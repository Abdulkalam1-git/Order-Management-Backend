package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "scheme_products_table")
public class SchemeProductsModel {
    @Id
    private String schemeProductId;
    @OneToOne
    @JoinColumn(name = "scheme_id", nullable = false)
    SchemesModel schemesModel;
    @OneToOne
    @JoinColumn(name = "product_id", nullable = false)
    ProductModel productModel;
    private Date createdAt = new Date();
    private Date deletedAt;
    private String status;



}
