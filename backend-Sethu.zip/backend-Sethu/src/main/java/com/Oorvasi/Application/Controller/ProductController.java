package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.CreateProductModel;
import com.Oorvasi.Application.Model.ProductModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/product")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

public class ProductController {

    @Autowired
    private ProductService productService;

    @PreAuthorize("hasAnyAuthority('Manage Item')")
    @PostMapping(value = "add/product")
    public ResponseEntity<Response> addDate(@RequestBody CreateProductModel createProductModel){
        return productService.addProduct(createProductModel);
    }

    @PreAuthorize("hasAnyAuthority('Manage Item')")
    @PostMapping(value = "delete/item/{productId}")
    public ResponseEntity<Response> deleteItem(@PathVariable String productId){
        return productService.deleteItem(productId);
    }

    @PreAuthorize("hasAnyAuthority('View Item Details')")
    @GetMapping(value = "get/item/{productId}")
    public ResponseEntity<Response> getItemByProductId(@PathVariable String productId){
        return productService.getItemById(productId);
    }

    @PreAuthorize("hasAnyAuthority('View Items')")
    @GetMapping(value = "get/items")
    public ResponseEntity<Response> getItems(@RequestParam  String search,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable){
        return  productService.getItems(search,pageable);
    }

    @PreAuthorize("hasAnyAuthority('Manage Item')")
    @PutMapping(value="edit/item")
    public ResponseEntity<Response> editItem(@RequestBody CreateProductModel updateProductModel){
        return productService.editProduct(updateProductModel);
    }



}
