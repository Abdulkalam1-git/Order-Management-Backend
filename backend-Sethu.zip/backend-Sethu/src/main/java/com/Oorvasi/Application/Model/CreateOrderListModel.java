package com.Oorvasi.Application.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreateOrderListModel {

    private String orderBy;
    private String orderId;
    private Integer items;
    private Double totalOrderAmount;
    private Double totalOrderWeight;
    private Double totalFreeOrderWeight;
    private String agentId;
    private String shopId;
    private List<String> productId;
    private List<Integer> quantity;
    private List<Double> amounts;
    private String createdBy;
    private Integer executiveId;
    //--to join ------ shopOrderTable and shopOrderListTable -------- //
    private List<String> tempId;
}
