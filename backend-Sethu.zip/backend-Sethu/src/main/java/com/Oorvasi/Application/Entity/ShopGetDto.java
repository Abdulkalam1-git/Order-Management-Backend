package com.Oorvasi.Application.Entity;

public interface ShopGetDto {
    String getShopName();
    String getArea();
    String getCity();
    String getShopId();
    String getLocationName();
    String getState();
}
