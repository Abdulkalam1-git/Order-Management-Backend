package com.Oorvasi.Application.Entity;

public interface DispatchItemsDto {

    String getOrderId();
    double getTotalOrderWeight();
    Double getTotalOrderAmount();
    Double getTotalFreeOrderWeight();
    Integer getItems();
    Integer getDispatchedItems();
    Integer getYetToDispatchItems();
    Double getAgentBalance();



}
