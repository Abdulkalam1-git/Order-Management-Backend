package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ShopService {
    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private ShopOrderRepository shopOrderRepository;

    @Autowired
    private ShopOrderListRepository shopOrderListRepository;

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ProductPriceRepository productPriceRepository;


    public ResponseEntity<Response> getShop(String keyWord) {
        Response response = new Response();
        try {
            List<ShopGetDto> shopDetailsFromDb = shopRepository.getShop(keyWord);
            if (shopDetailsFromDb == null || shopDetailsFromDb.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("No shop found ");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("Shop details fetched successfully");
                response.setData(shopDetailsFromDb);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getShopsBasedOnLocation(String locationId,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<ShopGetDto> shopDetailsFromDb = shopRepository.findByLocationId(locationId,pageable);
            if (shopDetailsFromDb == null || shopDetailsFromDb.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("No shop found based on location");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("Shop details fetched successfully based on location");
                response.setDatas(shopDetailsFromDb);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getSingleShop(String shopId) {
        Response response = new Response();
        try {
            ShopGetDto shopModelFromDb = shopRepository.getByShopId(shopId);
            if (shopModelFromDb == null) {
                response.setStatus("failure");
                response.setResponseMessage("No shop found with id ");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("Shop details fetched successfully");
                response.setData(Collections.singletonList(shopModelFromDb));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> addShop(ShopModel shopModel) {
        Response response = new Response();
        try {
            String shopName = shopModel.getShopName().trim();
            String city = shopModel.getCity().trim();
            String state = shopModel.getState().trim();
            String area = shopModel.getArea().trim();
            if (shopName == null || shopName.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("shopName is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (shopRepository.existsByShopName(shopName)!=null) {
                response.setStatus("failure");
                response.setResponseMessage("shopName already exists.");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }

            if (area == null || area.isEmpty() || area.equalsIgnoreCase("null")) {
                response.setStatus("failure");
                response.setResponseMessage("Area is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (city == null || city.isEmpty() || city.equalsIgnoreCase("null")) {
                response.setStatus("failure");
                response.setResponseMessage("City is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (shopModel.getLocationModel().getLocationId() == null || shopModel.getLocationModel().getLocationId().isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("LocationId is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (state == null || state.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("State is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

            }

            // -- generate shopId ----- //
            ShopModel shopModelFromDb = shopRepository.findFirstByOrderByCreatedOnDesc();
            String shopId = shopModelFromDb == null ? "SHOP0001" : "SHOP" + String.format("%04d", (Long.parseLong(shopModelFromDb.getShopId().split("SHOP")[1]) + 1));
            while (shopRepository.existsById(shopId)) {
                shopId = shopModelFromDb == null ? "SHOP0001" : "SHOP" + String.format("%04d", (Long.parseLong(shopId.split("SHOP")[1]) + 1));
            }

            shopModel.setShopId(shopId);
            shopModel.setShopName(shopName);
            shopModel.setCity(city);
            shopModel.setState(state);
            shopModel.setArea(area);
            shopModel.setStatus("Active");
            shopModel.setCreatedOn(new Date());
            shopRepository.save(shopModel);
            response.setStatus("Success");
            response.setResponseMessage("Shop added SuccessFully");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setStatus("Failure" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> editShop(ShopModel updateShopModel) {
        Response response = new Response();
        try {
            String shopName = updateShopModel.getShopName().trim();
            String city = updateShopModel.getCity().trim();
            String state = updateShopModel.getState().trim();
            String area = updateShopModel.getArea().trim();
            ShopModel shopModelFromDb = shopRepository.findByShopId(updateShopModel.getShopId());
            if (shopModelFromDb == null) {
                response.setStatus("failure");
                response.setResponseMessage("No shop found with id ");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            if (shopName == null || shopName.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("shopName is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            Optional<ShopModel> existingShop = shopRepository.findByShopNameIgnoreCase(shopName);

            if (existingShop.isPresent()) {
                ShopModel existingShopModel = existingShop.get();
                // --- during edit if not same shopId means throw error --//
                if (!existingShopModel.getShopId().equals(updateShopModel.getShopId())) {
                    response.setStatus("failure");
                    response.setResponseMessage("shopName already exists.");
                    return new ResponseEntity<>(response, HttpStatus.CONFLICT);
                }
            }

            if (area == null || area.isEmpty() || area.equalsIgnoreCase("null")) {
                response.setStatus("failure");
                response.setResponseMessage("Area is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (city == null || city.isEmpty() || city.equalsIgnoreCase("null")) {
                response.setStatus("failure");
                response.setResponseMessage("City is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (updateShopModel.getLocationModel().getLocationId() == null || updateShopModel.getLocationModel().getLocationId().isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("LocationId is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (state == null || state.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("State is required.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

            }
            shopModelFromDb.setShopName(shopName);
            shopModelFromDb.setCity(city);
            shopModelFromDb.setState(state);
            shopModelFromDb.setArea(area);
            shopModelFromDb.setLocationModel(updateShopModel.getLocationModel());
            shopModelFromDb.setStatus("Active");
            shopModelFromDb.setUpdatedBy(updateShopModel.getUpdatedBy());
            shopModelFromDb.setUpdatedOn(new Date());
            shopRepository.save(shopModelFromDb);
            response.setStatus("Success");
            response.setResponseMessage("Shop details updated SuccessFully");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setStatus("Failure" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> deleteShop(String shopId) {
        Response response = new Response();
        try {
            ShopModel shopModelFromDb = shopRepository.findById(shopId).orElseThrow(null);
            if (shopModelFromDb == null) {
                response.setStatus("failure");
                response.setResponseMessage("No shop found with id ");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            shopModelFromDb.setStatus("InActive");
            shopRepository.save(shopModelFromDb);
            response.setStatus("Success");
            response.setResponseMessage("Shop deleted SuccessFully");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("Failure" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //----- shopOrder and shopOrderList ----------//

    public ResponseEntity<Response> createShopOrder(CreateShopOrderListModel createShopOrderList) {
            Response response = new Response();
            try {
                ShopOrderModel shopOrderModels = shopOrderRepository.findByExecutiveIdAndShopModelShopIdAndStatus(createShopOrderList.getExecutiveId(),createShopOrderList.getShopId(),"Active");
                if (shopOrderModels!=null){
                    response.setStatus("Failure");
                    response.setResponseMessage("The executive already has an order related to the shop.");
                    return new ResponseEntity<>(response,HttpStatus.NOT_ACCEPTABLE);
                }
                ShopOrderModel shopOrderModel = new ShopOrderModel();
                ShopOrderListModel shopOrderListModel = new ShopOrderListModel();
                ShopModel shopModel = new ShopModel();

                //-----------Assign executives for shops-----------------//
                ShopOrderModel shopOrderModelFromDb = shopOrderRepository.findFirstByOrderByCreatedOnDesc();
                //--------------generate tempId for shop----------------//
                String tempId = shopOrderModelFromDb == null ? "TEMP00001" : "TEMP" + String.format("%05d", (Long.parseLong(shopOrderModelFromDb.getTempId().split("TEMP")[1]) + 1));
                while (shopOrderRepository.existsById(tempId)) {
                    tempId = shopOrderModelFromDb == null ? "TEMP00001" : "TEMP" + String.format("%05d", (Long.parseLong(tempId.split("TEMP")[1]) + 1));
                }
                //-- quantity -- //
                List<Integer> quantities = createShopOrderList.getQuantity();
                for (Integer quantity : quantities) {
                    if (quantity <= 0) {
                        throw new RuntimeException("Quantity cannot be negative and quantity cannot be zero");
                    }
                }

                // -------- Scenario: Duplicate product IDs in the productId list----------//
                Set<String> uniqueProductIds = new HashSet<>(createShopOrderList.getProductId());
                if (uniqueProductIds.size() != createShopOrderList.getProductId().size()) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Duplicate product IDs are not allowed.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
                Double totalFreeOrderWeight = createShopOrderList.getTotalFreeOrderWeight();
                if(totalFreeOrderWeight <0){
                    throw new RuntimeException("total Free Order Weight cannot be negative");
                }
                shopOrderModel.setTempId(tempId);
                shopOrderModel.setOrderBy(createShopOrderList.getOrderBy());
                shopOrderModel.setExecutiveId(createShopOrderList.getExecutiveId());
                shopOrderModel.setExecutiveName(createShopOrderList.getExecutiveName());
                shopOrderModel.setTotalOrderWeight(createShopOrderList.getTotalOrderWeight());
                shopOrderModel.setTotalFreeOrderWeight(totalFreeOrderWeight);
                shopModel.setShopId(createShopOrderList.getShopId());
                shopOrderModel.setStatus("Active");
                shopOrderModel.setCreatedBy(createShopOrderList.getCreatedBy());
                shopOrderModel.setCreatedOn(new Date());
                shopOrderModel.setOrderOn(new Date());
                int itemss = createShopOrderList.getProductId().size();
                shopOrderModel.setItems(itemss);
                shopOrderModel.setUpdatedBy(createShopOrderList.getUpdateBy());
                shopOrderModel.setShopModel(shopModel);
                shopOrderModel.setUpdatedOn(new Date());
                shopOrderRepository.save(shopOrderModel);

                //--- Calculate total order amount from product price ---//
                Double totalOrderAmount = 0.0;
                Double totalOrderWeights = 0.0;
                List<String> productIds = createShopOrderList.getProductId();
                for (int i = 0; i < productIds.size(); i++) {
                    String productId = productIds.get(i);
                    Integer quantity = createShopOrderList.getQuantity().get(i);

                    ProductModel productModel = productRepository.findById(productId).orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));
                    if (!productModel.getStandard()) {
                        Optional<ShopModel> shopModelFromDb = shopRepository.findById(shopModel.getShopId());
                        if (shopModelFromDb.isPresent()) {
                            String shopLocationId = shopModelFromDb.get().getLocationModel().getLocationId();

                            Optional<ProductPriceModel> productPriceModelFromDb = productPriceRepository.findByProductIdAndLocationModelLocationId(productId, shopLocationId);
                            if (productPriceModelFromDb.isPresent()){
                                productModel.setPrice(productPriceModelFromDb.get().getLocationPrice());
                            }
                        }
                    }

                    // ---- fetch product price from ProductModel --- //
                    Double amount = productModel.getPrice();
                    if (amount == null || amount <= 0) {
                        throw new RuntimeException("Invalid amount for product ID: " + productId);
                    }

                    //---- total amount for this product --//
                    Double totalAmount = amount * quantity;
                    Double totalWeight = productModel.getWeightPerUnit()*quantity/1000000;
                    if (totalAmount <= 0) {
                        throw new RuntimeException("Invalid total amount for product ID: " + productId);
                    }

                    ShopOrderListModel lastOrderListModelFromDb = shopOrderListRepository.findFirstByOrderByCreatedOnDesc();
                    String shopOrderListId = lastOrderListModelFromDb == null ? "SOL00001" : "SOL" + String.format("%05d", (Long.parseLong(lastOrderListModelFromDb.getOrderListId().split("SOL")[1]) + 1));

                    while (shopOrderListRepository.existsById(shopOrderListId)) {
                        shopOrderListId = lastOrderListModelFromDb == null ? "SOL00001" : "SOL" + String.format("%05d", (Long.parseLong(shopOrderListId.split("SOL")[1]) + 1));
                    }
                    shopOrderListModel.setOrderListId(shopOrderListId);
                    shopOrderListModel.setShopOrderModel(shopOrderModel);
                    shopOrderListModel.setCreatedOn(new Date());
                    shopOrderListModel.setProductModel(productModel);
                    shopOrderListModel.setQuantity(quantity);
                    shopOrderListModel.setAmount(amount);
                    shopOrderListModel.setTotalAmount(totalAmount);
                    shopOrderListModel.setDeliveryStatus("Yet to Assign Agent");
                    shopOrderListModel.setCreatedBy(createShopOrderList.getCreatedBy());
                    shopOrderListModel.setUpdatedBy(createShopOrderList.getUpdateBy());
                    shopOrderListModel.setUpdatedOn(new Date());
                    shopOrderListRepository.save(shopOrderListModel);

                    // ---------- Add to the total order amount (shop order table) -----//
                    totalOrderAmount += totalAmount;
                    totalOrderWeights += totalWeight;
                }

                shopOrderModel.setTotalOrderAmount(totalOrderAmount);
                shopOrderModel.setTotalOrderWeight(totalOrderWeights);
                shopOrderRepository.save(shopOrderModel);

                response.setResponseMessage("Successfully created shop order");
                response.setStatus("success");
                return new ResponseEntity<>(response, HttpStatus.CREATED);
            } catch(
                    RuntimeException e)
            {
                response.setStatus("fail");
                response.setResponseMessage("Failed to create shop order: " + e.getMessage());
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);  // Changed to BAD_REQUEST for validation errors
            } catch(
                    Exception e)
            {
                response.setStatus("fail");
                response.setResponseMessage("Failed to create shop order: " + e.getMessage());
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }
    }

    public ResponseEntity<Response> findRecommendedAndAllAgents(String shopId, String keyWord) {
        Response response = new Response();
        ShopModel s = new ShopModel();
        try {
            //---------------------Recommended Agents Based On location and Searching------------------------------//
            List<AgentLocationDto> RecommendedAgentsFromDb = shopRepository.FindPriorityAgents(shopId, keyWord);
            if (RecommendedAgentsFromDb == null) {
                throw new RuntimeException("Error fetching recommended agents");
            }
            boolean check = !RecommendedAgentsFromDb.isEmpty();
            response.setStatus(check ? "success" : "success ");
            response.setResponseMessage(check ? "success" : "no  Recommended Agent found ");
            response.setData(RecommendedAgentsFromDb);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (RuntimeException e) {
            response.setStatus("failure");
            response.setResponseMessage("failed to retrieve: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("unexpected error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> findAllAgents(String keyWord,Pageable pageable) {
        Response response = new Response();
        ShopModel s = new ShopModel();
        try {
            //---------------------Recommended Agents Based On location and Searching------------------------------//
            Page<AgentLocationDto> AllAgents = shopRepository.FindAllAgents(keyWord,pageable);
            if (AllAgents == null) {
                throw new RuntimeException("Error fetching recommended agents");
            }
            boolean check = !AllAgents.isEmpty();
            response.setStatus(check ? "success" : "success ");
            response.setResponseMessage(check ? "success" : "no  Recommended Agent found ");
            response.setDatas(AllAgents);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (RuntimeException e) {
            response.setStatus("failure");
            response.setResponseMessage("failed to retrieve: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("unexpected error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> fetchShopsGroupedByExecutives(String keyWord,String locationId,Pageable pageable) {
        Response response = new Response();
        try {
            List<ShopOrderDto> shopsData = shopOrderRepository.findShopsGroupedByExecutive(keyWord ,locationId,pageable);
            Map<String, List<ShopOrderDto>> groupedByExecutive = shopsData.stream().collect(Collectors.groupingBy(ShopOrderDto::getExecutiveName));

            // -----Transform the data to remove 'executiveName' from the shop details----------//
            List<ShopGroupByExecutive> executivesWithShops = groupedByExecutive.entrySet().stream()
                    .map(entry -> new ShopGroupByExecutive(entry.getKey(),
                            entry.getValue().get(0).getExecutiveId(),
                            entry.getValue().stream()
                                    .map(shop -> new shopOrderGetDto (
                                            shop.getShopId(),
                                            shop.getShopName(),
                                            shop.getTotalOrderWeight(),
                                            shop.getTotalOrderAmount(),
                                            shop.getTotalFreeOrderWeight(),
                                            shop.getTempId()))
                            .collect(Collectors.toList())))
                    .collect(Collectors.toList());
            //-- pagination with shop size --- .//
            Page<ShopGroupByExecutive> pageResult = new PageImpl<>(executivesWithShops, pageable, executivesWithShops.size());
            response.setStatus("success");
            response.setDatas(pageResult);
            response.setResponseMessage("Shops grouped by executive");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("fail");
            response.setResponseMessage("Error retrieving data: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public ResponseEntity<Response> getShopOrderList(String ShopTempId) {
        Response response = new Response();
        try {
            //------validate ------//
            if (ShopTempId == null || ShopTempId.trim().isEmpty()) {
                throw new IllegalArgumentException("ShopTempId cannot be null or empty.");
            }
            List<ShopOrderItemsDto> getShopOrderListInDetailsFromDb = shopOrderListRepository.getShopOrderListInformation(ShopTempId);
            List<ShopOrderListProductDto> getProductDetailsFromDb = shopOrderListRepository.getShopOrderListProduct(ShopTempId);
            if (getShopOrderListInDetailsFromDb == null || getShopOrderListInDetailsFromDb.isEmpty()) {
                throw new NoSuchElementException("No order details found for the given ShopTempId.");
            }
            if (getProductDetailsFromDb == null || getProductDetailsFromDb.isEmpty()) {
                throw new NoSuchElementException("No product details found for the given ShopTempId.");
            }
            response.setResponseMessage("success");
            response.setStatus("success");
            response.setData(Collections.singletonList(new ShopOrderListInformationDto(getShopOrderListInDetailsFromDb, getProductDetailsFromDb)));
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (IllegalArgumentException | NoSuchElementException e) {
            response.setResponseMessage("fail: " + e.getMessage());
            response.setStatus("failed");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        } catch (Exception e) {
            response.setResponseMessage("Error retrieving data: " + e.getMessage());
            response.setStatus("failed");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}

