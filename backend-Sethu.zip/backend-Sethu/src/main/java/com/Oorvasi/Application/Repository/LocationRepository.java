package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.MarketZoneDto;
import com.Oorvasi.Application.Model.LocationModel;
import com.Oorvasi.Application.Model.StaffModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface LocationRepository extends JpaRepository<LocationModel, String> {
        @Query(value = "SELECT l.location_id as locationId, l.location_name AS LocationName, l.short_code AS ShortCode FROM location_table l " +
                "WHERE l.status iLike 'Active' AND (:search IS NULL OR l.location_name iLIKE %:search%)", nativeQuery = true)
        List<MarketZoneDto> findAll(String search);
        @Query(value = "SELECT l.location_id as locationId, l.location_name AS LocationName, l.short_code AS ShortCode FROM location_table l " +
                "WHERE l.status iLIKE 'active' " +
                "AND l.location_id = :locationId", nativeQuery = true)
        MarketZoneDto findMarketZoneByLocationId(String locationId);
    Optional <LocationModel> findByLocationId(String locationId);

    LocationModel findTop1ByOrderByCreatedOnDesc();

    boolean existsByLocationId(String locationId);

    @Query(value = "Select * from location_table where location_name ilike %:locationName ",nativeQuery = true)
    LocationModel findByLocationName(String locationName);

    @Query(value = "Select * from location_table where short_code ilike %:shortCode ",nativeQuery = true)
    LocationModel findByShortCode(String shortCode);
}
