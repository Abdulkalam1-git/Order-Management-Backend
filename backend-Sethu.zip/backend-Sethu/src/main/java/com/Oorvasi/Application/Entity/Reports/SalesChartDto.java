package com.Oorvasi.Application.Entity.Reports;

public interface SalesChartDto {
      String getLocationId();
      Long getTotalAmount();
      String getMonth();
}
