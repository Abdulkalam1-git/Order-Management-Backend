package com.Oorvasi.Application.Entity;

public interface AgentSummary {
    Long getAgents();
    Long getTotalOrders();
}
