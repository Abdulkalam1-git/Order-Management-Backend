package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.AccountMasterModel;
import com.Oorvasi.Application.Model.AccountTypeModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Repository.AccountMasterRepository;
import com.Oorvasi.Application.Repository.AccountTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    @Autowired
    private AccountTypeRepository accountTypeRepository;

    @Autowired
    private AccountMasterRepository accountMasterRepository;

    public ResponseEntity<Response> createAccountType(AccountTypeModel accountTypeModel) {
        Response response = new Response();
        try {
            accountTypeRepository.save(accountTypeModel);
            response.setResponseMessage("Successfully added");
            response.setStatus("success");
        } catch (Exception e) {
            response.setResponseMessage("Failed to save: " + e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    public ResponseEntity<Response> createAccountMaster(AccountMasterModel accountMasterModel) {
        Response response = new Response();
        try {
            //  Prevent race condition by synchronized block---- //
            synchronized (this) {
                AccountMasterModel accountMasterModelFromDb = accountMasterRepository.findFirstByOrderByCreatedOnDesc();
                String accountId = accountMasterModelFromDb == null ? "ACC00001" : "ACC"
                        + String.format("%05d", (Long.parseLong(accountMasterModelFromDb.getAccountId().split("ACC")[1]) + 1));

                accountMasterModel.setAccountId(accountId);
                accountMasterRepository.save(accountMasterModel);
                response.setResponseMessage("Added successfully");
                response.setStatus("success");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setStatus("fail");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAccountsByAccountTypeAndAccountName(String type, String keyWord) {
        Response response = new Response();
        try {
            //---- Searching for Account -->  Type = agent, manager, executive and keyWord for name ----------//
            List<AccountMasterModel> AccountFromDb = accountMasterRepository.getAccountByAccountTypeAndAccountName(type, keyWord);
            boolean checkEmpty = !AccountFromDb.isEmpty();
            response.setStatus(checkEmpty ? "success" : "failure");
            response.setResponseMessage(checkEmpty ? "success" : "No data found");
            response.setData(checkEmpty ? AccountFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
}
