package com.Oorvasi.Application.Entity;

public interface ShopOrderResponseModel {

     String getExecutiveName();
     Integer getExecutiveId();
     String getShopId();
     String getShopName();
     Double getTotalOrderAmount();
     Double getTotalOrderWeight();
     Double getTotalFreeOrderWeight();
     String getArea();
     String getCity();
     String getTempId();
}
