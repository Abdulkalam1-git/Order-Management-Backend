package com.Oorvasi.Application.Entity;

public interface ItemOrderSummaryDto {

    Long getItems();
    Long getTotalOrders();
}
