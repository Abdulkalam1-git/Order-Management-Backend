package com.Oorvasi.Application.Model;


import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AgentPersonalModel {

    private String agentId;
    private String agentName;
    private String state;
    private String city;
    private String area;
    private Double discountPercent;
    private Double agentBalance;

}
