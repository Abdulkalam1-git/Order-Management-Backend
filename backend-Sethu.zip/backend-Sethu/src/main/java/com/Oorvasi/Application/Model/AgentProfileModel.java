package com.Oorvasi.Application.Model;


import com.Oorvasi.Application.Entity.OrderDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Page;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AgentProfileModel {

    private List<OrderDto> orderModel;
    private AgentPersonalModel agentPersonalModel;

}
