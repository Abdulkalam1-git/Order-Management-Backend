package com.Oorvasi.Application.Model;

import com.Oorvasi.Application.Entity.DispatchOrderDetailsDto;
import com.Oorvasi.Application.Repository.UserDetails;
import lombok.*;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Response {

    private String status;
    private String responseMessage;
    private List<?> data;
    private OrderAndOrderListModel orderData;
    private Page datas;
    private String execution;
    private UserDetails userDetails;
    private List<Objects> AgentDetails;
    private DispatchOrderDetailsDto TotalOrderDetails;
    private FinalizeOrderModel finalizeOrderModel;
}
