package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.FactoryModel;
import com.Oorvasi.Application.Model.LocationModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Repository.FactoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Collections;
import java.util.List;


@Service
public class FactoryService {

    @Autowired
    private FactoryRepository factoryRepository;

    public ResponseEntity<Response> createFactory(@RequestBody FactoryModel factoryModel) {
        Response response = new Response();
        try {
            FactoryModel factoryName = factoryRepository.findByFactoryName(factoryModel.getFactoryName());
            FactoryModel factoryShortCode = factoryRepository.findByFactoryShortCode(factoryModel.getShortCode());
            if (factoryName!=null){
                response.setStatus("Failure");
                response.setResponseMessage("Factory Name already Exists");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            if (factoryShortCode!=null){
                response.setStatus("Failure");
                response.setResponseMessage("Short Code already Exists");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            FactoryModel factoryModelFromDB = factoryRepository.findTop1ByOrderByCreatedOnDesc();
            String factoryId = factoryModelFromDB == null ? "FAC001" : "FAC" + String.format("%03d", (Long.parseLong(factoryModelFromDB.getFactoryId().split("FAC")[1]) + 1));
            while (factoryRepository.existsByFactoryId(factoryId)) {
                factoryId = factoryModelFromDB == null ? "FAC001" : "FAC" + String.format("%03d", (Long.parseLong(factoryId.split("FAC")[1]) + 1));
            }
            factoryModel.setStatus("Active");
            factoryModel.setFactoryId(factoryId);
            factoryRepository.save(factoryModel);
            response.setStatus("Success");
            response.setResponseMessage("factory added successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> getFactoryById(String factoryId){
        Response response = new Response();
        try {
            FactoryModel factoryModel = factoryRepository.findByFactoryId(factoryId);
            if (factoryModel!=null){
                response.setStatus("Success");
                response.setResponseMessage("factory Details");
                response.setData(Collections.singletonList(factoryModel));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }else {
                response.setStatus("Failure");
                response.setResponseMessage("Unable to find factory");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        }catch (Exception e){
            response.setStatus("Failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // ---------method to getAll factory and searching By name --------//
    public ResponseEntity<Response> getFactoryByName(String keyWord) {
        Response response = new Response();
        try {
            List<FactoryModel> getFactoryFromDb = factoryRepository.findByfactoryNameContainingIgnoreCase(keyWord);
            boolean checkNull = !getFactoryFromDb.isEmpty();
            response.setStatus(checkNull ? "Success" : "Failure");
            response.setData(checkNull ? getFactoryFromDb : null);
            response.setResponseMessage(checkNull ? "successfully retrieved " : "no factory found");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage(e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> editFactory(FactoryModel updateFactoryModel) {
        Response response = new Response();
        try {
            if (updateFactoryModel.getShortCode() == null || updateFactoryModel.getShortCode().length() != 2) {
                response.setStatus("failure");
                response.setResponseMessage("Invalid shortCode format. It must be 2 characters long.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            FactoryModel factoryFromDb = factoryRepository.findByFactoryId(updateFactoryModel.getFactoryId());
            if (factoryFromDb == null) {
                response.setStatus("failure");
                response.setResponseMessage("Factory not found for the given factoryId");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            String normalizedFactoryName = updateFactoryModel.getFactoryName().trim().toLowerCase();
            if (factoryRepository.existsByFactoryNameIgnoreCaseAndFactoryIdNot(normalizedFactoryName, updateFactoryModel.getFactoryId())) {
                response.setStatus("failure");
                response.setResponseMessage("FactoryName already exists.");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            String normalizedShortCode = updateFactoryModel.getShortCode().trim().toLowerCase();
            if (factoryRepository.existsByShortCodeIgnoreCaseAndFactoryIdNot(normalizedShortCode, updateFactoryModel.getFactoryId())) {
                response.setStatus("failure");
                response.setResponseMessage("ShortCode already exists.");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            factoryFromDb.setFactoryName(updateFactoryModel.getFactoryName());
            factoryFromDb.setShortCode(updateFactoryModel.getShortCode());
            factoryFromDb.setArea(updateFactoryModel.getArea());
            factoryFromDb.setStatus(updateFactoryModel.getStatus());
            factoryRepository.save(factoryFromDb);

            response.setStatus("success");
            response.setResponseMessage("Factory updated successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public ResponseEntity<Response> deleteFactoryById(String factoryId) {
        Response response = new Response();
        try {
            FactoryModel factoryModelFromDb = factoryRepository.findById(factoryId).orElse(null);
            if (factoryModelFromDb != null) {
                factoryModelFromDb.setStatus("InActive");
                factoryRepository.save(factoryModelFromDb);
                response.setStatus("success");
                response.setResponseMessage("Factory  deleted successfully ");
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                response.setStatus("failure");
                response.setResponseMessage("Factory Zone not found");
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (Exception e) {
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

}
