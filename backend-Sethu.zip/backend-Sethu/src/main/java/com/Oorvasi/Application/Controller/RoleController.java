package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.Role;
import com.Oorvasi.Application.Model.RoleModel;
import com.Oorvasi.Application.Service.RoleServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping (value ="/roles")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

public class RoleController {

    @Autowired
    private RoleServices roleServices;

    @PreAuthorize("hasAnyAuthority('Manage Role')")
    @PostMapping("create/role")
    private ResponseEntity<Response> createRole(@RequestBody RoleModel roleModel){
        return roleServices.createRole(roleModel);
    }

    @PreAuthorize("hasAnyAuthority('View Roles')")
    @GetMapping("get/roles")
    public ResponseEntity<Response> getRoles(  ){
        return roleServices.getAllRoles();
    }
}
