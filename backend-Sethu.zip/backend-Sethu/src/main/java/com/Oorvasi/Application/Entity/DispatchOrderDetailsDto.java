package com.Oorvasi.Application.Entity;

public interface DispatchOrderDetailsDto {

    Long getTotalOrders();
    Long getItemsToBeDispatched();
    Long getItemsDispatched();

}
