package com.Oorvasi.Application.Entity;

public interface MarketZoneDto {
    String getLocationName();
    String getShortCode();
    String getLocationId();
}
