package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
public class TransActionService {
    @Autowired
    private TransactionalRepository transactionalRepository;

    @Autowired
    private AgentServiceLimitRepository agentServiceLimitRepository;

    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private AgentRepository agentRepository;


    public ResponseEntity<Response> addTransAction(TransActionAndPaymentModel transActionAndPaymentModel) {
        Response response = new Response();
        try {
            TransActionModel transActionModel = new TransActionModel();
            AgentModel agentModel = agentRepository.findByAgentId(transActionAndPaymentModel.getAgentId());
            //---------- amount deduction in agent service limit based on transaction amount done for agent -----------//
            double transactionAmount = transActionAndPaymentModel.getAmounts().stream().mapToDouble(Double::doubleValue).sum();
            List<Double> amounts = transActionAndPaymentModel.getAmounts();
            for (Double amount : amounts) {
                if (amount <= 0) {
                    throw new RuntimeException("Amount cannot be negative or zero");
                }
            }
            //---//
            transActionAndPaymentModel.setAmount(transactionAmount);
            transActionModel.setAmount(transActionAndPaymentModel.getAmount());
            Double totalamount = transActionModel.getAmount();
            AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(transActionAndPaymentModel.getAgentId());
            Double oldOutStanding = agentServiceLimitModel.getOutStandingAmount();
            Double newOutStanding= oldOutStanding-totalamount;
            if (newOutStanding<0){
                agentServiceLimitModel.setOutStandingAmount(0.0);
                agentServiceLimitModel.setExcessAmount(agentServiceLimitModel.getExcessAmount()+Math.abs(newOutStanding));
            }else {
                agentServiceLimitModel.setOutStandingAmount(newOutStanding);
                agentServiceLimitModel.setExcessAmount(0.0);
            }
            TransActionModel transActionModelFromDb = transactionalRepository.findFirstByOrderByCreatedOnDesc();
            String txId = transActionModelFromDb == null ? "TXID00001" : "TXID" + String.format("%05d", (Long.parseLong(transActionModelFromDb.getTransactionId().split("TXID")[1]) + 1));
            while (transactionalRepository.existsByTransactionId(txId)) {
                txId = transActionModelFromDb == null ? "TXID00001" : "TXID" + String.format("%05d", (Long.parseLong(txId.split("TXID")[1]) + 1));
            }
            transActionModel.setTransactionId(txId);
            transActionModel.setAgentModel(agentModel);
            transActionModel.setAmount(transActionAndPaymentModel.getAmount());
            transActionModel.setReceivedBy(transActionAndPaymentModel.getReceivedBy());
            transActionModel.setReferenceNo(transActionAndPaymentModel.getReferenceNo());
            transActionModel.setStatus("Active");
            transactionalRepository.save(transActionModel);
            for (int i = 0; i < transActionAndPaymentModel.getPaymentTypeId().size(); i++) {
                PaymentModel paymentModel = new PaymentModel();
                PaymentModel paymentModelFromDB = paymentRepository.findFirstByOrderByCreatedOnDesc();
                String paymentId = paymentModelFromDB == null ? "PAY00001" : "PAY" + String.format("%05d", (Long.parseLong(paymentModelFromDB.getPaymentId().split("PAY")[1]) + 1));
                while (paymentRepository.existsByPaymentId(paymentId)) {
                    paymentId = paymentModelFromDB == null ? "PAY00001" : "PAY" + String.format("%05d", (Long.parseLong(paymentId.split("PAY")[1]) + 1));
                }
                paymentModel.setPaymentId(paymentId);
                paymentModel.setAmount(transactionAmount);
                TransActionModel transActionModel1 = new TransActionModel();
                transActionModel1.setTransactionId(txId);
                paymentModel.setTransActionModel(transActionModel1);
                paymentModel.setAmount(transActionAndPaymentModel.getAmounts().get(i));
                Double paymentAmount = paymentModel.getAmount();
                if (paymentAmount == 0) {
                    throw new RuntimeException("amount cannot be zero");
                }
                if (paymentAmount < 0) {
                    throw new RuntimeException("amount cannot be negative");
                }
                PaymentTypeModel paymentTypeModel = new PaymentTypeModel();
                paymentTypeModel.setPaymentTypeId(transActionAndPaymentModel.getPaymentTypeId().get(i));
                paymentModel.setPaymentTypeModel(paymentTypeModel);
                paymentModel.setStatus("Active");
                paymentModel.setCreatedBy(transActionAndPaymentModel.getCreatedBy());
                paymentRepository.save(paymentModel);
            }
            response.setResponseMessage("Transaction Successful");
            response.setStatus("Success");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            System.out.println(e.getMessage());
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getFinalPaymentDetails(TransActionAndPaymentModel transActionAndPaymentModel){
        Response response = new Response();
        try {
                 AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(transActionAndPaymentModel.getAgentId());
                 Double outStandingAmount = agentServiceLimitModel.getOutStandingAmount();
                 Double excessAmount = agentServiceLimitModel.getExcessAmount();
                 Double paidAmount = transActionAndPaymentModel.getAmount();
            FinalizeOrderModel finalizeOrderModel = new FinalizeOrderModel();
                 if (outStandingAmount==0.0 && excessAmount == 0.0){
                     finalizeOrderModel.setOldBalance(0.0);
                     finalizeOrderModel.setNewBalance(paidAmount*-1);
                 }else if (outStandingAmount>0 && excessAmount == 0.0 ){
                     finalizeOrderModel.setOldBalance(outStandingAmount*-1);
                     double balance = 0.0;
                     if (outStandingAmount>paidAmount){
                         balance = outStandingAmount-paidAmount;
                         finalizeOrderModel.setNewBalance(balance*-1);
                     }else {
                         balance = paidAmount-outStandingAmount;
                         finalizeOrderModel.setNewBalance(balance);
                     }
                 } else {
                     finalizeOrderModel.setOldBalance(excessAmount);
                     finalizeOrderModel.setNewBalance(excessAmount+paidAmount);
                 }
                 response.setStatus("Success");
                 response.setFinalizeOrderModel(finalizeOrderModel);
                 return new ResponseEntity<>(response,HttpStatus.OK);
        }catch (Exception e){
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled Error "+ e.getMessage());
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
