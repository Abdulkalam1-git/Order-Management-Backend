package com.Oorvasi.Application.Entity.Reports;

public interface AgentCount {
    Integer getAgents();
}
