package com.Oorvasi.Application.Model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "shop_order_list_table")
@Entity
public class ShopOrderListModel {

    @Id
    private String orderListId;
    @OneToOne
    @JoinColumn(name = "temp_id", nullable = false)
    ShopOrderModel shopOrderModel;
    @OneToOne
    @JoinColumn(name = "product_id", nullable = false)
    ProductModel productModel;
    private Integer quantity;
    private Double amount;
    private Double totalAmount;
    @OneToOne
    @JoinColumn(name = "factory_id")
    FactoryModel factoryModel;
    private String deliveryStatus;
    private Date createdOn;
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}
