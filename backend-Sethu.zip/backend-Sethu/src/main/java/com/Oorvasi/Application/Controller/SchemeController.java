package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Entity.SchemeResponseDTO;
import com.Oorvasi.Application.Model.CreateSchemeProductModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.SchemeRulesModel;
import com.Oorvasi.Application.Model.SchemesModel;
import com.Oorvasi.Application.Service.SchemeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value = "scheme")
public class SchemeController {
    @Autowired
    private SchemeService schemeService;

//--1--//
    @PostMapping("create/schemes")
    public ResponseEntity<Response> createScheme(@RequestBody SchemesModel schemesModel){
        return schemeService.createScheme(schemesModel);
    }
    @GetMapping("get/schemes")
    public ResponseEntity<Response> getSchemes(
    @RequestParam String status ,
    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate){
        return schemeService.getSchemesDetails(status , startDate , endDate);
    }
    @PutMapping("update/scheme")
    public ResponseEntity<Response> updateScheme(@RequestBody  SchemesModel updatedSchemeData){
        return schemeService.updateScheme(updatedSchemeData);
    }

    @PostMapping("delete/scheme")
    public ResponseEntity<Response> deleteScheme(@RequestParam String schemeId){
        return schemeService.deleteScheme(schemeId);
    }
    //--2--//

    @PostMapping("create/schemeProduct")
    public ResponseEntity<Response> createSchemeProduct(@RequestBody CreateSchemeProductModel createSchemeProductModel){
        return schemeService.createSchemeProduct(createSchemeProductModel);
    }
    @GetMapping("get/Product-Schemes")
    public ResponseEntity<Response> getProductSchemes(){
        return schemeService.getAllProductsScheme();
    }
    @PostMapping("delete/ProductScheme")
    public ResponseEntity<Response> deleteProductScheme(@RequestParam String schemeProductId){
        return schemeService.deleteProductScheme(schemeProductId);
    }

    //--3--//

    @PostMapping("create/rule-scheme")
    public ResponseEntity<Response> createSchemeRule(@RequestBody SchemeRulesModel schemeRulesModel){
        return schemeService.createSchemeRule(schemeRulesModel);
    }

    @GetMapping("get/rule-Schemes")
    public ResponseEntity<Response> getRuleScheme(
            @RequestParam String status,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate
    ) {
        return schemeService.getAllRuleScheme(status, startDate, endDate);
    }

    @PostMapping("/delete/rule-schemes")
    public ResponseEntity<Response> deleteRuleScheme(@RequestParam String schemeRuleId){
        return schemeService.deleteRuleScheme(schemeRuleId);
    }
    @PutMapping("update/rule-scheme")
    public ResponseEntity<Response> updateRuleScheme(@RequestBody SchemeRulesModel schemeRulesModel){
        return schemeService.updateSchemeRule(schemeRulesModel);}

//
//   GetMapping("get/schemes-ByProduct")
//    public ResponseEntity<Response> getSchemesProduct(@RequestParam  String productId){
//        return schemeService.findSchemesByProductId(productId);
//    }

    @GetMapping("/get/global-schemes")
    public ResponseEntity<Response> getGlobalSchemesByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {
        return schemeService.getAllGlobalSchemes(startDate, endDate);
    }

    @GetMapping("/product/schemes")public ResponseEntity<Response> findSchemesByProductId
            (@RequestParam String productId ,
             @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
             @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate){
        return schemeService.findSchemesByProduct(productId,startDate,endDate);

    }}
