package com.Oorvasi.Application.Entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Page;

@Setter
@Getter
public class CombinedZoneResponseDTO {
    private TotalSales orderSummary;
    private Page<ZoneByDto> zoneStats;
}
