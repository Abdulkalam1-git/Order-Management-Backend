package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.StaffModel;
import com.Oorvasi.Application.Repository.RolePermissionRepository;
import com.Oorvasi.Application.Repository.StaffRepository;
import com.Oorvasi.Application.Repository.UserRepository;
import com.Oorvasi.Application.Repository.UserRoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

@Service
public class JWTUserDetailsService implements UserDetailsService {
    private static final Logger logger = LoggerFactory.getLogger(JWTUserDetailsService.class);

    @Autowired
    protected UserRepository userRepository;
    @Autowired
    private RolePermissionRepository rolePermissionRepository;
    @Autowired
    private UserRoleRepository userRoleRepository;
    @Autowired
    private StaffRepository staffRepository;

    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {    logger.info("Attempting to load user by username: {}", userId);    Long userIds = Long.valueOf(userId);    StaffModel user = (StaffModel) staffRepository.findByUserId(userIds)            .orElseThrow(() -> new UsernameNotFoundException("User not found"));    List<GrantedAuthority> authorities = new ArrayList<>();    String roleId = user.getRole().getRoleId();    logger.info("User Role ID: {}", roleId);    authorities.add(new SimpleGrantedAuthority("ROLE_" + roleId));    List<String> permissions = rolePermissionRepository.findPermissionsByRoleId(roleId);    logger.info("Permissions for role {}: {}", roleId, permissions);    for (String permission : permissions) {        authorities.add(new SimpleGrantedAuthority(permission));    }    return new User(            user.getUserName(),            user.getUserName(),            true, true, true, true,            authorities    );}
}



