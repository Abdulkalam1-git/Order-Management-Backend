package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.DispatchItemsDto;
import com.Oorvasi.Application.Entity.DispatchOrderDetailsDto;
import com.Oorvasi.Application.Entity.FactoryAssignDto;
import com.Oorvasi.Application.Entity.OrderDto;
import com.Oorvasi.Application.Model.OrderListModel;
import com.Oorvasi.Application.Model.OrderModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface OrderRepository extends JpaRepository<OrderModel, String> {


    OrderModel findByOrderId(String orderId);


    @Query(value = "select ot.order_id as orderId,ot.total_order_weight as totalOrderWeight, COALESCE(ot.total_free_order_weight , 0)  as totalFreeOrderWeight , ot.total_order_amount as totalOrderAmount,at.agent_id,at.agent_name as agentName,\n" +
            " at.area as area,at.city as city from order_table as ot inner join agent_table as at on ot.agent_id=at.agent_id where ot.order_id=:orderId ",nativeQuery = true)
    OrderResponseModel findByOrderIds(String orderId);

    Page<OrderModel> findByStatus(String Status, Pageable pageable);
    @Query(value = "select Count(*) as count from order_table where agent_id=?1 ", nativeQuery = true)
    Integer findCount(String agentId);

    @Query("SELECT " +
            "o.orderId AS orderId, " +
            "o.totalOrderWeight AS totalOrderWeight, " +
            "o.totalOrderAmount AS totalOrderAmount, " +
            "COALESCE(o.totalFreeOrderWeight , 0 ) AS totalFreeOrderWeight , " +
            "o.items AS items, " +
            "CASE " +
            "    WHEN al.OutStandingAmount <> 0 THEN -al.OutStandingAmount " +
            "    WHEN al.excessAmount <> 0 THEN al.excessAmount " +
            "    ELSE 0 " +
            "END AS agentBalance " +
            "FROM OrderModel o " +
            "INNER JOIN AgentServiceLimitModel al ON o.agentModel.agentId = al.agentModel.agentId " +
            "WHERE o.orderId ILIKE %:keyWord% " +
            "AND o.status = 'Finalize' " +
            "GROUP BY o.orderId, o.totalOrderWeight, o.totalOrderAmount, o.items, al.OutStandingAmount, al.excessAmount")
    Page<OrderDto> getSearchOrder(String keyWord, Pageable pageable);



    @Query("SELECT " +
            "o.orderId AS orderId , " +
            " o.totalOrderAmount AS totalOrderAmount ,o.totalOrderWeight as totalOrderWeight , " +
            "COALESCE(o.totalFreeOrderWeight , 0)  as totalFreeOrderWeight , " +
            "o.status AS status " +
            "FROM OrderModel o " +
            "Where o.agentModel.agentId=:agentId ")
    List<OrderDto> getSingleAgentOrder(String agentId);

    @Query("SELECT " +
            "o.orderId AS orderId, " +
            "o.totalOrderWeight AS totalOrderWeight, " +
            "o.totalOrderAmount AS totalOrderAmount, " +
            "COALESCE(o.totalFreeOrderWeight , 0 )  AS totalFreeOrderWeight , "+
            "o.items AS items, " +
            "CASE " +
            "    WHEN al.OutStandingAmount <> 0 THEN -al.OutStandingAmount " +
            "    WHEN al.excessAmount <> 0 THEN al.excessAmount " +
            "    ELSE 0 " +
            "END AS agentBalance " +
            "FROM OrderModel o " +
            "INNER JOIN AgentServiceLimitModel al ON o.agentModel.agentId = al.agentModel.agentId " +
            "WHERE o.orderId ILIKE %:keyWord% " +
            "AND o.status = 'Ready To Finalize' " +
            "GROUP BY o.orderId, o.totalOrderWeight, o.totalOrderAmount, o.items, al.OutStandingAmount, al.excessAmount")
    Page<OrderDto> getSearchReadyToFinalizeOrder(String keyWord, Pageable pageable);


    @Query(value = "SELECT DISTINCT o.order_id AS orderId,o.total_order_weight AS totalOrderWeight," +
            "    o.total_order_amount AS totalOrderAmount," +
            "    o.created_on AS createdOn," +
            "COALESCE(o.total_free_order_weight , 0 ) AS totalFreeOrderWeight , "+
            "    CASE WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount WHEN al.excess_amount <> 0 THEN al.excess_amount ELSE 0 " +
            "    END AS agentBalance,CASE WHEN CASE WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount WHEN al.excess_amount <> 0 THEN al.excess_amount " +
            "    ELSE 0 END > -100000 THEN 'Proceed' ELSE 'Blocked' END AS status FROM Order_table o " +
            " JOIN Order_list_table ol ON o.order_id = ol.order_id JOIN agent_service_limit_table al " +
            " ON o.agent_id = al.agent_id WHERE o.order_id ILIKE %:keyword% " +
            " AND ol.factory_id IS NULL ",nativeQuery = true)
    Page<FactoryAssignDto> getOrderItemsByOrderId(String keyword, Pageable pageable);

    @Query(value = "SELECT DISTINCT o.order_id AS orderId,o.total_order_weight AS totalOrderWeight," +
            "    o.total_order_amount AS totalOrderAmount," +
            "Coalesce(o.total_free_order_weight , 0 )  AS totalFreeOrderWeight , " +
            "    o.created_on AS createdOn," +
            "    CASE WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount WHEN al.excess_amount <> 0 THEN al.excess_amount ELSE 0 " +
            "    END AS agentBalance,CASE WHEN CASE WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount WHEN al.excess_amount <> 0 THEN al.excess_amount " +
            "    ELSE 0 END > -100000 THEN 'Proceed' ELSE 'Blocked' END AS status FROM Order_table o " +
            " JOIN Order_list_table ol ON o.order_id = ol.order_id JOIN agent_service_limit_table al " +
            " ON o.agent_id = al.agent_id WHERE ol.factory_id IS NULL ",nativeQuery = true)
    Page<FactoryAssignDto> getOrderItemsByOrderIdAll(Pageable pageable);


    @Query(value = "SELECT " +
            "o.orderId AS orderId, " +
            "o.totalOrderWeight AS totalOrderWeight, " +
            "o.totalOrderAmount AS totalOrderAmount, " +
            " COALESCE( o.totalFreeOrderWeight , 0 )  AS totalFreeOrderWeight , " +
            "o.items AS items, " +
            "SUM(CASE WHEN ol.deliveryStatus = 'Dispatched' THEN 1 ELSE 0 END) AS dispatchedItems, " +
            "SUM(CASE WHEN ol.deliveryStatus = 'Yet to dispatch' THEN 1 ELSE 0 END) AS yetToDispatchItems, " +
            "CASE " +
            "    WHEN al.OutStandingAmount <> 0 THEN -al.OutStandingAmount " +
            "    WHEN al.excessAmount <> 0 THEN al.excessAmount " +
            "    ELSE 0 " +
            "END AS agentBalance " +
            "FROM OrderModel o " +
            "INNER JOIN OrderListModel ol ON o = ol.orderModel " +
            "INNER JOIN AgentServiceLimitModel al ON o.agentModel.agentId = al.agentModel.agentId " +
            "INNER JOIN FactoryModel f ON f.factoryId = ol.factoryModel.factoryId " + // Added this JOIN
            "WHERE ol.factoryModel IS NOT NULL " +
            "AND ol.deliveryStatus = 'Yet to dispatch' " +
            "AND o.orderId ILIKE %:keyWord% " +
            "AND f.factoryId = :factoryId " + // Filtering by factoryId
            "GROUP BY o.orderId, o.totalOrderWeight, o.totalOrderAmount, al.OutStandingAmount, al.excessAmount")
    Page<DispatchItemsDto> getOrderDispatchDetails(String keyWord, String factoryId, Pageable pageable);




    @Query(value =
            " select ot.order_id as orderId,ot.total_order_weight as totalOrderWeight , COALESCE(ot.total_free_order_weight , 0)  as totalFreeOrderWeight , ot.total_order_amount as totalOrderAmount,at.agent_id,at.agent_name as agentName,\n" +
            " at.area as area,at.city as city,st.shop_id as shopId,st.shop_name as shopName,st.area as shopArea,st.city as shopCity,s.user_id as executiveId,\n" +
            " s.full_name as executiveName,s.area as executiveArea,s.city as executiveCity from order_table as ot inner join agent_table as at on ot.agent_id=at.agent_id\n" +
            " inner join shop_table as st on ot.shop_id=st.shop_id inner join staffs as s on ot.executive_id=s.user_id where ot.order_id=:orderId ",nativeQuery = true)
    OrderResponseModel findByOrderIdAndShop(String orderId);

    //-- counts of totalorders , yet to dispatch , dispatched ---//
    @Query(value = "SELECT    COUNT(DISTINCT ol.order_id) AS totalOrders , " +
            "               SUM(CASE WHEN ol.delivery_status = 'Yet to dispatch' THEN 1 ELSE 0 END) AS itemsToBeDispatched  , " +
            "               SUM(CASE WHEN ol.delivery_status = 'Dispatched' THEN 1 ELSE 0 END) AS itemsDispatched  " +
            "            FROM " +
            "               order_list_table ol " +
            "            WHERE " +
            "                ol.factory_id IS NOT NULL and ol.factory_id = :factoryId", nativeQuery = true)
    DispatchOrderDetailsDto totalDetails(String factoryId);


}
