package com.Oorvasi.Application.Entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Page;

@Getter
@Setter
public class ItemTrend {
    private ItemOrderSummaryDto ItemSummary;
    private Page<ItemTrendDto> ItemsTrends;
}
