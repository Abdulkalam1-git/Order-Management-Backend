package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.PaymentTypeModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/payment")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    //-not use in app--//
    @PreAuthorize("hasAnyAuthority('manage PayMent Type')")
    @PostMapping(value = "add/payment-type")
    public ResponseEntity<Response> makePayment(@RequestBody PaymentTypeModel paymentTypeModel){
        return paymentService.addPaymentType(paymentTypeModel);
    }
    @PreAuthorize("hasAnyAuthority('View PayMent Type')")
    @GetMapping(value = "/get/payment-types")
    public ResponseEntity<Response> getPaymentTypes(){
        return paymentService.getPaymentTypes();
    }
}
