package com.Oorvasi.Application.Model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinalizeOrderModel {

    private Double orderTotal;
    private Double Discounted;
    private Double discountPercent;
    private Double OldBalance;
    private Double newBalance;
}
