package com.Oorvasi.Application.Entity.Reports;


public interface AgentDetailsDTO {

    String getAgentId();
    String getAgentName();
    String getLocationId();
    String getState();
    String getCity();
    String getArea();
    Double getBalance();

}
