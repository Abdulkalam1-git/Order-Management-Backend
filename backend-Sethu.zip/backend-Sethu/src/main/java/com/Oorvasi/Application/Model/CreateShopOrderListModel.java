package com.Oorvasi.Application.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CreateShopOrderListModel {
    private Integer executiveId;
    private String executiveName;
    private String orderBy;
    private Integer items;
//    private Double totalOrderAmount;
    private Double totalOrderWeight;
    private Double totalFreeOrderWeight;
    private String shopId;
    private List<String> productId;
    private List<Integer> quantity;
//    private List<Double> amounts;
    private String createdBy;
    private String updateBy;
    private String updatedOn;

}
