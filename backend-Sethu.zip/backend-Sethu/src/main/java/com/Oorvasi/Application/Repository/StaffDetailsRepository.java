package com.Oorvasi.Application.Repository;

public interface StaffDetailsRepository {
    Long getUserId();
    String getUserName();
    String getRole();
}
