package com.Oorvasi.Application.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ProductDetailsDTO {

    private String productId;
    private String productName;
    private Double price;
    private Double weightPerUnit;
    private Integer unitPerBox;
    private Double boxWeight;
    private Boolean standard;
}
