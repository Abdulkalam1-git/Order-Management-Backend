package com.Oorvasi.Application.Entity;

public interface AgentOrderDetailsDto {
      String getOrderId();
     String getAgentId();
     String getAgentName();
     Long getTotalOrderAmount();
     String getStatus();




}
