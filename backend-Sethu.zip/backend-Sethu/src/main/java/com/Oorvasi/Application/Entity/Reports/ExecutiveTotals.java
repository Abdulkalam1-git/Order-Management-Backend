package com.Oorvasi.Application.Entity.Reports;

public interface ExecutiveTotals {

            Long getMarketingExecutives();
            Long getTotalOrders();

}
