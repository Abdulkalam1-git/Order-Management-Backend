package com.Oorvasi.Application.Configurations;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.security.interfaces.RSAPublicKey;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author arulmurugan
 *
 * The JWTAuthenticationFilters class is a Spring Security filter that intercepts incoming HTTP requests to verify the JWT
 * (JSON Web Token) in the Authorization header. The filter decodes the JWT, validates it using the JWKS (JSON Web Key Set)
 * provider, and populates the Spring Security context with the user's authentication details.
 *
 * <p>This class is designed to support OAuth2 authentication with Keycloak as the authorization server.
 * It verifies JWT tokens issued by Keycloak and extracts roles from the token to grant the user proper authorities.</p>
 *
 * <p>If the JWT is invalid or missing, the request will be rejected with a 401 Unauthorized status.</p>
 *
 * <p>This filter is executed once per request (via the {@link OncePerRequestFilter} base class).</p>
 */
@Data
@Component
@SuppressWarnings("unused")
@EqualsAndHashCode(callSuper = true)
public class JWTAuthenticationFilters extends OncePerRequestFilter {
    private static final Logger logger = LoggerFactory.getLogger(JWTAuthenticationFilters.class);

    @Value("${keycloak.tokens.access.audience}")                         
    private String audience;

    @Value("${application.oauth.resourceserver.jwt.issuer-uri}")         
    private String issuer;

    @Value("${application.oauth.resourceserver.jwt.jwk-set-uri}")        
    private String provider;

    private final JwkProvider jwkProvider;

    private static String AUTHORIZATION_HEADER ,TOKEN_TYPE ,  RESOURCE , ROLES;

    @Autowired
    private UserDetailsService userDetailsService;


    static {
      ROLES = "roles";
      RESOURCE = "email";
      TOKEN_TYPE = "Bearer";
   AUTHORIZATION_HEADER = "Authorization";
   }



    @Autowired 
    @Qualifier("handlerExceptionResolver")
    private HandlerExceptionResolver resolver;

    /**
     * Constructs a new JWTAuthenticationFilters instance and initializes the JWKS provider.
     *
     * @throws MalformedURLException if the JWKS URI is invalid.
     */
    public   JWTAuthenticationFilters () throws MalformedURLException {  jwkProvider = new JwkProviderBuilder(URI.create("https://auth.vinbytes.com/realms/Oorvasi/protocol/openid-connect/certs").toURL()).build();  }


    /**
     * Filters incoming HTTP requests to validate the JWT token present in the Authorization header.
     * If the token is valid, the user's authentication details are extracted and set in the Spring Security context.
     * If the token is invalid or missing, a 401 Unauthorized response is returned.
     *
     * @param request the HTTP request being processed.
     * @param response the HTTP response to be sent.
     * @param filterChain the filter chain to continue the request processing.
     * @throws java.io.IOException if an error occurs during token verification or request processing.
     */
    @Override
    protected void doFilterInternal(@lombok.NonNull HttpServletRequest request, @lombok.NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws IOException {
        try {
            final String authHeader = request.getHeader(AUTHORIZATION_HEADER);
            if (authHeader == null || !authHeader.startsWith(TOKEN_TYPE)) {
                filterChain.doFilter(request, response);
                return;
            }
            String token = authHeader.substring(7);
            DecodedJWT decodedJWT = JWT.decode(token);
            Jwk jwk = jwkProvider.get(decodedJWT.getKeyId());
            Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(issuer)
                    .withAudience(audience)
                    .build();
            verifier.verify(decodedJWT);
            String userId = decodedJWT.getClaim("user_id").asString();
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(userId);
            UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authToken);
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write(e.getMessage());
            resolver.resolveException(request,response,null,e);
        } 
    }

}
