package com.Oorvasi.Application.Entity.Reports;

public interface SalesOverTheYearByZone {

    String getLocationId();
          String getShortCode();
          Long getTotalSales();
          Long getTotalOrders();



}
