package com.Oorvasi.Application.Entity;

public interface ZoneByDto {
    String getZone();
    String getLocationId();
    String getZoneName();
    Long getTotalOrders();
    Long getTotalAgents();
    Long getTotalSales();
}
