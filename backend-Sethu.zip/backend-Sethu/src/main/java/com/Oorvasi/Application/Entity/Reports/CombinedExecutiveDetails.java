package com.Oorvasi.Application.Entity.Reports;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Page;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CombinedExecutiveDetails {
    private ExecutiveTotals executiveTotals;
    Page<ExecutiveDetails> executiveDetails;
}
