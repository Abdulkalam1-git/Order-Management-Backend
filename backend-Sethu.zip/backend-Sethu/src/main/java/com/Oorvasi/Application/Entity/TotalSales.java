package com.Oorvasi.Application.Entity;

public interface TotalSales {
    Long getTotalSales();
    Long getTotalOrder();
    Long getZones();
}
