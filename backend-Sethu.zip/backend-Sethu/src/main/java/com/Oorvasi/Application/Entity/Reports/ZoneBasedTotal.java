package com.Oorvasi.Application.Entity.Reports;

public interface ZoneBasedTotal {

              Long getTotalOrders();
              Long getTotalSales();
}
