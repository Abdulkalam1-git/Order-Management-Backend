package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.StaffModel;
import com.Oorvasi.Application.Model.LocationModel;
import com.Oorvasi.Application.Repository.LocationRepository;
import com.Oorvasi.Application.Repository.StaffDetailsRepository;
import com.Oorvasi.Application.Repository.StaffRepository;
import com.Oorvasi.Application.Repository.UserDetails;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.*;

@Slf4j
@Service
public class StaffService {
    @Autowired
    private StaffRepository staffRepository;


    @Autowired
    private LocationRepository locationRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired  Keycloak keycloak;
    @Value("${keycloak.realm}") private String realms;

    private JwkProvider jwkProvider;

    @Value("${application.oauth.resourceserver.jwt.issuer-uri}")
    private String issuer;

    @Value("${application.oauth.resourceserver.jwt.jwk-set-uri}")
    private String provider;
    @Value("${keycloak.tokens.access.audience}")
    private String audience;

    public ResponseEntity<Response> createStaff(StaffModel staffModel){
        Response response = new Response();
        System.out.println(staffModel);
        try {
            if (staffRepository.existsByPhoneNumber(staffModel.getPhoneNumber())) {
                response.setStatus("Failure");
                response.setResponseMessage("Phone number already exists.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            if ("HO Team".equalsIgnoreCase(staffModel.getTeam())) {
                if (!"HO Admin".equalsIgnoreCase(staffModel.getDesignation())) {
                    response.setStatus("Failure");
                    response.setResponseMessage("A member of HO Team must have the designation 'HO Admin'.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
            }
            else if ("Sales Team".equalsIgnoreCase(staffModel.getTeam())) {
                if (!"Sales Manager".equalsIgnoreCase(staffModel.getDesignation()) &&
                        !"Sales Executive".equalsIgnoreCase(staffModel.getDesignation())) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Sales Team Team members must have the designation 'Sales Manager' or 'Sales Executive'.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
            }
            else{
                response.setStatus("Failure");
                response.setResponseMessage("Team unavailable'.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            if (staffModel.getLocationModel() != null && staffModel.getLocationModel().getLocationId() != null) {
                Optional <LocationModel> locationModel = locationRepository.findByLocationId(staffModel.getLocationModel().getLocationId());
                if (locationModel.isEmpty()) {
                    response.setStatus("Failure");
                    response.setData(Collections.singletonList(locationModel));
                    response.setResponseMessage("Invalid locationId. The specified location does not exist." + locationModel);
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
                staffModel.setLocationModel(locationModel.get());
            }

            staffModel.setCreatedOn(new Date());
            staffModel.setPassword(passwordEncoder.encode(staffModel.getPassword()));
            staffRepository.save(staffModel);
            boolean execution =  makers(staffModel);
            response.setStatus("Success");
            response.setData(Collections.singletonList(staffModel));
            response.setExecution(execution ? "The user added in keycloak successfully!" : "The user not added in keycloak");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        }
        catch (DataIntegrityViolationException e) {
            String detailedMessage = e.getRootCause() != null ? e.getRootCause().getMessage() : e.getMessage();
            if (detailedMessage.contains("violates foreign key constraint")) {
                String responseMessage = "The specified Role does not exist. Please check the Role.";
                response.setStatus("Failure");
                response.setResponseMessage(responseMessage);
            } else {
                log.warn(e.getMessage());
                response.setStatus("Failure");
                response.setResponseMessage("An error occurred while creating the Staff.");
            }
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        catch(Exception err){
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled Error: " + err.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    private boolean makers (StaffModel staff) {
        UserRepresentation representation = new UserRepresentation();
        representation.setUsername(staff.getUserName());
        // representation.setEmail(staff.getEmail());
        representation.setEnabled(true);
        representation.setEmailVerified(false);
        representation.setEmail(staff.getEmail());
        CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
        credentialRepresentation.setTemporary(false);
        credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
        credentialRepresentation.setValue(staff.getPassword());
        credentialRepresentation.setUserLabel(CredentialRepresentation.PASSWORD);
        representation.setCredentials(Collections.singletonList(credentialRepresentation));
        String[] names = staff.getFullName().split(" ");
        representation.setFirstName(names[0]);
        Map<String, List<String>> attributes = new HashMap<>();
        attributes.put("mobile_number", List.of(staff.getPhoneNumber()));
        attributes.put("designation", List.of(staff.getDesignation()));
        attributes.put("user_id", List.of(String.valueOf(staff.getUserId())));
        representation.setAttributes(attributes);
        UsersResource usersResource = getUserResources();
        try (jakarta.ws.rs.core.Response responses = usersResource.create(representation) ) {
            log.warn("{} and {} ", responses.getStatus(),responses.getStatusInfo());
            return responses.getStatus() == 201;
        } catch (Exception e) {   log.error(" The exception occurred  {} ", e.getMessage());    }
        return false;
    }

    UsersResource getUserResources () { return keycloak.realm(realms).users();  }

    public String get (String name) {    return name.replaceAll(" ", "").toLowerCase();     }

    public ResponseEntity<Response> getAllStaffs(String keyword,@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable){
        Response responses=new Response();
        try {
            Page<StaffDetailsRepository> staffModels = staffRepository.findByKeyword(keyword,pageable);
            if (staffModels.isEmpty()) {
                responses.setStatus("Failure");
                responses.setResponseMessage("No Data");
                return new ResponseEntity<>(responses, HttpStatus.NOT_FOUND);
            } else {
                responses.setStatus("Success");
                responses.setDatas(staffModels);
                return new ResponseEntity<>(responses, HttpStatus.OK);

            }
        }
        catch (Exception e){
            responses.setStatus("Failure");
            responses.setResponseMessage(e.getLocalizedMessage());
            return new ResponseEntity<>(responses, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getStaffById(String authorizationHeader) {
        Response response = new Response();
        try {
            DecodedJWT decodedJWT = JWT.decode(authorizationHeader.substring("Bearer ".length()));
            String userId = decodedJWT.getClaim("user_id").asString();
            UserDetails staffModel = staffRepository.findByStaffId(Long.valueOf(userId));
            response.setStatus("Success");
            response.setResponseMessage("Staff listed for User ID:"+userId);
            response.setUserDetails(staffModel);
            return new ResponseEntity<>(response,HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error fetching staff by role: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getStaffByDesignation(String designation) {
        System.out.println(designation);
        Response response = new Response();
        try {
            List<StaffModel> staffModels = staffRepository.findByDesignation(designation);
            if (staffModels.isEmpty()) {
                response.setStatus("Failure");
                response.setResponseMessage("No staff found with the designation: " + designation);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            response.setStatus("Success");
            response.setResponseMessage("Staff listed for designation: " + designation);
            response.setData(staffModels);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error fetching staff by designation: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> getStaffsByLocation(String locationId,String keyword,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<UserDetails> staffModels = staffRepository.findByLocationId(locationId,keyword,pageable);
            if (staffModels.isEmpty()) {
                response.setStatus("Failure");
                response.setResponseMessage("No staff found with the location: " + locationId);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            response.setStatus("Success");
            response.setResponseMessage("Staff listed for location: " + locationId);
            response.setDatas(staffModels);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error fetching staff by designation: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getStaffByTeam(String team) {
        Response response = new Response();
        try {
            List<StaffModel> staffModels = staffRepository.findByTeam(team);
            if (staffModels.isEmpty()) {
                response.setStatus("Failure");
                response.setResponseMessage("No staff found in the team: " + team);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            response.setStatus("Success");
            response.setResponseMessage("Staff listed for team: " + team);
            response.setData(staffModels);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error fetching staff by team: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> updateStaff(StaffModel updatedStaffModel) {
        Response response = new Response();
        try {
            StaffModel existingStaff = staffRepository.findById(updatedStaffModel.getUserId()).orElse(null);
            if (existingStaff == null) {
                response.setStatus("Failure");
                response.setResponseMessage("Staff with ID " + updatedStaffModel.getUserId() + " not found.");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            if (!existingStaff.getPhoneNumber().equals(updatedStaffModel.getPhoneNumber()) &&
                    staffRepository.existsByPhoneNumber(updatedStaffModel.getPhoneNumber())) {
                response.setStatus("Failure");
                response.setResponseMessage("Phone number already exists.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            if ("HO Team".equalsIgnoreCase(updatedStaffModel.getTeam())) {
                if (!"HO Admin".equalsIgnoreCase(updatedStaffModel.getDesignation())) {
                    response.setStatus("Failure");
                    response.setResponseMessage("A member of HO Team must have the designation 'HO Admin'.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
            } else if ("Sales Team".equalsIgnoreCase(updatedStaffModel.getTeam())) {
                if (!"Sales Manager".equalsIgnoreCase(updatedStaffModel.getDesignation()) &&
                        !"Sales Executive".equalsIgnoreCase(updatedStaffModel.getDesignation())) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Sales Team members must have the designation 'Sales Manager' or 'Sales Executive'.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
            } else {
                response.setStatus("Failure");
                response.setResponseMessage("Team unavailable.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            if (updatedStaffModel.getLocationModel() != null && updatedStaffModel.getLocationModel().getLocationId() != null) {
                Optional<LocationModel> locationModel = locationRepository.findByLocationId(updatedStaffModel.getLocationModel().getLocationId());
                if (locationModel.isEmpty()) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Invalid locationId. The specified location does not exist.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
                existingStaff.setLocationModel(locationModel.get());
            }
            existingStaff.setUserName(updatedStaffModel.getUserName());
            existingStaff.setFullName(updatedStaffModel.getFullName());
            existingStaff.setPhoneNumber(updatedStaffModel.getPhoneNumber());
            existingStaff.setRole(updatedStaffModel.getRole());
            existingStaff.setTeam(updatedStaffModel.getTeam());
            existingStaff.setDesignation(updatedStaffModel.getDesignation());
            existingStaff.setState(updatedStaffModel.getState());
            existingStaff.setCity(updatedStaffModel.getCity());
            existingStaff.setArea(updatedStaffModel.getArea());
            existingStaff.setPassword(passwordEncoder.encode(existingStaff.getPassword()));
            existingStaff.setStatus(updatedStaffModel.getStatus());
            existingStaff.setUpdatedOn(new Date());
            // existingStaff.setUpdatedBy("Admin");
            staffRepository.save(existingStaff);
            response.setStatus("Success");
            response.setResponseMessage("Staff details updated successfully.");
            response.setData(Collections.singletonList(existingStaff));
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error occurred while updating the staff: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
