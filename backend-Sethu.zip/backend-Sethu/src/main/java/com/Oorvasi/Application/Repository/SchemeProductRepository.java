package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.SchemeGlobalDto;
import com.Oorvasi.Application.Entity.SchemesGetByProductId;
import com.Oorvasi.Application.Model.SchemeProductsModel;
import com.Oorvasi.Application.Model.SchemesModel;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface SchemeProductRepository extends JpaRepository<SchemeProductsModel , String> {

    SchemeProductsModel findFirstByOrderByCreatedAtDesc();

    List<SchemeProductsModel> findByStatus(String Status);

    Optional<SchemeProductsModel> findBySchemeProductIdAndDeletedAtIsNull(String schemeProductId);


    @Query(value = """
    SELECT 
        s.scheme_id AS schemeId,
        s.description AS description,
        s.start_date AS startDate,
        s.end_date AS endDate,
        s.is_active AS isActive,
        s.is_global AS isGlobal,
        s.scheme_name AS schemeName,
        sr.scheme_product_id AS schemeProductId,
        sr.product_id AS productId,
        sp.scheme_rule_id AS schemeRuleId,
        sp.condition_type AS conditionType,
        sp.condition_value AS conditionValue,
        sp.reward_value AS rewardValue,
        sp.free_product_id AS freeProductId,
        -- Handle product details even when freeProductId is NULL
        CASE 
            WHEN sp.free_product_id IS NULL THEN NULL
            ELSE p.product_name
        END AS productName,
        CASE 
            WHEN sp.free_product_id IS NULL THEN NULL
            ELSE p.standard
        END AS standard,
        CASE 
            WHEN sp.free_product_id IS NULL THEN NULL
            ELSE p.box_weight
        END AS boxWeight,
        CASE 
            WHEN sp.free_product_id IS NULL THEN NULL
            ELSE p.price
        END AS price,
        CASE 
            WHEN sp.free_product_id IS NULL THEN NULL
            ELSE p.weight_per_unit
        END AS weightPerUnit,
        CASE 
            WHEN sp.free_product_id IS NULL THEN NULL
            ELSE p.unit_per_box
        END AS unitPerBox
    FROM 
        schemes_table AS s
    JOIN 
        scheme_products_table AS sr ON s.scheme_id = sr.scheme_id
    JOIN 
        scheme_rules_table AS sp ON s.scheme_id = sp.scheme_id
    LEFT JOIN 
        product_table AS p ON COALESCE(sp.free_product_id , null) = p.product_id
    WHERE 

         sr.product_id = :productId
    """, nativeQuery = true)
    List<SchemesGetByProductId> fetchSchemeDetails(@Param("productId") String productId);



    @Query(value = """
            
            SELECT\s
                s.scheme_id AS schemeId,
                s.description AS description,
                s.start_date AS startDate,
                s.end_date AS endDate,
                s.is_active AS isActive,
                s.is_global AS isGlobal,
                s.scheme_name AS schemeName,
                sp.scheme_rule_id AS schemeRuleId,
                sp.condition_type AS conditionType,
                sp.condition_value AS conditionValue,
                sp.reward_value AS rewardValue,
                sp.free_product_id AS freeProductId,
                p.product_name AS productName,
                p.standard AS standard,
                p.box_weight AS boxWeight,
                p.price AS price,
                p.weight_per_unit AS weightPerUnit,
                p.unit_per_box AS unitPerBox
            FROM\s
                schemes_table AS s
            
            JOIN\s
                scheme_rules_table AS sp ON s.scheme_id = sp.scheme_id
            LEFT JOIN\s
                product_table AS p on
                                     sp.free_product_id = p.product_id
            WHERE\s
                s.status iLike 'active'  and s.is_active is true
    """, nativeQuery = true)
    List<SchemeGlobalDto>  fetchGlobalDetails();



    @EntityGraph(attributePaths = {"schemesModel", "schemesModel.schemeRulesModel", "schemesModel.schemeRulesModel.productModel"})
    @Query("SELECT spm FROM SchemeProductsModel spm " +
            "JOIN spm.schemesModel s " +
            "WHERE spm.productModel.productId = :productId " +
            "AND s.startDate >= :startDate AND s.endDate <= :endDate")
    List<SchemeProductsModel> findByProductModel_ProductId(
            @Param("productId") String productId,
            @Param("startDate") Date startDate,
            @Param("endDate") Date endDate);




}
