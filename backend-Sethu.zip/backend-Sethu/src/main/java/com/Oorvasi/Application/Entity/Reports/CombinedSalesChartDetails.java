package com.Oorvasi.Application.Entity.Reports;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter

public class CombinedSalesChartDetails {

    private List<SalesChartDto> SalesOverTheYear;
    private List<SalesOverTheYearByZone> zones;
}
