package com.Oorvasi.Application.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CreateProductModel {
    private String productId;
    private String productName;
    private Double price;
    private Double weightPerUnit;
    private Integer unitPerBox;
    private Double boxWeight;
    private Date createdOn = new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
    private Boolean standard;
    private List<String> locationId;
    private List<Double> locationPrice;
}
