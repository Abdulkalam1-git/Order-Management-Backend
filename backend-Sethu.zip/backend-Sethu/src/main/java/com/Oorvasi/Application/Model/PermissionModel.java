package com.Oorvasi.Application.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "permission_table")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PermissionModel {
    @Id
    private String permissionId;
    private String permissionGroup;
    private String permissionName;
    @Column(name = "status")
    private String status;
    @Column(name = "created_on")
    private Date createdOn = new Date();
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "updated_on")
    private Date updatedOn;
    @Column(name = "updated_by")
    private String updatedBy;
}
