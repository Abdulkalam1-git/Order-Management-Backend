package com.Oorvasi.Application.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;



    @Entity
    @Table(name = "user_role_table")
    @NoArgsConstructor
    @AllArgsConstructor
    @Getter
    @Setter
    public class UserRoleModel {

        @Id
        @Column(name = "user_role_id")
        private String userRoleId;
        @Column(name = "user_id")
        private String userId;
        @Column(name = "role_id")
        private String roleId;
        @Column(name = "status")
        private String status;
        @Column(name = "created_on")
        private Date createdOn = new Date();
        @Column(name = "created_by")
        private String createdBy;
        @Column(name = "updated_on")
        private Date updatedOn;
        @Column(name = "updated_by")
        private String updatedBy;
    }

