package com.Oorvasi.Application.Entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Page;

@Setter
@Getter
public class AgentPerformanceTotal {
    AgentSummary AgentSummary;
    Page<AgentPerformanceDto> AgentPerformance;
}
