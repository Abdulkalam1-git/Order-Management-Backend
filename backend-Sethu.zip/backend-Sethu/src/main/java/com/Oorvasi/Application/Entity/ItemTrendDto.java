package com.Oorvasi.Application.Entity;

public interface ItemTrendDto {
    String getItem();
    String getProductId();
    String getFactoryId();
    Long getOrders();
    Long getSales();
}
