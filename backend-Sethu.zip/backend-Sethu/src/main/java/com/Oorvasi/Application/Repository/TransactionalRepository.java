package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.TransActionModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionalRepository extends JpaRepository<TransActionModel,String> {
    TransActionModel findFirstByOrderByCreatedOnDesc();

    boolean existsByTransactionId(String agentId);
}
