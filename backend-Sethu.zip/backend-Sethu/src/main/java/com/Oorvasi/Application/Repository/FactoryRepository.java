package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.FactoryDto;
import com.Oorvasi.Application.Model.FactoryModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FactoryRepository extends JpaRepository<FactoryModel,String> {

    List<FactoryModel>  findByfactoryNameContainingIgnoreCase (String keyWord);
    FactoryModel findByFactoryId(String factoryId);


    @Query(value = "SELECT l.factory_name AS FactoryName, l.short_code AS ShortCode " +
            "FROM factory_table l " +
            "WHERE l.status iLIKE 'active' " +
            "AND (:keyWord IS NULL " +
            "OR l.factory_name iLIKE %:keyWord% " +
            "OR l.short_code iLIKE %:keyWord% " +
            "OR l.factory_id iLIKE %:keyWord% " +
            "OR (:keyWord = l.factory_id))",
            nativeQuery = true)
    List<FactoryDto> getAllFactory(String keyWord);
    boolean existsByFactoryNameIgnoreCase(String factoryName);

    boolean existsByFactoryNameIgnoreCaseAndFactoryIdNot(String factoryName, String factoryId);
    boolean existsByShortCodeIgnoreCaseAndFactoryIdNot(String shortCode, String factoryId);


    FactoryModel findTop1ByOrderByCreatedOnDesc();

    boolean existsByFactoryId(String factoryId);

    @Query(value = "Select * from factory_table where factory_name ilike  %:factoryName",nativeQuery = true)
    FactoryModel findByFactoryName(String factoryName);

    @Query(value = "Select * from factory_table where short_code ilike  %:shortCode",nativeQuery = true)
    FactoryModel findByFactoryShortCode(String shortCode);
}
