package com.Oorvasi.Application.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_table")
public class UserModel {

    @Id
    private String userId;
    private String userName;
    private String empId;
    private String email;
    private String phoneNo;
    private UserRoleEnum role= UserRoleEnum.ADMIN;
    private String status;
    private Date createdOn;
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;

}
