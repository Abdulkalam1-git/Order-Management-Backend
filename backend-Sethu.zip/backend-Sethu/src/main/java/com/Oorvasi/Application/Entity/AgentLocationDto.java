package com.Oorvasi.Application.Entity;

public interface AgentLocationDto {

    String getAgentName();
    String getArea();
    String getAgentId();
    String getCity();
    String getState();

}
