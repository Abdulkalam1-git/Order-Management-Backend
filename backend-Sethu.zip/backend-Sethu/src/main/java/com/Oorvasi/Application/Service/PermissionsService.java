package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.PermissionModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.Role;
import com.Oorvasi.Application.Repository.PermissionsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
public class PermissionsService {

    @Autowired
    private PermissionsRepository permissionsRepository;

    public ResponseEntity<Response>createPermissions(PermissionModel permissionModel) {
        Response response = new Response();
        try {
            if (permissionsRepository.existsByPermissionName(permissionModel.getPermissionName())) {
                response.setStatus("Failure");
                response.setResponseMessage("Permission name already exists.");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            long length = permissionsRepository.count();
            String PermissionId = "P" + String.format("%04d", length + 1);
            permissionModel.setPermissionId(PermissionId);
            permissionsRepository.save(permissionModel);
            response.setStatus("Success");
            response.setResponseMessage("Permission Created successfully");
            response.setData(Collections.singletonList(permissionModel));
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error occurred while Creating Permission: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAllPermissions(){
        Response responses=new Response();
        try{
            List<PermissionModel> permissions =  permissionsRepository.findAll();
            responses.setStatus("Success");
            responses.setResponseMessage("Retrieved all Permissions Successfully");
            responses.setData(permissions);
            return new ResponseEntity<>(responses, HttpStatus.OK);
        }
        catch (Exception e){
            responses.setStatus("Failure");
            responses.setResponseMessage(e.getLocalizedMessage());
            return new ResponseEntity<>(responses, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getAuthenticatedUserRole() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Objects.requireNonNull(authentication, "The user is not authenticated!");

        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

        // Extract role from authorities
        String roleId = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .filter(auth -> auth.startsWith("ROLE_"))
                .map(auth -> auth.replace("ROLE_", "")) // Remove prefix
                .findFirst()
                .orElse("UNKNOWN_ROLE");

        // Extract permissions (excluding role)
        List<String> grantedPermissions = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .filter(permission -> !permission.startsWith("ROLE_")) // Exclude role names
                .toList();

        // Manual permission grouping
        Map<String, List<String>> groupedPermissions = new LinkedHashMap<>();

        // Define manual groupings
        Map<String, List<String>> permissionGroups = new HashMap<>();
        permissionGroups.put("Create_order", List.of("View Zone", "View Zone Agent", "View Items" , "Create Order"));
        permissionGroups.put("Sales_order", List.of("View Zone", "View Zone Shop", "View SalesExecutive" , "View SalesOrder" , "Create SalesOrder","View Single ShopOrder" , "View ShopOrder Detail" , "Assign Agent", "View All Agent","View Recommended Agent"));
        permissionGroups.put("Factory_planning", List.of("view OrderItems","View Single OrderDetail" , "Assign Factory", "View Factory" , "Edit Order"));
        permissionGroups.put("Dispatch", List.of("View Factory" ,"View Single OrderDetail" , "Update Delivery Status", "View DispatchCount", "View DispatchItems"));
        permissionGroups.put("Finalize", List.of("view Finalize Detail", "View Single OrderDetail", "Update Order Finalize", "View Finalize Balance Details"));
        permissionGroups.put("Closed_orders", List.of("View Single OrderDetail", "View ClosedOrders"));
        permissionGroups.put("Make_payment", List.of("Make PayMent" ,"View PayMent Type" , "View Single Agent" , "View Final PayMent"));

        // Iterate over granted permissions and map them to the defined groups
        for (Map.Entry<String, List<String>> entry : permissionGroups.entrySet()) {
            String groupName = entry.getKey();
            List<String> permissionList = entry.getValue();

            List<String> assignedPermissions = grantedPermissions.stream()
                    .filter(permissionList::contains)
                    .toList();

            if (!assignedPermissions.isEmpty()) {
                groupedPermissions.put(groupName, assignedPermissions);
            }
        }

        // Log for debugging
        System.out.println("Extracted Role ID: " + roleId);
        System.out.println("Grouped Permissions: " + groupedPermissions);

        // Response structure
        Map<String, Object> response = new HashMap<>();
        response.put("roleId", roleId);
        response.put("permissions", groupedPermissions);

        return ResponseEntity.ok(response);
    }
}
