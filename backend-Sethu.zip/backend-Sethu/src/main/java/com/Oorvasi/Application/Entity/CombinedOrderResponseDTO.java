package com.Oorvasi.Application.Entity;

import com.Oorvasi.Application.Entity.Reports.ZoneBasedTotal;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Page;

@Setter
@Getter
public class CombinedOrderResponseDTO {
    private ZoneBasedTotal orderSummary;
    private Page<OrderByDto> orderStats;


}
