package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.AgentLocationDto;
import com.Oorvasi.Application.Entity.ShopGetDto;
import com.Oorvasi.Application.Model.ShopModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import java.util.List;
import java.util.Optional;

public interface ShopRepository extends JpaRepository<ShopModel, String> {


    ShopModel findFirstByOrderByCreatedOnDesc();

    ShopModel findByShopId(String shopId);

    @Query(value = "SELECT * FROM shop_table WHERE shop_name iLike :shopName", nativeQuery = true)
    ShopModel existsByShopName(String shopName);

    Optional<ShopModel> findByShopNameIgnoreCase(String shopName);


    @Query(value = "SELECT s.shop_id as shopId,s.shop_name , s.city , s.area " +
            "FROM shop_table s " +
            "WHERE s.status iLIKE 'active' " +
            "AND (:keyWord IS NULL " +
            "OR s.shop_name iLIKE %:keyWord% " +
            "OR s.city iLIKE %:keyWord% " +
            "OR s.area iLIKE %:keyWord% " +
            "OR s.shop_id iLike %:keyWord% " +
            "OR (:keyWord = s.shop_id))", nativeQuery = true)
    List<ShopGetDto> getShop(String keyWord);

    @Query(value = "SELECT s.shop_name , s.city , s.area,l.location_name ,s.state " +
            "FROM shop_table s inner join location_table as l on s.location_id=l.location_id " +
            "WHERE s.status iLIKE 'active' " +
            "and s.shop_id = :shopId", nativeQuery = true)
    ShopGetDto getByShopId(String shopId);


    @Query(value = "select shop_id as shopId,shop_name as shopName, city as city,area as area,state as state from shop_table where location_id=:locationId ", nativeQuery = true)
    Page<ShopGetDto> findByLocationId(String locationId, Pageable pageable);

    @Query(value = "select a.agent_id as agentId,a.city as city, a.state as state,a.agent_name as AgentName ,a.area as area from  location_table as l " +
            "join agent_table as a  on a.location_id = l.location_id  " +
            " join shop_table as s on s.location_id = l.location_id  " +
            "where s.shop_id = :shopId and a.agent_name iLike %:keyWord% ", nativeQuery = true)
    List<AgentLocationDto> FindPriorityAgents(String shopId, String keyWord);

    @Query(value = "select a.agent_name as AgentName ,a.city as city, a.state as state ,a.agent_id as agentId,a.area as area " +
            " from  location_table as l " +
            "left join agent_table as a " +
            "on a.location_id = l.location_id where a.agent_name iLike %:keyWord%  ", nativeQuery = true)
    Page<AgentLocationDto> FindAllAgents(String keyWord,Pageable pageable);







}
