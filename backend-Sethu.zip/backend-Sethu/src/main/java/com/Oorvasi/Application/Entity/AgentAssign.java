package com.Oorvasi.Application.Entity;

import lombok.*;

import java.util.List;


@NoArgsConstructor
@Setter
@Getter
public class AgentAssign {
    public List<AgentLocationDto> recommendedAgents;
    public List<AgentLocationDto> allAgents;

}
