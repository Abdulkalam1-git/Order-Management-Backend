package com.Oorvasi.Application.Model;



import java.sql.Timestamp;

public interface AgentMonthlyReportModel {

 Timestamp getMonth();
 long getTotalAmount();

}
