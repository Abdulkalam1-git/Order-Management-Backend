package com.Oorvasi.Application.Entity;

public interface ItemDto {

    String getProductName();
    Double getPrice();
    Double getWeightPerUnit();
    String getProductId();
}
