package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.PermissionModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.PermissionsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

@RequestMapping (value ="/permissions")
public class PermissionsController {

    @Autowired
    private PermissionsService permissionsService;

    @PreAuthorize("hasAnyAuthority('manage Permission')")
    @PostMapping("create/permission")
    private ResponseEntity<Response> createPermission(@RequestBody PermissionModel permissionModel){
        return permissionsService.createPermissions(permissionModel);
    }

    @PreAuthorize("hasAnyAuthority('View Permission')")
    @GetMapping("get/permissions")
    public ResponseEntity<Response> getRoles(){
        return permissionsService.getAllPermissions();
    }


    @PreAuthorize("hasAnyAuthority('View PermissionContext')")
    @GetMapping("/get/context")public ResponseEntity<?> getContext () {
        return permissionsService.getAuthenticatedUserRole();
    }
}
