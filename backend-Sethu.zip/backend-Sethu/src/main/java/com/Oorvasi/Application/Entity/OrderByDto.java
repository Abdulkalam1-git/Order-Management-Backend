package com.Oorvasi.Application.Entity;

public interface OrderByDto {
    String getOrderId();

    String getAgentId();

    String getAgentName();

    String getLocationId();

    String getZone();

    Long getTotalOrderAmount();
}
