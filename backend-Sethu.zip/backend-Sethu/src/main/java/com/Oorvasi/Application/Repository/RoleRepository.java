package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.AgentModel;
import com.Oorvasi.Application.Model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,String>{
    Boolean existsByRole(String role);

    Role findTop1ByRoleIdContainingOrderByCreatedOnDesc(String agentIdRegex);

    boolean existsByRoleId(String roleId);
}
