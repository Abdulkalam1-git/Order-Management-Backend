package com.Oorvasi.Application.Entity;

import com.Oorvasi.Application.Entity.Reports.ZoneBasedTotal;
import com.Oorvasi.Application.Model.AgentMonthlyReportModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
    public class CombinedBarDetails {

    private ZoneBasedTotal totalDetails;
    private List<AgentMonthlyReportModel> agentBarDetails ;


}
