package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "report")
public class ReportController {

    @Autowired
    private ReportService reportsService;

    //--1--//

    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/sales-current-Month")
    public ResponseEntity<Response> getSalesForMonth() {
        return reportsService.salesForMonth();
    }

    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/monthlySales-GroupBy-Year")
    public ResponseEntity<Response> getMonthlySalesGroupByYear(@RequestParam int year) {
        return reportsService.monthlySalesGroupByYear(year);
    }

    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/zoneBy-TotalSalesChart")
    public ResponseEntity<Response> getZoneByTotalSalesChart(@RequestParam int year, @RequestParam String locationId) {
        return reportsService.SalesChart(year, locationId);
    }

    //--2 --//
    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/zone-Summary")
    public ResponseEntity<Response> getZoneDetails(@RequestParam String startDate,
                                                   @RequestParam String endDate,
                                                   @PageableDefault(page = 0, size = 10) Pageable pageable) {
        return reportsService.getZoneDetails(startDate, endDate, pageable);
    }

    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/zone-Details")
    public ResponseEntity<Response> getZoneOrderDetails(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam String locationId,
            @PageableDefault(page = 0, size = 10) Pageable pageable) {
        return reportsService.getZoneOrderDetails(startDate, endDate, pageable, locationId);
    }

    //--3 -- //
    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/item-trends")
    public ResponseEntity<Response> getItemDetails(
            @RequestParam("startDate") String startDate,
            @RequestParam("endDate") String endDate,
            @RequestParam("factoryId") String factoryId,
            @PageableDefault(page = 0, size = 10) Pageable pageable) {
        return reportsService.ItemTrends(startDate, endDate, pageable, factoryId);

    }

    //--4--//
    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/agent-performance")
    public ResponseEntity<Response> getAgentPerformance(
            @RequestParam("startDate") String startDate,
            @RequestParam("endDate") String endDate,
            @RequestParam("locationId") String locationId,
            @PageableDefault(page = 0, size = 10) Pageable pageable) {
        return reportsService.agentPerformance(startDate, endDate, locationId, pageable);
    }

    //--5--//
    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/agent-OutStanding")
    public ResponseEntity<Response> getAgentOutStanding(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam(defaultValue = "") String locationId,
            @PageableDefault(page = 0, size = 10) Pageable pageable) {
        return reportsService.fetchAgentSummary(startDate, endDate, locationId, pageable);
    }

    //-- 6 -- //

    @PreAuthorize("hasAnyAuthority('View Reports')")
    @GetMapping("get/executive-Total")
    public ResponseEntity<Response> getExecutiveTotal(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam String locationId,
            @PageableDefault(page = 0, size = 10) Pageable pageable) {
        return reportsService.getExecutiveTotals(startDate, endDate, locationId, pageable);
    }

}