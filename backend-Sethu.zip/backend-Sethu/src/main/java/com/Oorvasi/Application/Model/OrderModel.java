package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "order_table")
public class OrderModel {

    @Id
    private String orderId;
    @OneToOne
    @JoinColumn(name = "agent_id",nullable = false)
    AgentModel agentModel;
    private String orderBy;
    private Date orderOn = new Date();
    private Integer items;
    private Double totalOrderAmount;
    private Double totalOrderWeight;
    private Double totalFreeOrderWeight;
    @OneToOne
    @JoinColumn(name = "shop_id")
    ShopModel shopModel;
    private String status;
    private Date createdOn= new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
    private Integer executiveId;
}
