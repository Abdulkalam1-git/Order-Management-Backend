package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.antlr.v4.runtime.misc.NotNull;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "product_table")
public class ProductModel {

    @Id
    private String productId;
    private String productName;
    private Double price;
    private Double weightPerUnit;
    private Integer unitPerBox;
    private Double boxWeight;
    private String status;
    private Date createdOn = new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
    private Boolean Standard; //---true means standard price Or --false means  price , location based price ---//

}
