package com.Oorvasi.Application.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransActionAndPaymentModel {
    private String agentId;
    private String agentServiceLimitId;
    private List<String> paymentTypeId;
    private String receivedBy;
    private Double amount;
    private String createdBy;
    private String referenceNo;
    private List<Double> amounts;
}
