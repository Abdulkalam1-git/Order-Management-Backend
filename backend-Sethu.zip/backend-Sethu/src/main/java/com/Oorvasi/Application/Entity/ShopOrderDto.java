package com.Oorvasi.Application.Entity;

import java.math.BigInteger;

public interface ShopOrderDto {

      String getShopId();
      String getShopName();
      Double getTotalOrderWeight();
      Double getTotalOrderAmount();
      Double getTotalFreeOrderWeight();
      String getTempId();
      String getExecutiveName();
      Integer getExecutiveId();



}
