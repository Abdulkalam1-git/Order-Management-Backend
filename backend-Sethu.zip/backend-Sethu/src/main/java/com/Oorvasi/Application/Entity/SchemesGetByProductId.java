package com.Oorvasi.Application.Entity;

import org.springframework.lang.Nullable;

public interface SchemesGetByProductId {
    String getSchemeId();
    String getDescription();
    String getSchemeRuleId();
    String getConditionType();
    Double getConditionValue();
    String getRewardValue();
    String getSchemeName();
    String getStartDate();
    String getEndDate();
    Boolean getIsActive();
    Boolean getIsGlobal();
    String getSchemeProductId();
    String getProductId();
    String getFreeProductId();
    @Nullable
    String getProductName();
    @Nullable Double getPrice();
    @Nullable Boolean getStandard();
    @Nullable Integer getUnitPerBox();
    @Nullable Double getBoxWeight();
    @Nullable Double getWeightPerUnit();
}
