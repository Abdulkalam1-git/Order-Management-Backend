package com.Oorvasi.Application.Repository;


import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Entity.Reports.*;
import com.Oorvasi.Application.Model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;
import java.util.Objects;

public interface AgentRepository extends JpaRepository<AgentModel, String> {

    AgentModel findTop1ByAgentIdContainingOrderByCreatedOnDesc(String regex);

    AgentModel findByAgentId(String agentId);

    Boolean existsByAgentId(String agentId);

    @Query(value = "select at.agent_id as agentId,at.agent_name as agentName,at.area as area,at.city as city,at.state as state ,\n" +
            "CASE WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount WHEN al.excess_amount <> 0 THEN al.excess_amount ELSE 0 \n" +
            "END AS agentBalance from agent_table as at Inner join  agent_service_limit_table al ON at.agent_id = al.agent_id where at.location_id=:locationId ", nativeQuery = true)
    Page<AgentPersonalData> findByLocation_Id(String locationId, Pageable pageable);

    @Query(value = "select at.agent_id as agentId,at.agent_name as agentName,at.area as area,at.city as city,at.state as state ,\n" +
            "        CASE WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount WHEN al.excess_amount <> 0 THEN al.excess_amount ELSE 0 \n" +
            "        END AS agentBalance from agent_table as at Inner join  agent_service_limit_table al ON at.agent_id = al.agent_id where location_id=:locationId and (at.agent_name Ilike %:keyword% or at.area ilike %:keyword%) ", nativeQuery = true)
    Page<AgentPersonalData> findByLocation_Ids(String locationId, String keyword, Pageable pageable);

    List<AgentModel> findByAgentNameContainingIgnoreCase(String search);

    AgentModel findByEmail(String email);

    @Query(value = "select * from order_table where agent_id=:agentId and status <> 'Finalize'", nativeQuery = true)
    List<Object[]> findByAgentStatusAndId(String agentId);

    AgentModel findByPhoneNo(String phoneNo);



    @Query(value = "select count(order_id) as count, sum(total_order_amount) as totalSalesAmount from order_table\n" +
            "where agent_id=:agentId", nativeQuery = true)
    AgentReportModel findAgentReport(String agentId);

    @Query(value = "select count(order_id) as count, sum(total_order_amount) as totalSalesAmount from order_table\n" +
            "where agent_id=:agentId and created_on between :startDate and :endDate ", nativeQuery = true)
    AgentReportModel findAgentReportSingleMonth(String agentId, Date startDate, Date endDate);


    //4 //-------- agent performance --- //


    //-- 4 -------- agent performance --- //
    @Query(value = "   SELECT  a.agent_id , a.agent_name AS AGENT , a.state AS STATE , a.city AS CITY , a.area AS AREA,l.location_id , COUNT(DISTINCT o.order_id) AS ORDERS, " +
            "   COALESCE(SUM(o.total_order_amount), 0) AS SALES   FROM order_table AS o " +
            "   RIGHT JOIN agent_table AS a on a.agent_id = o.agent_id " +
            "   LEFT JOIN location_table AS l ON l.location_id = a.location_id " +
            "  where ( o.created_on IS NULL OR ( o.created_on >= CAST(:startDate AS Date ) and o.created_on <= CAST(:endDate AS Date )) )" +
            "   and (:locationId IS NULL OR :locationId ='' OR a.location_id = :locationId ) " +
            "   GROUP BY l.location_id ,a.agent_id , a.agent_name , a.state , a.city , a.area " +
            "   ORDER BY a.agent_name ASC ", nativeQuery = true)
    Page<AgentPerformanceDto> AgentPerformance(String startDate, String endDate, String locationId, Pageable pageable);

    @Query(value = " SELECT COUNT(DISTINCT a.agent_name) AS agents , COUNT(DISTINCT O.order_id ) AS totalOrders from order_table As o " +
            " RIGHT JOIN agent_table AS a on a.agent_id = o.agent_id " +
            " where ( o.created_on IS NULL OR  ( o.created_on >= CAST(:startDate AS Date ) and o.created_on <= CAST(:endDate AS Date )) )  " +
            "   and (:locationId IS NULL OR :locationId ='' OR a.location_id = :locationId )", nativeQuery = true)
    AgentSummary agentSummary(String startDate, String endDate, String locationId);


    // -- 5 --//
    @Query(value = "SELECT distinct a.agent_id , a.agent_name AS AGENTNAME, l.location_id ,  a.state AS STATE, a.city AS CITY, a.area AS AREA, " +
            "CASE " +
            "    WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount " +
            "    WHEN al.excess_amount <> 0 THEN al.excess_amount " +
            " ELSE 0 END AS BALANCE " +
            "FROM agent_table a " +
            "LEFT JOIN agent_service_limit_table al ON a.agent_id = al.agent_id " +
            "LEFT Join order_table As o  on o.agent_id = a.agent_id " +
            "LEFT JOIN location_table l ON a.location_id = l.location_id " +
            "WHERE (o.created_on IS NULL OR (o.created_on >= CAST(:startDate AS DATE) AND o.created_on <= CAST(:endDate AS DATE)) ) " +
            "AND (:locationId IS NULL OR :locationId ='' OR a.location_id = :locationId )" +
            "group by a.agent_name , a.agent_id ,  l.location_id ,  al.out_standing_amount ,al.excess_amount   " +
            "order by a.agent_name   ", nativeQuery = true)
    Page<AgentDetailsDTO> agentOutStandingDetails(String startDate, String endDate, String locationId, Pageable pageable);

    @Query(value = "select sum(a.out_standing_amount ) * -1  As totalOutStanding  from agent_service_limit_table As a " +
            "join agent_table at on a.agent_id = at.agent_id  " +
            "join location_table l on at.location_id = l.location_id " +
            "where (:locationId IS NULL OR :locationId ='' OR at.location_id = :locationId ) ", nativeQuery = true)
    TotalOutstandingDto totalOutStandingAmounts(String locationId);

    @Query(value = "select COALESCE(sum(o.total_order_amount ) , 0 ) As TotalSales from order_table As o " +
            " join agent_table a on o.agent_id = a.agent_id " +
            "join location_table l on a.location_id = l.location_id " +
            "where (:locationId IS NULL OR :locationId ='' OR a.location_id = :locationId ) ", nativeQuery = true)
    TotalSalesDto TotalSales(String locationId);

    @Query(value = "select distinct count(a.agent_id) As AGENTS from agent_table a " +
            " where (:locationId IS NULL OR :locationId ='' OR a.location_id = :locationId ) ", nativeQuery = true)
    AgentCount agentsDetails(String locationId);

    //-- agent get by id -- //

    @Query(value = " select a.agent_id ,  a.agent_name ,  a.area , a.city , a.location_id , a.discount_percent ,  " +
            " CASE " +
            "           WHEN al.out_standing_amount <> 0 THEN -al.out_standing_amount " +
            "           WHEN al.excess_amount <> 0 THEN al.excess_amount " +
            "                ELSE 0 " +
            "            END AS agent_balance from agent_table a " +
            " right join agent_service_limit_table al on a.agent_id = al.agent_id " +
            " where a.agent_id = :agentId ", nativeQuery = true)
    AgentDetails agentDetails(String agentId);



    //--same dto used for report 2 ;;//
    @Query(value = "   select count(o.order_id) as totalOrders , Coalesce(sum(o.total_order_amount) , 0 ) as totalSales from order_table o " +
            " where o.agent_id = :agentId " , nativeQuery = true)
    ZoneBasedTotal findTotalYearBarReport(String agentId);

    @Query(value = "SELECT DATE_Trunc('month',created_on) AS month,SUM(total_order_amount) AS totalAmount " +
            "FROM order_table where agent_id=:agentId  " +
            "GROUP BY DATE_Trunc('month',created_on)  " +
            "ORDER BY month ", nativeQuery = true)
    List<AgentMonthlyReportModel> findAgentReportMonthly(String agentId);

    @Query(value = "SELECT o.order_id, o.agent_id, o.total_order_amount, o.status  " +
            "FROM order_table o " +
            "WHERE o.agent_id = :agentId " +
            "AND (o.order_id ILIKE %:keyWord% OR o.agent_id IN (" +
            "  SELECT a.agent_name FROM agent_table a WHERE a.agent_name ILIKE %:keyWord%" +
            "))", nativeQuery = true)
    List<AgentOrderDetailsDto> findAgentOrderDetails(String agentId, String keyWord);



    @Query(value = " select o.order_list_id , o.order_id , o.product_id , Coalesce(sum(o.quantity) , 0) as quantity , p.product_name , p.price   from order_list_table o  " +
            "    join product_table p  on p.product_id = o.product_id  " +
            " where o.order_id = :orderId " +
            " group by o.product_id , p.product_name ,  o.order_list_id ,p.price" , nativeQuery = true)
    List<AgentOrderListDetails> agentOrderList(String orderId);






}