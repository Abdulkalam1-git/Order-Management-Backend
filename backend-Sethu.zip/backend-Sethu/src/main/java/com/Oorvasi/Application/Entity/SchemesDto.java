package com.Oorvasi.Application.Entity;

public interface SchemesDto {
    String getSchemeId();
    String getSchemeName();
    String getDescription();
    String getStartDate();
    String getEndDate();
    boolean getIsActive();
    boolean getIsGlobal();
}
