package com.Oorvasi.Application.Repository;

public interface UserDetails {


    Long getUserId();
    String getUserName();
    String getDesignation();
    String getRole();
    String getPassword();
    String getArea();
    String getCity();
    String getState();
    Long getExecutiveId();
    String getExecutiveName();
}
