package com.Oorvasi.Application.Entity.Reports;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Page;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AgentOutStandingDto {
    private  TotalSalesDto totalSales;
    private  TotalOutstandingDto totalOutStandings;
    private AgentCount agent;
    private Page<AgentDetailsDTO> agents;
}
