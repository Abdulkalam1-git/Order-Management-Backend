package com.Oorvasi.Application.Entity;

import java.util.List;

public interface ItemDetailDto {

    String getProductName();
    Integer getUnitPerBox();
    Double getWeightPerUnit();
    Double getBoxWeight();
    Double getPrice();



}
