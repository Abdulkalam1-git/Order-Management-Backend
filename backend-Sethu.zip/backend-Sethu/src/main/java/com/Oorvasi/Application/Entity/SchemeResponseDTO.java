package com.Oorvasi.Application.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter@Setter@AllArgsConstructor@NoArgsConstructor
public class SchemeResponseDTO {
    private String schemeId;
    private String schemeName;
    private Date startDate;
    private Date endDate;
    private List<SchemeRuleDTO> schemeRules;
}
