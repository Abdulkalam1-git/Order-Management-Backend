package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.FactoryModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.FactoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/factory")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)
public class FactoryController {
    @Autowired
    private FactoryService factoryService;

    @PreAuthorize("hasAnyAuthority('Manage Factory')")
    @PostMapping(value = "/create/factory")
    public ResponseEntity<Response> addFactory(@RequestBody FactoryModel factoryModel) {
        return factoryService.createFactory(factoryModel);
    }

    @PreAuthorize("hasAnyAuthority('View Factory')")
    @GetMapping(value ="/get/factory-name")
    public ResponseEntity<Response> getFactoryByName( @RequestParam String keyWord){
        return factoryService.getFactoryByName(keyWord);
    }

    @PreAuthorize("hasAnyAuthority('View Factory Details')")
    @GetMapping(value ="/get/singleFactory/{factoryId}")
    public ResponseEntity<Response> getFactoryByIds( @PathVariable String factoryId){
        return factoryService.getFactoryById(factoryId);
    }

    @PreAuthorize("hasAnyAuthority('Manage Factory')")
    @PutMapping(value= "edit/factory")
    public ResponseEntity<Response> editFactoryZone(@RequestBody FactoryModel updateFactoryModel ){
        return factoryService.editFactory( updateFactoryModel);
    }

    @PreAuthorize("hasAnyAuthority('Manage Factory')")
    @PostMapping(value ="delete/factory/{factoryId}")
    public ResponseEntity<Response> deleteFactory(@PathVariable String factoryId){
        return factoryService.deleteFactoryById(factoryId);
    }


}
