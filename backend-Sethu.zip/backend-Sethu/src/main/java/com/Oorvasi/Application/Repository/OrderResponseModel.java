package com.Oorvasi.Application.Repository;

public interface OrderResponseModel {
    String getOrderId();
    String getAgentName();
    String getAgentId();
    Double getTotalOrderWeight();
    Double getTotalOrderAmount();
    Double getTotalFreeOrderWeight();
    String getArea();
    String getCity();
    String getShopId();
    String getShopName();
    String getShopArea();
    String getShopCity();
    Integer getExecutiveId();
    String getExecutiveName();
    String getExecutiveArea();
    String getExecutiveCity();
    void setAgentBalance(String s);

}
