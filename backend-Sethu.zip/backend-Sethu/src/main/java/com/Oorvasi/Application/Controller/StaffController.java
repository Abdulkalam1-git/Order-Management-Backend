package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.StaffModel;
import com.Oorvasi.Application.Service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)
@RequestMapping(value = "/staff")
public class StaffController {

    @Autowired StaffService staffService;

    @PreAuthorize("hasAnyAuthority('Manage Staff')")
    @PostMapping("create/staff")
    private ResponseEntity<Response> createStaff(@RequestBody StaffModel staffModel){
        return staffService.createStaff(staffModel);
    }

    @PreAuthorize("hasAnyAuthority('View Staff')")
    @GetMapping("get/staff/all")
    public ResponseEntity<Response> getAllStaffs(@RequestParam String keyword,@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable){
        return staffService.getAllStaffs(keyword,pageable);
    }
    @PreAuthorize("hasAnyAuthority('View Staff Details')")
    @GetMapping("get/staff")
    public ResponseEntity<Response> getStaffsByID(@RequestHeader("Authorization") String authorizationHeader){
        return staffService.getStaffById(authorizationHeader);
    }

    @PreAuthorize("hasAnyAuthority('View Staff Details Designation')")
    @GetMapping("get/staff/designation/{designation}")
    public ResponseEntity<Response> getStaffsByDesignation(@PathVariable String  designation ){
        return staffService.getStaffByDesignation(designation);
    }
    @PreAuthorize("hasAnyAuthority('View SalesExecutive')")
    @GetMapping("get/allSalesExecutive/{locationId}")
    public ResponseEntity<Response> getStaffsByLocation(@PathVariable("locationId") String locationId, @RequestParam String keyword,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable ){
        return staffService.getStaffsByLocation(locationId,keyword,pageable);
    }

    @PreAuthorize("hasAnyAuthority('View Staff Details Team')")
    @GetMapping("get/staff/team/{team}")
    public ResponseEntity<Response> getStaffsByTeam(@PathVariable String team ){
        return staffService.getStaffByTeam(team);
    }

    @PreAuthorize("hasAnyAuthority('Manage Staff')")
    @PutMapping("update/staff")
    public ResponseEntity<Response> updateStaff(@RequestBody StaffModel updatedStaffModel) {
        return staffService.updateStaff(updatedStaffModel);
    }
}
