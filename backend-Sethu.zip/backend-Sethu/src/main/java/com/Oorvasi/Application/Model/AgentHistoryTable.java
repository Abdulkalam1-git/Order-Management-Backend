package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "agent_history_table")
public class AgentHistoryTable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer AgentEditId;
    private String agentId;
    private String agentName;
    private String phoneNo;
    private String email;
    private String state;
    private String city;
    private String area;
    private String businessName;
    private String addressLine1;
    private String addressLine2;
    @OneToOne
    @JoinColumn(name = "location_id")
    LocationModel locationModel;
    private String status;
    private Date createdOn;
    private String createdBy;
    private Date updatedOn = new Date();
    private String updatedBy;
    private Double discountPercent;
}
