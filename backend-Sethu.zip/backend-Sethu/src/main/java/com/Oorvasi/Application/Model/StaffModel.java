package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="staffs")
public class StaffModel {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private long userId;
    @Column(nullable = false)
    private String userName;
    @Column(nullable = false)
    private String fullName;
    @Column(unique = true, nullable = false)
    private String phoneNumber;
    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;
    private String password;
    @Column(nullable = false)
    private String team;
    @Column( nullable = false)
    private String designation;
    @ManyToOne
    @JoinColumn(name = "location_id")
    private LocationModel locationModel;
    private String state;
    private String city;
    private String area;
    private String status;
    @Column(name = "created_on", nullable = false, updatable = false)
    private Date createdOn;
    @Column(name = "created_by", updatable = false)
    private String createdBy;
    @Column(name = "updated_on")
    private Date updatedOn;
    @Column(name = "updated_by")
    private String updatedBy;

    @Transient private String email;
}
