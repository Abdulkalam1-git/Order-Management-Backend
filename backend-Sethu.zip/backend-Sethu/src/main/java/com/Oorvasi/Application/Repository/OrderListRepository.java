package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Entity.Reports.*;
import com.Oorvasi.Application.Model.OrderListModel;
import com.Oorvasi.Application.Model.OrderModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface OrderListRepository extends JpaRepository<OrderListModel, String> {

    OrderListModel findFirstByOrderByCreatedOnDesc();

    boolean existsByOrderListId(String orderListId);

    OrderListModel findByOrderListId(String orderListId);

    List<OrderListModel> findByOrderModel(OrderModel currentOrderStatusFromDb);

    List<OrderListModel> findByOrderModelAndProductModelProductId(OrderModel orderModel, String productId);

    @Query(value = "select olt.order_list_id as orderListId,pt.product_name as productName,pt.product_id as productId,pt.price as price,olt.quantity as " +
            "quantity,pt.weight_per_unit as weightPerUnit,ft.factory_name as factoryName,olt.total_amount as total_amount,olt.delivery_status as status,olt.factory_id as " +
            "factory_id , ft.short_code As factoryShortName from order_list_table as olt " +
            "inner join product_table as pt on olt.product_id=pt.product_id " +
            "left join factory_table as ft on olt.factory_id=ft.factory_id " +
            "where olt.order_id=:orderId ", nativeQuery = true)
    List<OrderDetailsRepo> findByOrder_Id(String orderId);

    //--reports -- //
    //--------- analysis ------------------------//


    //--1--// (i)
    @Query(value = "SELECT " +
            "    COUNT(o.order_id) AS totalOrders, " +
            "    SUM(o.total_order_amount) AS TotalSales, " +
            "    TO_CHAR(o.created_on, 'MON YYYY') AS month , " +
            "    1000000 AS TotalAmount " +
            "FROM " +
            "    order_table AS o " +
            "WHERE " +
            "    extract(YEAR FROM o.created_on) = extract(YEAR FROM now()) " +
            "    AND extract(MONTH FROM o.created_on) = extract(MONTH FROM now()) " +
            "GROUP BY  " +
            "    TO_CHAR(o.created_on, 'MON YYYY')", nativeQuery = true)
    SalesForMonthDto salesForMonth();

    //--1--// (ii)
    @Query(value = "select Date_Trunc('month' , created_on) AS month , sum(total_order_amount )As totalAmount " +
            "from order_table where  " +
            "     EXTRACT(YEAR FROM created_on) = :year " +
            "group by DATE_Trunc('month' , created_on) " +
            "order by month ", nativeQuery = true)
    List<MonthlySalesReports> monthlySalesReports(int year);

    @Query(value = " select count(order_id) As totalOrders , sum(total_order_amount) As totalSales from order_table " +
            " where extract(YEAR From created_on) = :year", nativeQuery = true)
    MonthlySalesByYearTotal monthlySalesByYear(int year);

    //--1--// (iii)

    @Query(value = "WITH months AS ( " +
            "SELECT generate_series(DATE_TRUNC('year', MAKE_DATE(:year, 1, 1))," +
            " DATE_TRUNC('year', MAKE_DATE(:year, 1, 1)) +" +
            " INTERVAL '11 months', INTERVAL '1 month') AS month )," +
            " locations AS ( SELECT location_id FROM location_table " +
            "WHERE status ILIKE 'active' " +
            "AND (:locationId IS NULL OR :locationId = '' OR location_id = :locationId) )" +
            " SELECT TO_CHAR(m.month, 'YYYY-MM') AS month," +
            " COALESCE(SUM(o.total_order_amount), 0) AS totalAmount, " +
            " l.location_id FROM " +
            "months m " +
            "CROSS JOIN locations l " +
            "LEFT JOIN agent_table a ON a.location_id = l.location_id " +
            "LEFT JOIN order_table o ON o.agent_id = a.agent_id AND" +
            " DATE_TRUNC('month', o.created_on) = m.month " +
            " GROUP BY m.month, l.location_id " +
            "ORDER BY l.location_id, m.month ", nativeQuery = true)
    List<SalesChartDto> salesChartDto(@Param("year") int year, @Param("locationId") String locationId);

    @Query(value = " select l.location_id , l.short_code AS shortCode, " +
            "COALESCE(SUM(o.total_order_amount), 0) AS totalSales , " +
            "COALESCE(COUNT(o.order_id), 0) AS totalOrders from location_table As l " +
            " left join  agent_table As a on l.location_id = a.location_id " +
            " left join order_table As o  on a.agent_id = o.agent_id " +
            "AND EXTRACT(YEAR FROM o.created_on) = :year " +
            "where l.status iLike 'active' " +
            " group by l.location_id ", nativeQuery = true)
    List<SalesOverTheYearByZone> salesOverYearByZone(int year);


    //-- by order ------//
    @Query(value = "SELECT ot.order_id,at.agent_id , at.agent_name,lt.location_id ,  lt.short_code AS Zone, ot.total_order_amount FROM order_table AS ot " +
            "  JOIN agent_table AS at ON ot.agent_id = at.agent_id " +
            "  JOIN location_table AS lt ON lt.location_id = at.location_id " +
            "WHERE ot.order_on " +
            "BETWEEN CAST(:startDate AS timestamp) AND " +
            "CAST(:endDate AS timestamp) " +
            "AND ( :locationId IS NULL OR :locationId ='' OR  lt.location_id = :locationId ) " +
            "ORDER BY ot.order_id ,ot.created_on DESC", nativeQuery = true)
    Page<OrderByDto> findByOrders(String startDate, String endDate, Pageable pageable, String locationId);

    // -- total sales ---//
    @Query(value = "SELECT " +
            "SUM(ot.total_order_amount) AS  totalSales , COUNT(ot.order_id) AS totalOrder ,   " +
            "(select count(lt.location_id ) As zones from location_table lt where   lt.status iLike 'active') " +
            "FROM location_table lt " +
            "left JOIN agent_table at ON lt.location_id = at.location_id " +
            "left JOIN order_table ot ON at.agent_id = ot.agent_id " +
            "WHERE ot.order_on" +
            " BETWEEN CAST(:startDate AS timestamp) AND " +
            "CAST(:endDate AS timestamp) " ,
            nativeQuery = true)
    TotalSales findTotalSales(String startDate, String endDate);

    @Query(value = "SELECT " +
            "SUM(ot.total_order_amount) AS  totalSales , COUNT(ot.order_id) AS totalOrders " +
            "FROM location_table lt " +
            "left JOIN agent_table at ON lt.location_id = at.location_id " +
            "left JOIN order_table ot ON at.agent_id = ot.agent_id " +
            "WHERE ot.order_on" +
            " BETWEEN CAST(:startDate AS timestamp) AND " +
            "CAST(:endDate AS timestamp) " +
            "AND ( :locationId IS NULL OR :locationId ='' OR  lt.location_id = :locationId ) ",
            nativeQuery = true)
    ZoneBasedTotal findZoneBasedSales(String startDate, String endDate, String locationId);


    //-- by zones  ---//
    @Query(value = "SELECT lt.short_code AS zone, lt.location_id AS locationId , lt.location_name AS zoneName, COUNT(DISTINCT ot.order_id) AS total_orders," +
            " COUNT(DISTINCT at.agent_id) AS total_agents, SUM(ot.total_order_amount) AS total_sales " +
            "FROM order_table AS ot " +
            " right JOIN agent_table AS at ON ot.agent_id = at.agent_id " +
            " right JOIN location_table AS lt ON lt.location_id = at.location_id " +
            "WHERE ot.order_on " +
            "BETWEEN CAST(:startDate AS timestamp) AND CAST(:endDate AS timestamp) OR ot.created_on IS NULL " +
            "and lt.status iLike 'active'" +
            "GROUP BY lt.short_code, lt.location_name , lt.location_id " +
            "ORDER BY lt.short_code",
            nativeQuery = true)
    Page<ZoneByDto> findTotalOrderByZones(String startDate, String endDate, Pageable pageable);

    //-- -- zone Analysis ----------//

    // -- 3 --//
    @Query(value = "SELECT  p.product_id , ft.factory_id ,  p.product_name AS item , COUNT(DISTINCT ol.order_id) AS orders, COALESCE(SUM(ol.total_amount), 0) AS sales " +
            "FROM product_table p " +
            "LEFT JOIN order_list_table ol ON p.product_id = ol.product_id " +
            "LEFT JOIN order_table ot ON ol.order_id = ot.order_id " +
            "LEFT JOIN factory_table ft ON ft.factory_id = ol.factory_id " +
            "where ( ot.created_on IS NULL OR ( ot.created_on >= CAST(:startDate AS Date ) and ot.created_on <= CAST(:endDate AS Date )) )" +
            "AND ( :factoryId IS NULL OR :factoryId ='' OR  ol.factory_id = :factoryId ) " +
            "GROUP BY p.product_id, p.product_name , ft.factory_id  " +
            "ORDER BY sales DESC",
            nativeQuery = true)
    Page<ItemTrendDto> ItemTrends(String startDate, String endDate, String factoryId, Pageable pageable);


    @Query(value = "SELECT  SUM(product_summary.orders) AS total_orders , COUNT(DISTINCT product_summary.product_id) AS items FROM ( " +
            "    SELECT  p.product_id AS product_id , COUNT(DISTINCT ol.order_id) AS orders, COALESCE(SUM(ol.total_amount), 0) AS sales " +
            "    FROM product_table p " +
            "    LEFT JOIN order_list_table ol ON p.product_id = ol.product_id " +
            "    LEFT JOIN order_table ot ON ol.order_id = ot.order_id " +
            "    WHERE (ot.created_on BETWEEN CAST(:startDate AS timestamp) AND CAST(:endDate AS timestamp) OR ot.created_on IS NULL) " +
            "AND ( :factoryId IS NULL OR :factoryId ='' OR  ol.factory_id = :factoryId ) " +
            "    GROUP BY p.product_id, p.product_name ) AS product_summary",
            nativeQuery = true)
    ItemOrderSummaryDto getTotalOrderAndItems(String startDate, String endDate, String factoryId);


    //5//
    @Query(value = "select (select count(s.user_id) AS Marketing_Executives from staffs s " +
            " WHERE s.created_on " +
            "             BETWEEN CAST(:startDate AS timestamp) AND " +
            "             CAST(:endDate AS timestamp) and " +
            "s.designation = 'Sales Executive' and ( :locationId IS NULL OR :locationId ='' OR  s.location_id = :locationId )   ) " +
            ", count(*) AS Total_Orders from shop_order_table st " +
            "join shop_table sh on st.shop_id = sh.shop_id " +
            "join location_table l on sh.location_id = l.location_id " +
            "where st.created_on " +
            "           BETWEEN CAST(:startDate AS timestamp) AND " +
            "            CAST(:endDate AS timestamp) and " +
            "( :locationId IS NULL OR :locationId ='' OR  l.location_id = :locationId )  "
            , nativeQuery = true)
    ExecutiveTotals findExecutiveTotals(String startDate, String endDate, String locationId);


    @Query(value = "select st.executive_id , s.user_id , s.user_name As name , s.location_id , s.state , s.city , s.area , count(st.executive_id) as orders ,  " +
            "COALESCE(sum(st.total_order_amount) , 0) AS sales  from staffs s  " +
            " left join shop_order_table st on s.user_id = st.executive_id " +
            "join location_table l on  s.location_id = l.location_id " +
            "where s.designation = 'Sales Executive' " +
            " and st.created_on " +
            "           BETWEEN CAST(:startDate AS timestamp) AND " +
            "            CAST(:endDate AS timestamp)  and " +
            "( :locationId IS NULL OR :locationId ='' OR  l.location_id = :locationId )  " +
            "group by st.executive_id , s.user_id " +
            "order by s.user_name ", nativeQuery = true)
    Page<ExecutiveDetails> findExecutiveDetails(String startDate, String endDate, String locationId, Pageable pageable);


}
