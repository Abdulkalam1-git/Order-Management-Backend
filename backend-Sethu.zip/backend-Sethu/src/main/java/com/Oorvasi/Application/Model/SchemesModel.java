package com.Oorvasi.Application.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "schemes_table")
public class SchemesModel {
    @Id
    private String schemeId;
    @Column(nullable = false, length = 255)
    private String schemeName;
    @Column(nullable = false)
    private String description;
    @Column(nullable = false)
    private Date startDate;
    @Column(nullable = false)
    private Date endDate;
    @Column(nullable = false)
    private Boolean isActive;
    @Column(nullable = false)
    private Boolean isGlobal;
    private Date createdAt = new Date();
    private Date updatedAt;
    private Date deletedAt;
    private String status;
    // Add the One-to-Many relationship
    @OneToMany(mappedBy = "schemesModel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<SchemeRulesModel> schemeRulesModel; // Maps the relationship

}
