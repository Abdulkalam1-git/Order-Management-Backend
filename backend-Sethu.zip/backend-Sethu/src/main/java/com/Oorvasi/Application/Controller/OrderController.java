package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Entity.FactoryPlan;
import com.Oorvasi.Application.Entity.OrderListUpdate;
import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/order")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PreAuthorize("hasAnyAuthority('Create Order')")
    @PostMapping(value = "/create/order")
    public ResponseEntity<Response> createOrder(@RequestBody CreateOrderListModel createOrderListModel) {
        return orderService.createOrder(createOrderListModel);
    }

    @PreAuthorize("hasAnyAuthority('Assign Agent')")
    @PostMapping("assign/agent")
    //----agent assign ----//
    public ResponseEntity<Response> createOrderFromShop(@RequestBody CreateOrderListModel createOrderListModelFromShop) {
        return orderService.createOrderFromShop(createOrderListModelFromShop);
    }

    @PreAuthorize("hasAnyAuthority('Assign Factory')")
    @PostMapping(value = "/factories/assign")
    public ResponseEntity<Response> assignFactory(@RequestBody FactoryPlan factoryPlan) {
        return orderService.assignFactory(factoryPlan);
    }

    @PreAuthorize("hasAnyAuthority('View Single OrderDetail')")
    @GetMapping(value = "/get/single-order")
    public ResponseEntity<Response> getSingleOrder(@RequestParam String orderId) {
        return orderService.getSingleOrder(orderId);
    }

    @PreAuthorize("hasAnyAuthority('View Single ShopOrder')")
    @GetMapping(value = "/get/single-shop-order")
    public ResponseEntity<Response> getSingleShopOrder(@RequestParam String tempId) {
        return orderService.getSingleShopOrder(tempId);
    }

    //    @PreAuthorize("hasAnyAuthority('Read_User')")
    @GetMapping(value = "/get/Ready-to-finalize")
    public ResponseEntity<Response> getReadyToFinalize(@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return orderService.getOrdersToFinalize(pageable);
    }

    //    @PreAuthorize("hasAnyAuthority('Read_User')")
    @GetMapping(value = "/get/closed-orders")
    public ResponseEntity<Response> getClosedOrders(@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return orderService.getClosedOrders(pageable);
    }

    @PreAuthorize("hasAnyAuthority('View ClosedOrders')")
    @GetMapping(value = "/get/closed-orders-byName")
    public ResponseEntity<Response> getClosedOrdersByName(@RequestParam String keyWord, @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return orderService.getFinalizeOrder(keyWord, pageable);
    }

    @PreAuthorize("hasAnyAuthority('view Finalize Detail')")
    @GetMapping(value = "/get/ready-to-finalizeOrders/byName")
    public ResponseEntity<Response> getReadyToFinalizeOrdersByName(@RequestParam String keyWord, @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return orderService.getReadyToFinalizeOrder(keyWord, pageable);
    }

    @PreAuthorize("hasAnyAuthority('view OrderItems')")
    @GetMapping(value = "/get/Order-items-to-assign-factory")
    public ResponseEntity<Response> FetchOrderItemsToAssignFactory(@RequestParam String keyword, @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return orderService.fetchOrderItemsForFactoryAssignment(keyword, pageable);
    }

    @PreAuthorize("hasAnyAuthority('View DispatchItems')")
    @GetMapping(value = "/get/Dispatch-items-byOrderId")
    public ResponseEntity<Response> getDispatchItemsByOrderId(@RequestParam String keyword, @RequestParam String factoryId, @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return orderService.getDispatchItemsByOrderId(keyword, factoryId, pageable);
    }

    @PreAuthorize("hasAnyAuthority('View DispatchCount')")
    @GetMapping(value = "get/total-Dispatch-Details")
    public ResponseEntity<Response> getTotalDispatchDetails(@RequestParam String factoryId) {
        return orderService.getTotalDispatchDetails(factoryId);

    }

    @PreAuthorize("hasAnyAuthority('Edit Order')")
    @PutMapping("/update/order")
    public ResponseEntity<Response> editOrder(@RequestBody CreateOrderListModel editOrderListModel) {
        return orderService.editOrder(editOrderListModel);
    }

    @PreAuthorize("hasAnyAuthority('Update Delivery Status')")
    @PutMapping(value = "/update/delivery-status")
    public ResponseEntity<Response> updateDeliveryStatusAndOrderStatus(@RequestBody OrderListUpdate orderListUpdate) {
        return orderService.updateDeliveryStatusAndOrderStatus(orderListUpdate);
    }

    @PreAuthorize("hasAnyAuthority('Update Order Finalize ')")
    @PutMapping(value = "/update/order/finalize")
    public ResponseEntity<Response> finalizeOrder(@RequestParam String orderId) {
        return orderService.UpdateOrderStatusFinalize(orderId);
    }

    @PreAuthorize("hasAnyAuthority('View Finalize Balance Details')")
    @GetMapping(value = "/get/order/finalizeDetails")
    public ResponseEntity<Response> finalizeOrderDetails(@RequestParam String orderId) {
        return orderService.getFInalizeOrderDetails(orderId);
    }

}

