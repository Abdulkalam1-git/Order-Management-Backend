package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.*;
import org.hibernate.query.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private OrderListRepository orderListRepository;
    @Autowired
    private AgentRepository agentRepository;
    @Autowired
    private ShopOrderRepository shopOrderRepository;
    @Autowired
    private ShopOrderListRepository shopOrderListRepository;
    @Autowired
    private AgentServiceLimitRepository agentServiceLimitRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ProductPriceRepository productPriceRepository;

    public ResponseEntity<Response> createOrder(CreateOrderListModel createOrderListModel) {
        Response response = new Response();
        try {
            OrderModel orderModel = new OrderModel();
            String agentId = createOrderListModel.getAgentId();
            AgentModel agentModel = agentRepository.findByAgentId(agentId);
            AgentModel agentModelToDB = new AgentModel();
            agentModelToDB.setAgentId(createOrderListModel.getAgentId());
            int count = orderRepository.findCount(createOrderListModel.getAgentId()) + 1;
            // -------- generate Order ID -------- //
            String agentName = agentModel.getAgentName();
            LocalDate date = LocalDate.now();
            int day = date.getDayOfMonth();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM");
            String currentMonth = date.format(formatter);
            String orderId = agentName + "/" + day + currentMonth + "/" + count;
            orderModel.setOrderId(orderId);
            orderModel.setAgentModel(agentModelToDB);
            //-- quantity -- //
            List<Integer> quantities = createOrderListModel.getQuantity();
            for (Integer quantity : quantities) {
                if (quantity < 0) {
                    throw new RuntimeException("quantity cannot be negative");
                }
                if (quantity == 0) {
                    throw new RuntimeException("quantity cannot be zero");
                }
            }
            Double weight = 0.0;
            int items = createOrderListModel.getProductId().size();
            orderModel.setItems(items);
            orderModel.setOrderBy(createOrderListModel.getOrderBy());
            orderModel.setTotalOrderAmount(createOrderListModel.getTotalOrderAmount());
            orderModel.setTotalOrderWeight(createOrderListModel.getTotalOrderWeight());
            orderModel.setStatus("Active");
            orderRepository.save(orderModel);
            Double totalOrderAmount = 0.0;
            Double totalOrderWeight = 0.0;
            for (int i = 0; i < createOrderListModel.getProductId().size(); i++) {
                String productId = createOrderListModel.getProductId().get(i);
                Integer quantity = createOrderListModel.getQuantity().get(i);
                // ----ProductModel to get the amount ---//
                ProductModel productModelFromDb = productRepository.findById(productId).orElseThrow(() -> new RuntimeException("no product details for found for ID :" + productId));
                //--false --//
                if (!productModelFromDb.getStandard()) {
                    Optional<AgentModel> agentFromDb = agentRepository.findById(agentId);
                    if (agentFromDb.isPresent()) {
                        String agentLocationId = agentFromDb.get().getLocationModel().getLocationId();

                        Optional<ProductPriceModel> productPriceModelFromDb = productPriceRepository.findByProductIdAndLocationModelLocationId(productId, agentLocationId);
                        if (productPriceModelFromDb.isPresent()) {
                            productModelFromDb.setPrice(productPriceModelFromDb.get().getLocationPrice());
                        }
                    }
                }
                // --  get product price -- //
                Double amount = productModelFromDb.getPrice();
                if (amount == null || amount <= 0) {
                    throw new RuntimeException("Invalid amount for product ID: " + productId);
                }
                Double totalAmount = amount * quantity;
                if (totalAmount <= 0) {
                    throw new RuntimeException("Invalid total amount for product ID: " + productId);
                }
                Double totalWeight = productModelFromDb.getWeightPerUnit()*quantity/1000000;
                totalOrderWeight+=totalWeight;
                // --- save OrderListModel
                OrderListModel orderListModel = new OrderListModel();
                OrderListModel orderListModel1 = orderListRepository.findFirstByOrderByCreatedOnDesc();
                String orderListId = orderListModel1 == null ? "OL00001" :
                        "OL" + String.format("%05d", (Long.parseLong(orderListModel1.getOrderListId().split("OL")[1]) + 1));
                while (orderListRepository.existsByOrderListId(orderListId)) {
                    orderListId = "OL" + String.format("%05d", (Long.parseLong(orderListId.split("OL")[1]) + 1));
                }
                orderListModel.setOrderListId(orderListId);
                orderListModel.setOrderModel(orderModel);
                orderListModel.setProductModel(productModelFromDb);
                orderListModel.setQuantity(createOrderListModel.getQuantity().get(i));
                orderListModel.setAmount(amount);
                orderListModel.setTotalAmount(totalAmount);
                orderListModel.setDeliveryStatus("Yet to dispatch");
                orderListModel.setCreatedBy(createOrderListModel.getCreatedBy());
                orderListRepository.save(orderListModel);
                // ---Add to the totalOrderAmount --//
                totalOrderAmount += totalAmount;
            }
            if(createOrderListModel.getTotalFreeOrderWeight() <0 ){
                throw new RuntimeException("totalFreeOrderWeight Cannot be negative");}
            Double totalFreeOrderWeight = createOrderListModel.getTotalFreeOrderWeight();
            orderModel.setTotalOrderWeight(totalOrderWeight);
            orderModel.setTotalOrderAmount(totalOrderAmount);
            orderModel.setTotalFreeOrderWeight(totalFreeOrderWeight);
            orderRepository.save(orderModel);
            response.setStatus("Success");
            response.setResponseMessage("Order created successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Failed to create order " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getSingleOrder(String orderId) {
        Response response = new Response();
        try {
            OrderModel orderModel = orderRepository.findByOrderId(orderId);
            String AgentId  = orderModel.getAgentModel().getAgentId();
            List<OrderDetailsRepo> orderListModel = orderListRepository.findByOrder_Id(orderId);
            if (orderModel.getShopModel()==null){
                OrderResponseModel orderResponseModel = orderRepository.findByOrderIds(orderId);
                AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(AgentId);
                if (orderModel != null && !orderListModel.isEmpty()) {
                    OrderAndOrderListModel orderAndOrderListModel = new OrderAndOrderListModel();
                    if (agentServiceLimitModel.getOutStandingAmount()==0 && agentServiceLimitModel.getExcessAmount()==0){
                        orderAndOrderListModel.setAgentBalance(0.0);
                    }else if(agentServiceLimitModel.getOutStandingAmount()>0 && agentServiceLimitModel.getExcessAmount()==0){
                        orderAndOrderListModel.setAgentBalance(agentServiceLimitModel.getOutStandingAmount()*-1);
                    }else {
                       orderAndOrderListModel.setAgentBalance(agentServiceLimitModel.getExcessAmount());
                    }
                    orderAndOrderListModel.setOrderModel(orderResponseModel);
                    orderAndOrderListModel.setOrderListModelList(orderListModel);
                    response.setStatus("Success");
                    response.setOrderData(orderAndOrderListModel);
                    return new ResponseEntity<>(response, HttpStatus.OK);
                }
            }else {
                OrderResponseModel orderResponseModel = orderRepository.findByOrderIdAndShop(orderId);
                AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(AgentId);
                if (orderModel != null && !orderListModel.isEmpty()) {
                    OrderAndOrderListModel orderAndOrderListModel = new OrderAndOrderListModel();
                    if (agentServiceLimitModel.getOutStandingAmount()==0 && agentServiceLimitModel.getExcessAmount()==0){
                        orderAndOrderListModel.setAgentBalance(0.0);
                    }else if(agentServiceLimitModel.getOutStandingAmount()>0 && agentServiceLimitModel.getExcessAmount()==0){
                        orderAndOrderListModel.setAgentBalance(agentServiceLimitModel.getOutStandingAmount()*-1);
                    }else {
                        orderAndOrderListModel.setAgentBalance(agentServiceLimitModel.getExcessAmount());
                    }
                    orderAndOrderListModel.setOrderModel(orderResponseModel);
                    orderAndOrderListModel.setOrderListModelList(orderListModel);
                    response.setStatus("Success");
                    response.setOrderData(orderAndOrderListModel);
                    return new ResponseEntity<>(response, HttpStatus.OK);
                }
            }
            response.setStatus("Success");
            response.setData(Collections.singletonList(orderModel));
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getSingleShopOrder(String tempId) {
        Response response = new Response();
        try {
            ShopOrderResponseModel shopOrderResponseModel = shopOrderRepository.findByTempIds(tempId);
            List<OrderDetailsRepo> orderListModel = shopOrderListRepository.findBytempIds(tempId);
            if (shopOrderResponseModel != null && !orderListModel.isEmpty()) {
                OrderAndOrderListModel orderAndOrderListModel = new OrderAndOrderListModel();
                orderAndOrderListModel.setShopOrderResponseModel(shopOrderResponseModel);
                orderAndOrderListModel.setOrderListModelList(orderListModel);
                response.setStatus("Success");
                response.setData(Collections.singletonList(orderAndOrderListModel));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
            response.setStatus("Success");
            response.setData(Collections.singletonList(shopOrderResponseModel));
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public ResponseEntity<Response> assignFactory(FactoryPlan factoryPlan) {
        Response response = new Response();
        try {
            for (int i = 0; i < factoryPlan.getFactoryId().size(); i++) {
                OrderListModel orderListModel = orderListRepository.findByOrderListId(factoryPlan.getOrderListId().get(i));
                FactoryModel factoryModel = new FactoryModel();
                factoryModel.setFactoryId(factoryPlan.getFactoryId().get(i));
                orderListModel.setFactoryModel(factoryModel);
                orderListRepository.save(orderListModel);
            }
            OrderListModel orderListModel =orderListRepository.findByOrderListId(factoryPlan.getOrderListId().get(0));
            OrderModel orderModel = orderRepository.findByOrderId(orderListModel.getOrderModel().getOrderId());
            orderModel.setStatus("Yet to dispatch");
            orderRepository.save(orderModel);
            response.setStatus("success");
            response.setResponseMessage("Factory Assigned To Order Successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> updateDeliveryStatusAndOrderStatus(OrderListUpdate orderListUpdate) {
        Response response = new Response();
        try {
            List<OrderListModel> orderListModelsFromDb = orderListRepository.findAllById(orderListUpdate.getOrderListId());
            if (orderListModelsFromDb.isEmpty()) {
                response.setStatus("Failure");
                response.setResponseMessage("No Order List Items Found for the given IDs");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            OrderModel currentOrderStatusFromDb = orderListModelsFromDb.get(0).getOrderModel();
            for (OrderListModel orderListModel : orderListModelsFromDb) {
                String currentDeliveryStatus = orderListModel.getDeliveryStatus();
                orderListModel.setDeliveryStatus(
                        "Yet to dispatch".equals(currentDeliveryStatus) ? "Dispatched" : "Yet to dispatch"
                );
            }
            orderListRepository.saveAll(orderListModelsFromDb);
            List<OrderListModel> allOrderListItems = orderListRepository.findByOrderModel(currentOrderStatusFromDb);
            boolean allDispatched = allOrderListItems.stream()
                    .allMatch(item -> "Dispatched".equals(item.getDeliveryStatus()));
            //-- orderModel -- //
            currentOrderStatusFromDb.setStatus(allDispatched ? "Ready To Finalize" : "Active");
            orderRepository.save(currentOrderStatusFromDb);
            response.setStatus("Success");
            response.setResponseMessage("Order Delivery Status Updated Successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public ResponseEntity<Response> getOrdersToFinalize(@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<OrderModel> getOrderFromDb = orderRepository.findByStatus("Ready To Finalize",pageable);
            //---true or false -----//
            boolean checkEmpty = !getOrderFromDb.isEmpty();
            response.setStatus(checkEmpty ? "success" : "failure");
            response.setResponseMessage(checkEmpty ? "Orders Ready To Finalize Found Successfully" : " No Orders To Finalize ");
            response.setDatas(checkEmpty ? getOrderFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("failed to find " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> UpdateOrderStatusFinalize(String orderId) {
        Response response = new Response();
        try {
            OrderModel orderModelFromDb = orderRepository.findByOrderId(orderId);
            Double discountPercent = orderModelFromDb.getAgentModel().getDiscountPercent();
            if (orderModelFromDb == null) {
                response.setStatus("Failure");
                response.setResponseMessage("Order Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            Double actualTotalAmount = orderModelFromDb.getTotalOrderAmount();
            Double discountAmount = actualTotalAmount * discountPercent / 100;
            Double totalAmountAfterDiscount = actualTotalAmount - discountAmount;
            orderModelFromDb.setStatus("Finalize");
            AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(orderModelFromDb.getAgentModel().getAgentId());
            Double oldOutStanding = agentServiceLimitModel.getOutStandingAmount();
            Double excessAmount = agentServiceLimitModel.getExcessAmount();
            if (excessAmount == 0.0) {
                agentServiceLimitModel.setOutStandingAmount(oldOutStanding+totalAmountAfterDiscount);
            } else if (excessAmount > 0.0) {
                if (excessAmount > totalAmountAfterDiscount) {
                    agentServiceLimitModel.setExcessAmount(excessAmount-totalAmountAfterDiscount);
                } else {
                    agentServiceLimitModel.setExcessAmount(0.0);
                    agentServiceLimitModel.setOutStandingAmount(totalAmountAfterDiscount-excessAmount);
                }
            }
            agentServiceLimitRepository.save(agentServiceLimitModel);
            orderRepository.save(orderModelFromDb);
            response.setStatus("Success");
            response.setResponseMessage("Order Status Updated Successfully");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> getFInalizeOrderDetails(String orderId) {
        Response response = new Response();
        try {
            OrderModel orderModelFromDb = orderRepository.findByOrderId(orderId);
            Double discountPercent = orderModelFromDb.getAgentModel().getDiscountPercent();
            if (orderModelFromDb == null) {
                response.setStatus("Failure");
                response.setResponseMessage("Order Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            String orderModelStatusFromDb = orderModelFromDb.getStatus();
            if (orderModelStatusFromDb.equals("Ready To Finalize")) {
                Double actualTotalAmount = orderModelFromDb.getTotalOrderAmount();
                Double discountAmount = actualTotalAmount * discountPercent / 100;
                Double totalAmountAfterDiscount = actualTotalAmount - discountAmount;
                orderModelFromDb.setStatus("Finalize");
                AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(orderModelFromDb.getAgentModel().getAgentId());
                Double oldOutStanding = agentServiceLimitModel.getOutStandingAmount();
                Double newOutStanding = oldOutStanding + totalAmountAfterDiscount;
                FinalizeOrderModel finalizeOrderModel = new FinalizeOrderModel();
                finalizeOrderModel.setOrderTotal(orderModelFromDb.getTotalOrderAmount());
                finalizeOrderModel.setDiscounted(totalAmountAfterDiscount);
                finalizeOrderModel.setDiscountPercent(discountPercent);
                if (agentServiceLimitModel.getExcessAmount() == 0.0 && agentServiceLimitModel.getOutStandingAmount() == 0.0) {
                    finalizeOrderModel.setOldBalance(0.0);
                    finalizeOrderModel.setNewBalance( newOutStanding*-1);
                } else if (agentServiceLimitModel.getOutStandingAmount() == 0.0 && agentServiceLimitModel.getExcessAmount() > 0.0) {
                    finalizeOrderModel.setOldBalance(agentServiceLimitModel.getExcessAmount());
                    if (agentServiceLimitModel.getExcessAmount() > totalAmountAfterDiscount) {
                        Double newBalance = agentServiceLimitModel.getExcessAmount() - totalAmountAfterDiscount;
                        finalizeOrderModel.setNewBalance(newBalance);
                    } else {
                        Double newBalance = totalAmountAfterDiscount - agentServiceLimitModel.getExcessAmount();
                        finalizeOrderModel.setNewBalance(newBalance*-1);
                    }

            } else if (agentServiceLimitModel.getOutStandingAmount() > 0.0 && agentServiceLimitModel.getExcessAmount() == 0.0) {
                finalizeOrderModel.setOldBalance(agentServiceLimitModel.getOutStandingAmount()*-1);
                if (agentServiceLimitModel.getOutStandingAmount() > totalAmountAfterDiscount) {
                    Double newBalance = agentServiceLimitModel.getOutStandingAmount() + totalAmountAfterDiscount;
                    finalizeOrderModel.setNewBalance(newBalance*-1);
                } else {
                    Double newBalance = totalAmountAfterDiscount + agentServiceLimitModel.getOutStandingAmount();
                    finalizeOrderModel.setNewBalance(newBalance*-1);
                }
            }
                response.setFinalizeOrderModel(finalizeOrderModel);
                response.setStatus("Success");
                response.setResponseMessage("Order Status Updated Successfullys");
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                Double actualTotalAmount = orderModelFromDb.getTotalOrderAmount();
                Double discountAmount = actualTotalAmount * discountPercent / 100;
                Double totalAmountAfterDiscount = actualTotalAmount - discountAmount;
                FinalizeOrderModel finalizeOrderModel = new FinalizeOrderModel();
                finalizeOrderModel.setOrderTotal(orderModelFromDb.getTotalOrderAmount());
                finalizeOrderModel.setDiscounted(totalAmountAfterDiscount);
                finalizeOrderModel.setDiscountPercent(discountPercent);
                response.setFinalizeOrderModel(finalizeOrderModel);
                response.setStatus("Success");
                response.setResponseMessage("Order Status Updated Successfully");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




    public ResponseEntity<Response> getClosedOrders(@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<OrderModel> orderStatusFromDb = orderRepository.findByStatus("Finalize",pageable);
            //---true or false ----//
            boolean checkEmpty = !orderStatusFromDb.isEmpty();
            response.setStatus(checkEmpty ? "success" : "failure");
            response.setResponseMessage(checkEmpty ? "Order Found Successfully" : "No Finalize Order Found ");
            response.setDatas(checkEmpty ? orderStatusFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getReadyToFinalizeOrder(String keyWord,@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            //-------- searching for get Ready to finalize  like by %orderId----//
            Page<OrderDto> orderByFromDb = orderRepository.getSearchReadyToFinalizeOrder(keyWord,pageable);
            //---true or false ---//
            boolean checkEmpty = !orderByFromDb.isEmpty();
            response.setStatus(checkEmpty ? "success" : "failure");
            response.setResponseMessage(checkEmpty ? "Order Found Successfully" : "No Ready to Finalize Order Found By given Name");
            response.setDatas(checkEmpty ? orderByFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("fail");
            response.setResponseMessage("failure : " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getFinalizeOrder(String keyWord,@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            //------- searching for get finalize  like by %orderId----//
            Page<OrderDto> orderByFromDb = orderRepository.getSearchOrder(keyWord,pageable);
            boolean check = !orderByFromDb.isEmpty();
            response.setStatus(check ? "success" : "failure");
            response.setResponseMessage(check ? "Order Found Successfully" : "No Order Found By given Name");
            response.setDatas(check ? orderByFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> fetchOrderItemsForFactoryAssignment(String keyword,@PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<FactoryAssignDto> orderItemsFromDb;
            if (Objects.equals(keyword, "")){
                 orderItemsFromDb = orderRepository.getOrderItemsByOrderIdAll(pageable);
            }else {
                 orderItemsFromDb = orderRepository.getOrderItemsByOrderId(keyword,pageable);
            }
            boolean check = !orderItemsFromDb.isEmpty();
            response.setStatus(check ? "success" : "failure");
            response.setResponseMessage(check ? "orders retrieved successfully" : "No orders Found Please try again");
            response.setDatas(check ? orderItemsFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure ");
            response.setResponseMessage("failed" + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
    public ResponseEntity<Response> getDispatchItemsByOrderId(String keyword, String factoryId,
                                                              @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<DispatchItemsDto> dispatchItemsFromDb = orderRepository.getOrderDispatchDetails(keyword, factoryId, pageable);
            response.setResponseMessage(!dispatchItemsFromDb.isEmpty() ? "Successfully Retrieved orders" : "No Data Found");
            response.setStatus("Success");
            response.setDatas(dispatchItemsFromDb);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {

            response.setDatas(null);
            response.setResponseMessage(e.getMessage());
            response.setStatus("Fail");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
    public ResponseEntity<Response> getTotalDispatchDetails(String factoryId) {
        Response response = new Response();
        try {
            DispatchOrderDetailsDto dispatchOrderDetailsDto = orderRepository.totalDetails(factoryId);
            if (dispatchOrderDetailsDto == null) {
                response.setStatus("Failure");
                response.setResponseMessage("No dispatch details found.");
                return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
            }
            response.setStatus("Success");
            response.setResponseMessage("Dispatch details retrieved successfully.");
            response.setTotalOrderDetails(dispatchOrderDetailsDto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setData(null);
            response.setResponseMessage(e.getMessage());
            response.setStatus("fail");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        }
    }


//    public ResponseEntity<Response> editOrder(CreateOrderListModel editOrderListModel) {
//        Response response = new Response();
//        try {
//            // ---Scenario: Null or empty editOrderListModel, productId, or quantity ---//
//            if (editOrderListModel == null || editOrderListModel.getProductId() == null || editOrderListModel.getQuantity() == null) {
//                response.setStatus("Failure");
//                response.setResponseMessage("Invalid input data. productId or quantity cannot be null.");
//                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//            }
//
//            // --- Scenario: Empty productId or quantity --- ///
//            if (editOrderListModel.getProductId().isEmpty() || editOrderListModel.getQuantity().isEmpty()) {
//                response.setStatus("Failure");
//                response.setResponseMessage("productId or quantity cannot be empty.");
//                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//            }
//
//            // ---- Scenario: Mismatched sizes of productId and quantity lists ---- //
//            if (editOrderListModel.getProductId().size() != editOrderListModel.getQuantity().size()) {
//                response.setStatus("Failure");
//                response.setResponseMessage("ProductId and Quantity lists must have the same size.");
//                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//            }
//            // -------- Scenario: Duplicate product IDs in the productId list----------//
//            Set<String> uniqueProductIds = new HashSet<>(editOrderListModel.getProductId());
//            if (uniqueProductIds.size() != editOrderListModel.getProductId().size()) {
//                response.setStatus("Failure");
//                response.setResponseMessage("Duplicate product IDs are not allowed.");
//                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//            }
//
//            // --- Scenario: Quantity validation (must be a valid integer and cannot be zero or negative) --- //
//            List<Integer> quantities = editOrderListModel.getQuantity();
//            for (Integer quantity : quantities) {
//                if (quantity <= 0) {
//
//                    response.setStatus("Failure");
//                    response.setResponseMessage("Quantity cannot be zero or negative.");
//                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
//                }
//            }
//            //---  Retrieve the existing order ---//
//            Optional<OrderModel> existingOrderOptional = orderRepository.findById(editOrderListModel.getOrderId());
//            if (!existingOrderOptional.isPresent()) {
//                response.setStatus("Failure");
//                response.setResponseMessage("Order not found for ID: " + editOrderListModel.getOrderId());
//                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
//            }
//            OrderModel existingOrder = existingOrderOptional.get();
//
//            // --- Delete products not in the updated list --- //
//            List<OrderListModel> existingOrderItems = orderListRepository.findByOrderModel(existingOrder);
//            Set<String> updatedProductIds = new HashSet<>(editOrderListModel.getProductId());
//            existingOrderItems.forEach(item -> {
//                if (!updatedProductIds.contains(item.getProductModel().getProductId())) {
//                    orderListRepository.delete(item);
//                }
//            });
//            // ---- Update or add products ---- //
//            double totalOrderAmount = 0.0;
//            for (int i = 0; i < editOrderListModel.getProductId().size(); i++) {
//                String productId = editOrderListModel.getProductId().get(i);
//                int quantity = editOrderListModel.getQuantity().get(i);
//                //  --- Retrieve product details -- //
//                Optional<ProductModel> productOptional = productRepository.findById(productId);
//                if (!productOptional.isPresent()) {
//                    response.setStatus("Failure");
//                    response.setResponseMessage("Product not found for ID: " + productId);
//                    return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
//                }
//                ProductModel product = productOptional.get();
//
//                // ---Check if the product is already in the order  ----//
//                List<OrderListModel> existingItemsByProduct = orderListRepository.findByOrderModelAndProductModelProductId(existingOrder, productId);
//                OrderListModel orderItem;
//                if (!existingItemsByProduct.isEmpty()) {
//                    //------ Update existing item -----//
//                    orderItem = existingItemsByProduct.get(0);
//                    orderItem.setQuantity(quantity);
//                } else {
//                    //------- Add a new order item ---------//
//                    orderItem = new OrderListModel();
//                    OrderListModel orderListModelFromDb = orderListRepository.findFirstByOrderByCreatedOnDesc();
//                    String orderListId = orderListModelFromDb == null ? "OL00001" : "OL" + String.format("%05d", (Long.parseLong(orderListModelFromDb.getOrderListId().split("OL")[1]) + 1));
//                    while (orderListRepository.existsByOrderListId(orderListId)) {
//                        orderListId = "OL" + String.format("%05d", (Long.parseLong(orderListId.split("OL")[1]) + 1));
//                    }
//
//                    String newOrderListId = generateUniqueOrderListId();
//                    orderItem.setOrderListId(newOrderListId);
//                    orderItem.setOrderModel(existingOrder);
//                    orderItem.setProductModel(product);
//                    orderItem.setDeliveryStatus("Yet to dispatch");
//                    orderItem.setCreatedBy(editOrderListModel.getCreatedBy());
//                }
//
//                //--------- Calculate amounts -----------//
//                double productPrice = product.getPrice();
//                orderItem.setAmount(productPrice);
//                orderItem.setQuantity(quantity);
//                orderItem.setTotalAmount(productPrice * quantity);
//                totalOrderAmount += orderItem.getTotalAmount();
//
//                orderListRepository.save(orderItem);
//            }
//            existingOrder.setTotalOrderAmount(totalOrderAmount);
//            orderRepository.save(existingOrder);
//
//            response.setStatus("Success");
//            response.setResponseMessage("Order Updated Successfully");
//            return new ResponseEntity<>(response, HttpStatus.OK);
//
//        } catch (Exception e) {
//            response.setStatus("Failure");
//            response.setResponseMessage("Error: " + e.getMessage());
//            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }


    public ResponseEntity<Response> editOrder(CreateOrderListModel editOrderListModel) {
        Response response = new Response();
        try {
            if (editOrderListModel == null ||
                    editOrderListModel.getProductId() == null ||
                    editOrderListModel.getQuantity() == null ||
                    editOrderListModel.getProductId().isEmpty() ||
                    editOrderListModel.getQuantity().isEmpty() ||
                    editOrderListModel.getProductId().size() != editOrderListModel.getQuantity().size()) {

                response.setStatus("Failure");
                response.setResponseMessage("Invalid input: productId and quantity must be non-null, non-empty, and of the same size.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            // -------- Scenario: Duplicate product IDs in the productId list----------//
            Set<String> uniqueProductIds = new HashSet<>(editOrderListModel.getProductId());
            if (uniqueProductIds.size() != editOrderListModel.getProductId().size()) {
                response.setStatus("Failure");
                response.setResponseMessage("Duplicate product IDs are not allowed.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            // --- Scenario: Quantity validation (must be a valid integer and cannot be zero or negative) --- //
            List<Integer> quantities = editOrderListModel.getQuantity();
            for (Integer quantity : quantities) {
                if (quantity <= 0) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Quantity cannot be zero or negative.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
            }
            //---  Retrieve the existing order ---//
            Optional<OrderModel> existingOrderOptional = orderRepository.findById(editOrderListModel.getOrderId());
            if (!existingOrderOptional.isPresent()) {
                response.setStatus("Failure");
                response.setResponseMessage("Order not found for ID: " + editOrderListModel.getOrderId());
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            OrderModel existingOrder = existingOrderOptional.get();

            // --- Delete products not in the updated list --- //
            List<OrderListModel> existingOrderItems = orderListRepository.findByOrderModel(existingOrder);
            Set<String> updatedProductIds = new HashSet<>(editOrderListModel.getProductId());
            existingOrderItems.forEach(item -> {
                if (!updatedProductIds.contains(item.getProductModel().getProductId())) {
                    orderListRepository.delete(item);
                }
            });

            // ---- Update or add products ---- //
            double totalOrderAmount = 0.0;
            double totalOrderWeight = 0.0;

            for (int i = 0; i < editOrderListModel.getProductId().size(); i++) {
                String productId = editOrderListModel.getProductId().get(i);
                int quantity = editOrderListModel.getQuantity().get(i);

                // --- Retrieve product details -- //
                Optional<ProductModel> productOptional = productRepository.findById(productId);
                if (!productOptional.isPresent()) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Product not found for ID: " + productId);
                    return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
                }
                ProductModel product = productOptional.get();
                // --- false --- //
                if (!product.getStandard()) {
                    // -- New Logic: Check agent's location and match with product price -- //
                    Optional<AgentModel> AgentFromDb = agentRepository.findById(existingOrder.getAgentModel().getAgentId());
                    if (AgentFromDb.isPresent()) {
                        String agentLocationId = AgentFromDb.get().getLocationModel().getLocationId();
                        Optional<ProductPriceModel> locationPriceOptional = productPriceRepository
                                .findByProductIdAndLocationModelLocationId(productId, agentLocationId);

                        if (locationPriceOptional.isPresent()) {
                            //--- If location-specific price exists, use it --- //
                            product.setPrice(locationPriceOptional.get().getLocationPrice());
                        }
                    }
                }

                // ---Check if the product is already in the order  ----//
                List<OrderListModel> existingItemsByProduct = orderListRepository.findByOrderModelAndProductModelProductId(existingOrder, productId);
                OrderListModel orderItem;
                if (!existingItemsByProduct.isEmpty()) {
                    //------ Update existing item -----//
                    orderItem = existingItemsByProduct.get(0);
                    orderItem.setQuantity(quantity);
                } else {
                    //------- Add a new order item ---------//
                    orderItem = new OrderListModel();
                    OrderListModel orderListModelFromDb = orderListRepository.findFirstByOrderByCreatedOnDesc();
                    String orderListId = orderListModelFromDb == null ? "OL00001" : "OL" + String.format("%05d", (Long.parseLong(orderListModelFromDb.getOrderListId().split("OL")[1]) + 1));
                    while (orderListRepository.existsByOrderListId(orderListId)) {
                        orderListId = "OL" + String.format("%05d", (Long.parseLong(orderListId.split("OL")[1]) + 1));
                    }

                    String newOrderListId = generateUniqueOrderListId();
                    orderItem.setOrderListId(newOrderListId);
                    orderItem.setOrderModel(existingOrder);
                    orderItem.setProductModel(product);
                    orderItem.setDeliveryStatus("Yet to dispatch");
                    orderItem.setCreatedBy(editOrderListModel.getCreatedBy());
                }

                //--------- Calculate amounts -----------//
                double productPrice = product.getPrice();
                orderItem.setAmount(productPrice);
                orderItem.setUpdatedOn(new Date());
                orderItem.setQuantity(quantity);
                orderItem.setTotalAmount(productPrice * quantity);
                totalOrderAmount += orderItem.getTotalAmount();

                // --- Calculate weight for this product --- //--tons--//
                double productWeight = product.getWeightPerUnit() * quantity / 1000000;
                totalOrderWeight += productWeight;


                orderListRepository.save(orderItem);
            } // -- count items -- //
            int items = editOrderListModel.getProductId().size();

            existingOrder.setTotalOrderAmount(totalOrderAmount);
            existingOrder.setTotalOrderWeight(totalOrderWeight);
            existingOrder.setItems(items);
            orderRepository.save(existingOrder);

            response.setStatus("Success");
            response.setResponseMessage("Order Updated Successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




    public ResponseEntity<Response> createOrderFromShop(CreateOrderListModel createOrderListModelFromShop) {
        //----------Assign agent to tempid(shop)--------------if agent assigned order move to order_table and order_list_table//
        Response response = new Response();
        try {
            String agentId = createOrderListModelFromShop.getAgentId();
            Integer executiveId = createOrderListModelFromShop.getExecutiveId();
            List<String> tempIds = createOrderListModelFromShop.getTempId();

            // --- Find the agent --------//
            AgentModel agentModel = agentRepository.findByAgentId(agentId);
            if (agentModel == null) {
                throw new RuntimeException("Agent not found for ID: " + agentId);
            }

            List<ShopOrderModel> shopOrderModels = new ArrayList<>();

            if (tempIds != null && !tempIds.isEmpty()) {
                shopOrderModels = shopOrderRepository.findByTempIdIn(tempIds);
                if (shopOrderModels.isEmpty()) {
                    throw new RuntimeException("No Shop Orders found for the given tempIds.");
                }
            } else if (executiveId != null) {
                shopOrderModels = shopOrderRepository.findByExecutiveIdAndStatus(executiveId, "Active");
                if (shopOrderModels == null || shopOrderModels.isEmpty()) {
                    throw new RuntimeException("No Shop Orders found for Executive ID: " + executiveId);
                }
            } else {
                throw new RuntimeException("Either tempId or executiveId must be provided.");
            }

            int count = orderRepository.findCount(agentId) + 1;
            for (ShopOrderModel shopOrderModel : shopOrderModels) {
                // ---- Generate orderId for each shop order ------ //
                String orderId = generateOrderId(agentModel.getAgentName(), count);
                // -------- Move data from ShopOrder to Order table ----------//
                OrderModel orderModel = new OrderModel();
                orderModel.setOrderId(orderId);
                orderModel.setAgentModel(agentModel);
                orderModel.setStatus("Active");
                orderModel.setCreatedBy("ADMIN");
                orderModel.setItems(shopOrderModel.getItems());
                orderModel.setOrderBy(shopOrderModel.getOrderBy());
                orderModel.setTotalOrderAmount(shopOrderModel.getTotalOrderAmount());
                orderModel.setTotalOrderWeight(shopOrderModel.getTotalOrderWeight());
                orderModel.setShopModel(shopOrderModel.getShopModel());
                orderModel.setExecutiveId(shopOrderModel.getExecutiveId());
                orderRepository.save(orderModel);
                shopOrderModel.setStatus("Agent Assigned");
                shopOrderRepository.save(shopOrderModel);
                // -----------Move data from ShopOrderList to OrderList table----------//
                List<ShopOrderListModel> shopOrderListModels = shopOrderListRepository.findByShopOrderModelTempId(shopOrderModel.getTempId());
                for (ShopOrderListModel shopOrderListModel : shopOrderListModels) {
                    shopOrderListModel.setDeliveryStatus("Agent Assigned");
                    shopOrderListRepository.save(shopOrderListModel);
                    OrderListModel orderListModel = new OrderListModel();
                    orderListModel.setOrderModel(orderModel);
                    orderListModel.setProductModel(shopOrderListModel.getProductModel());
                    orderListModel.setQuantity(shopOrderListModel.getQuantity());
                    orderListModel.setAmount(shopOrderListModel.getAmount());
                    orderListModel.setTotalAmount(shopOrderListModel.getAmount() * shopOrderListModel.getQuantity());
                    orderListModel.setDeliveryStatus("Yet to dispatch");
                    orderListModel.setCreatedBy("ADMIN");
                    String orderListId = generateUniqueOrderListId();
                    orderListModel.setOrderListId(orderListId);
                    orderListRepository.save(orderListModel);
                }
                count++;
            }
            response.setStatus("Success");
            response.setResponseMessage("Agent assigned successfully.");
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {
            response.setStatus("Failure: " + e.getMessage());
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private String generateUniqueOrderListId() {
        OrderListModel latestOrderList = orderListRepository.findFirstByOrderByCreatedOnDesc();
        String orderListId = latestOrderList == null ? "OL00001" :
                "OL" + String.format("%05d", (Long.parseLong(latestOrderList.getOrderListId().split("OL")[1]) + 1));
        while (orderListRepository.existsByOrderListId(orderListId)) {
            orderListId = "OL" + String.format("%05d", (Long.parseLong(orderListId.split("OL")[1]) + 1));
        }
        return orderListId;
    }

    private String generateOrderId(String agentName, int count) {
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMM");
        String formattedDate = date.format(formatter);
        return agentName + "/" + formattedDate + "/" + count;
    }


}



