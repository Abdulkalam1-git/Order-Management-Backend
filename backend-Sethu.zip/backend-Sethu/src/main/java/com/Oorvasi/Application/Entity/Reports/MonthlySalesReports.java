package com.Oorvasi.Application.Entity.Reports;

import java.sql.Timestamp;

public interface MonthlySalesReports {
    Timestamp getMonth();
    Long getTotalAmount();
}
