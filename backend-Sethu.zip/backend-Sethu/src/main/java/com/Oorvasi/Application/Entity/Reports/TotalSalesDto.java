package com.Oorvasi.Application.Entity.Reports;

import java.math.BigDecimal;

public interface TotalSalesDto {

    Long getTotalSales();



}
