package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.UserRoleModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRoleRepository extends JpaRepository<UserRoleModel,Long> {
    List<UserRoleModel> findByUserId(String userId);

}
