package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "payment_table")
@Entity
public class PaymentModel {

    @Id
    private String paymentId;
    @OneToOne
    @JoinColumn(name = "transaction_id",nullable = false)
    private TransActionModel transActionModel;
    private Double amount;
    @OneToOne
    @JoinColumn(name = "payment_type_id",nullable = false)
    private PaymentTypeModel paymentTypeModel;
    private String status;
    private Date createdOn= new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;

}
