package com.Oorvasi.Application.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;
import java.util.List;
import java.util.stream.Stream;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ShopGroupByExecutive {
    private String executiveName;
    private Integer executiveId;
    private List<shopOrderGetDto> shops;
}
