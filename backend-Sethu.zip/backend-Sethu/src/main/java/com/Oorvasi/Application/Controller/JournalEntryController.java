package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.JournalEntryModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.JournalEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

@RequestMapping("/journal")
public class JournalEntryController {

    @Autowired
    private JournalEntryService journalEntryService ;

    @PostMapping("/create/entry")
    public ResponseEntity<Response> createEntry(@RequestBody JournalEntryModel journalEntryModel){
        return journalEntryService.createJournalEntry(journalEntryModel);
    }
}
