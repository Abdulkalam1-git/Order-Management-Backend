package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.StaffModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface StaffRepository extends JpaRepository<StaffModel ,Long> {
    boolean existsByPhoneNumber(String phoneNumber);
    List<StaffModel> findByDesignation(String designation);
    List<StaffModel> findByTeam(String team);

    @Query(value = "SELECT s.user_id AS userId, s.user_name AS userName, r.role AS role " +
            "FROM staffs AS s " +
            "INNER JOIN roles AS r ON s.role_id = r.role_id " +
            "WHERE (s.designation ILIKE %:keyword% OR s.full_name ILIKE %:keyword% OR s.team ILIKE %:keyword%) " +
            "ORDER BY s.created_on DESC", nativeQuery = true)
    Page<StaffDetailsRepository> findByKeyword(String keyword, Pageable pageable);

    Optional<Object> findByUserId(Long userIds);

    @Query(value = "select user_id as userId,user_name as userName,designation as designation ,r.role as role from staffs as s\n" +
            "inner join roles as r on s.role_id=r.role_id where user_id=:userId",nativeQuery = true)
    UserDetails findByStaffId(Long userId);
    @Query(value = "select user_id as executiveId,user_name as executiveName,area as area,city as city,state as state from staffs where designation='Sales Executive' and location_id=:locationId and user_name ilike %:keyword% ",nativeQuery = true)
    Page<UserDetails> findByLocationId(String locationId,String keyword,Pageable pageable);
}
