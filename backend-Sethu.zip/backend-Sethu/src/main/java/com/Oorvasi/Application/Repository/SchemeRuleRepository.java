package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.SchemeRulesModel;
import com.Oorvasi.Application.Model.SchemesModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface SchemeRuleRepository extends JpaRepository<SchemeRulesModel , String> {

    SchemeRulesModel findFirstByOrderByCreatedAtDesc();

    List<SchemeRulesModel> findByStatusAndCreatedAtBetween(String status, Date startDate, Date endDate);

    Optional<SchemeRulesModel> findBySchemeRuleIdAndDeletedAtIsNull(String schemeRuleId);

}
