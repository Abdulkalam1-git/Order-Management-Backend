package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.AgentHistoryTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentHistoryRepository extends JpaRepository<AgentHistoryTable,String> {
}
