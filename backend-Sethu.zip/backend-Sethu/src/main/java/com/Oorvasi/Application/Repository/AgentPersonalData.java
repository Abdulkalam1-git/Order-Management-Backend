package com.Oorvasi.Application.Repository;

public interface AgentPersonalData {


    String getAgentId();
    String getAgentName();
    String getArea();
    String getState();
    String getCity();
    Double getDiscountPercent();
    Double getAgentBalance();
}
