package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Entity.MarketZoneDto;
import com.Oorvasi.Application.Model.AgentModel;
import com.Oorvasi.Application.Model.LocationModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
public class
LocationService {

    @Autowired
    private LocationRepository locationRepository;

    public ResponseEntity<Response> addLocation(LocationModel locationModel) {
        Response response = new Response();
        try {
            LocationModel locationModelName = locationRepository.findByLocationName(locationModel.getLocationName());
            LocationModel locationModelShortCode = locationRepository.findByShortCode(locationModel.getShortCode());
            if (locationModelName!=null){
                response.setStatus("Failure");
                response.setResponseMessage("Location Name already Exists");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            if (locationModelShortCode!=null){
                response.setStatus("Failure");
                response.setResponseMessage("Short Code already Exists");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            LocationModel locationModelFromDb = locationRepository.findTop1ByOrderByCreatedOnDesc();
            String locationId = locationModelFromDb == null ? "LOC001" : "LOC" + String.format("%03d", (Long.parseLong(locationModelFromDb.getLocationId().split("LOC")[1]) + 1));
            while (locationRepository.existsByLocationId(locationId)) {
                locationId = locationModelFromDb == null ? "LOC001" : "LOC" + String.format("%03d", (Long.parseLong(locationId.split("LOC")[1]) + 1));
            }
            locationModel.setLocationId(locationId);
            locationModel.setStatus("Active");
            locationRepository.save(locationModel);
            response.setStatus("Success");
            response.setResponseMessage("Location added successfully");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getMarketZones(String search) {
        Response response = new Response();
        try {
            List<MarketZoneDto> marketZoneDetailFromDb = locationRepository.findAll(search);
            if (!marketZoneDetailFromDb.isEmpty()) {
                response.setStatus("success");
                response.setResponseMessage("Market Zones successfully retrieved");
                response.setData(marketZoneDetailFromDb);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }else {
                response.setStatus("Failure");
                response.setResponseMessage("Unable to get Market Zones");
                response.setData(marketZoneDetailFromDb);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getMarketZoneById(String locationId) {
        Response response = new Response();
        try {
            MarketZoneDto marketZoneFromDb = locationRepository.findMarketZoneByLocationId(locationId);
            if (marketZoneFromDb!=null){
                response.setStatus("success");
                response.setResponseMessage("Successfully retrieved the Zone for The LocationId "+locationId);
                response.setData(Collections.singletonList(marketZoneFromDb));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }else {
                response.setStatus("Failure");
                response.setResponseMessage("Zone for LocationId: "+locationId+" Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("fail");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> editMarketZone( LocationModel updateLocationModel) {
        Response response = new Response();
        try {
            LocationModel marketZoneDetailFromDb = locationRepository.findById(updateLocationModel.getLocationId()).orElse(null);
            if (marketZoneDetailFromDb != null) {

                if (!marketZoneDetailFromDb.getLocationName().equals(updateLocationModel.getLocationName())){
                    LocationModel locationModelName = locationRepository.findByLocationName(updateLocationModel.getLocationName());
                    if (locationModelName!=null){
                        response.setStatus("Failure");
                        response.setResponseMessage("Location Name already Exists");
                        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
                    }else {
                        marketZoneDetailFromDb.setLocationName(updateLocationModel.getLocationName());
                    }
                }
                if (!marketZoneDetailFromDb.getShortCode().equals(updateLocationModel.getShortCode())){
                    LocationModel locationModelShortCode = locationRepository.findByShortCode(updateLocationModel.getShortCode());
                    if (locationModelShortCode!=null){
                        response.setStatus("Failure");
                        response.setResponseMessage("Short Code already Exists");
                        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
                    }else {
                        marketZoneDetailFromDb.setShortCode(updateLocationModel.getShortCode());
                    }
                }
                marketZoneDetailFromDb.setUpdatedOn(new Date());
                locationRepository.save(marketZoneDetailFromDb);
                response.setStatus("Success");
                response.setResponseMessage("Zone for LocationId: "+marketZoneDetailFromDb.getLocationId()+" Updated Successfully");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
            else {
                response.setStatus("Failure");
                response.setResponseMessage("Zone for LocationId: "+updateLocationModel.getLocationId()+" Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public ResponseEntity<Response> deleteMarketZone(String locationId) {
        Response response = new Response();
        try {
            LocationModel marketZoneDetailFromDb = locationRepository.findById(locationId).orElse(null);
            if (marketZoneDetailFromDb != null) {
                marketZoneDetailFromDb.setStatus("InActive");
                locationRepository.save(marketZoneDetailFromDb);
                response.setStatus("Success");
                response.setResponseMessage("Zone for LocationId: "+locationId+" Deleted Successfully");
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                response.setStatus("Failure");
                response.setResponseMessage("Zone for LocationId: "+locationId+" Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
