package com.Oorvasi.Application.Entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@JsonInclude(JsonInclude.Include.ALWAYS)
public class shopOrderGetDto {
    private String shopId;
    private String shopName;
    private Double totalOrderWeight;
    private Double totalOrderAmount;
    private Double totalFreeOrderWeight;
    private String tempId;
}
