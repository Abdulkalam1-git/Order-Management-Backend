package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.AgentServiceLimitModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AgentServiceLimitRepository extends JpaRepository<AgentServiceLimitModel,String> {

    AgentServiceLimitModel findFirstByOrderByCreatedOnDesc();
    AgentServiceLimitModel findByAgentModel_AgentId(String agentId);

}
