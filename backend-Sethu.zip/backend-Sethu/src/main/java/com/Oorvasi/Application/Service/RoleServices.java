package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.RolePermissionRepository;
import com.Oorvasi.Application.Repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.*;

@Service
public class RoleServices {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
 private RolePermissionRepository rolePermissionRepository;

    public ResponseEntity<Response>createRole (RoleModel roleModel) {
        Response response = new Response();
        Role role = new Role();
        try {
            if (roleRepository.existsByRole(role.getRole())) {
                response.setStatus("Failure");
                response.setResponseMessage("Role name already exists.");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            String roleIdRegex = "ROLE";
            Role roleModelFromDb = roleRepository.findTop1ByRoleIdContainingOrderByCreatedOnDesc(roleIdRegex);
            String roleId = roleModelFromDb == null ? "ROLE001" : "ROLE" + String.format("%03d", (Long.parseLong(roleModelFromDb.getRoleId().split("ROLE")[1]) + 1));
            while (roleRepository.existsByRoleId(roleId)) {
                roleId = roleModelFromDb == null ? "ROLE001" : "ROLE" + String.format("%03d", (Long.parseLong(roleId.split("ROLE")[1]) + 1));
            }
            role.setRoleId(roleId);
            role.setRole(roleModel.getRole());
            role.setStatus("Active");
            role.setCreatedBy(roleModel.getCreatedBy());
            roleRepository.save(role);
            if (roleModel.getPermissions() != null && !roleModel.getPermissions().isEmpty()) {
                for (int i=0; i<roleModel.getPermissions().size(); i++) {
                    String rolePermissionIdRegex = "RP";
                    RolePermissionModel rolePermissionModeFromDb = rolePermissionRepository.findTop1ByRolePermissionIdContainingOrderByCreatedOnDesc(rolePermissionIdRegex);
                    String rolePermissionId = rolePermissionModeFromDb == null ? "RP001" : "RP" + String.format("%03d", (Long.parseLong(rolePermissionModeFromDb.getRolePermissionId().split("RP")[1]) + 1));
                    while (rolePermissionRepository.existsByRolePermissionId(rolePermissionId)) {
                        rolePermissionId = rolePermissionModeFromDb == null ? "RP" : "RP" + String.format("%03d", (Long.parseLong(rolePermissionId.split("RP")[1]) + 1));
                    }
                    RolePermissionModel rolePermissionModel = new RolePermissionModel();
                    PermissionModel permissionModel = new PermissionModel();
                    permissionModel.setPermissionId(roleModel.getPermissions().get(i));
                        rolePermissionModel.setRolePermissionId(rolePermissionId);
                        rolePermissionModel.setRole(role);
                        rolePermissionModel.setPermissionModel(permissionModel);
                        rolePermissionModel.setCreatedBy(roleModel.getCreatedBy());
                        rolePermissionRepository.save(rolePermissionModel);
                }
            }
            response.setStatus("Success");
            response.setResponseMessage("Role Created successfully");
            response.setData(Collections.singletonList(role));
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        }
        catch (Exception err) {
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled Error: " + err.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> getAllRoles(){
        Response responses=new Response();
        try{
            List<Role> role =  roleRepository.findAll();
            responses.setStatus("Success");
            responses.setData(role);
            return new ResponseEntity<>(responses, HttpStatus.OK);
        }
        catch (Exception e){
            responses.setStatus("Failure");
            responses.setResponseMessage(e.getLocalizedMessage());
            return new ResponseEntity<>(responses, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
