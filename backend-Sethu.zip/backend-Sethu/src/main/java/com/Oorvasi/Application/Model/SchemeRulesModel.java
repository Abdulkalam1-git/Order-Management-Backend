package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "scheme_rules_table")
public class SchemeRulesModel {
    @Id
    private String schemeRuleId;
    @ManyToOne
    @JoinColumn(name = "scheme_id")
    SchemesModel schemesModel;
    @Column(nullable = false, length = 50)
    private String conditionType;
    @Column(nullable = false, precision = 10, scale = 2)
    @Min(value = 1, message = "conditionValue  cannot be negative or zero ")
    private BigDecimal conditionValue;
    @Column(nullable = false, length = 50)
    private String rewardType;
    @Column(precision = 10, scale = 2)
    @Min(value = 1, message = "rewardValue  cannot be negative or zero ")
    private BigDecimal rewardValue;
    @OneToOne
    @JoinColumn(name = "free_product_id", nullable = true)
    ProductModel productModel;
    @Column(nullable = true)
    @Min(value = 0, message = "Free product quantity cannot be negative")
    private Integer freeProductQuantity;
    private Date createdAt = new Date();
    private Date updatedAt;
    private Date deletedAt;
    private String status;


}
