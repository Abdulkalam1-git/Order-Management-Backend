package com.Oorvasi.Application.Entity;

public interface AgentOrderListDetails {

       String getOrderId();
       String getOrderListId();
       String getProductId();
       String getProductName();
       Integer getPrice();
       Long getQuantity();
}
