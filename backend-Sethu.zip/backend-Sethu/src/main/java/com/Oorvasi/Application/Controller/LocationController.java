package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.LocationModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/location")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

public class LocationController {

    @Autowired
    private LocationService locationService;

    @PreAuthorize("hasAnyAuthority('Manage Zone')")
    @PostMapping(value = "create/zone")
    public ResponseEntity<Response> addData(@RequestBody LocationModel locationModel){
        return locationService.addLocation(locationModel);
    }
    @PreAuthorize("hasAnyAuthority('View Zone')")
    @GetMapping(value = "get/market-zones")
    public ResponseEntity<Response> getMarketZones(@RequestParam String search){
        return locationService.getMarketZones(search);
    }

    @PreAuthorize("hasAnyAuthority('Manage Zone')")
    @PutMapping(value= "edit/market-zones")
    public ResponseEntity<Response> editMarketZone(@RequestBody LocationModel updateLocationModel){
        return locationService.editMarketZone(updateLocationModel);
    }

    @PreAuthorize("hasAnyAuthority('Manage Zone')")
    @PostMapping(value = "delete/market-zones/{locationId}")
    public ResponseEntity<Response> deleteMarketZone(@PathVariable String locationId){
        return locationService.deleteMarketZone(locationId);
    }

    @PreAuthorize("hasAnyAuthority('View Zones Details')")
    @GetMapping(value = "get/singleZone")
    public ResponseEntity<Response> getMarketZoneById(@RequestParam String locationId){
        return locationService.getMarketZoneById(locationId);
    }
}
