package com.Oorvasi.Application.Model;

public enum UserRoleEnum {
    ADMIN,SUPER_ADMIN,DIRECTOR
}
