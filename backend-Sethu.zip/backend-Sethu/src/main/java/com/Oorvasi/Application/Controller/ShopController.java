package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

@RequestMapping(value = "/shop")
public class ShopController {


    @Autowired
    private ShopService shopService;


    @PreAuthorize("hasAnyAuthority('Manage Shop')")
    @PostMapping(value = "/create/shops")
    public ResponseEntity<Response> createShop(@RequestBody ShopModel shopModel) {
        return shopService.addShop(shopModel);
    }
    @PreAuthorize("hasAnyAuthority('Create SalesOrder')")
    @PostMapping(value = "/create/shop-order")
    public ResponseEntity<Response> createShopOrder(@RequestBody CreateShopOrderListModel createShopOrderList) {
        return shopService.createShopOrder(createShopOrderList);
    }

    @PreAuthorize("hasAnyAuthority('View Shop Details')")
    @GetMapping(value = "/get/shop-details")
    public ResponseEntity<Response> getShopDetails(@RequestParam String keyWord) {
        return shopService.getShop(keyWord);
    }
    @PreAuthorize("hasAnyAuthority('View Zone Shop')")
    @GetMapping(value = "/get/location-shop")
    public ResponseEntity<Response> getShopByLocation(@RequestParam String locationId,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable) {
        return shopService.getShopsBasedOnLocation(locationId,pageable);
    }

    @PreAuthorize("hasAnyAuthority('View Shop Details')")
    @GetMapping(value = "/get/single-shop")
    public ResponseEntity<Response> getSingleShop(@RequestParam String shopId) {
        return shopService.getSingleShop(shopId);
    }

    @PreAuthorize("hasAnyAuthority('Manage Shop')")
    @PutMapping(value = "/edit/shop")
    public ResponseEntity<Response> editShop(@RequestBody ShopModel updateShopModel) {
        return shopService.editShop(updateShopModel);
    }

    @PreAuthorize("hasAnyAuthority('Manage Shop')")
    @PostMapping(value = "/delete/shop/{shopId}")
    public ResponseEntity<Response> deleteShop(@PathVariable String shopId) {
        return shopService.deleteShop(shopId);
    }

    @PreAuthorize("hasAnyAuthority('View Recommended Agent')")
    @GetMapping(value = "/get/recommendedAgents")
    public ResponseEntity<Response> findRecommendedAndAllAgents(@RequestParam String shopId, @RequestParam String keyWord) {
        return shopService.findRecommendedAndAllAgents(shopId, keyWord);
    }
    @PreAuthorize("hasAnyAuthority('View All Agent')")
    @GetMapping(value = "/get/allAgents")
    public ResponseEntity<Response> findAllAgents( @RequestParam String keyWord,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable) {
        return shopService.findAllAgents(keyWord,pageable);
    }

    @PreAuthorize("hasAnyAuthority('View SalesOrder')")
    @GetMapping(value = "/get/shop-group-byExecutive")
    public ResponseEntity<Response> fetchShopsGroupedByExecutives(@RequestParam String keyWord,@RequestParam String locationId,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable) {
        return shopService.fetchShopsGroupedByExecutives(keyWord,locationId,pageable);
    }

    @PreAuthorize("hasAnyAuthority('View ShopOrder Detail')")
    @GetMapping(value = "/get/shop-orderList-detail")
    public ResponseEntity<Response> fetchShopOrderList(@RequestParam String ShopTempId) {
        return shopService.getShopOrderList(ShopTempId);
    }

}
