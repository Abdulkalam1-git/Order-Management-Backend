package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "agent_service_limit_table")
public class AgentServiceLimitModel {

    @Id
    private String agentServiceLimitId;
    @OneToOne
    @JoinColumn(name = "agent_id", nullable = false)
    AgentModel agentModel;
    private Double OutStandingAmount;
    private Double excessAmount;
    private String service;
    private String status;
    private Date createdOn;
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}
