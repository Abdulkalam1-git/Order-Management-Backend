package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "role_permission_table")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RolePermissionModel {
    @Id
    private String rolePermissionId;
    @OneToOne
    @JoinColumn(name = "permission_id",nullable = false)
    private PermissionModel permissionModel;
    @ManyToOne
    @JoinColumn(name = "role_id",nullable = false)
    private Role role;
    @Column(name = "created_on")
    private Date createdOn = new Date();
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "updated_on")
    private Date updatedOn;
    @Column(name = "updated_by")
    private String updatedBy;
}
