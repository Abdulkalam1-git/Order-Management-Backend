package com.Oorvasi.Application.Entity.Reports;

public interface MonthlySalesByYearTotal {

     Long getTotalSales();
     Long getTotalOrders();
}
