package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.AgentModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping(value = "/agent")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)
public class AgentController {

    @Autowired
    private AgentService agentService;

    @PreAuthorize("hasAnyAuthority('Manage Agents')")
    @PostMapping(value = "create/agent")
    public ResponseEntity<Response> createdAgent(@RequestBody AgentModel agentModel) {
        return agentService.createAgent(agentModel);
    }

    @PreAuthorize("hasAnyAuthority('View Single Agent')")
    @GetMapping(value = "get/single/agent")
    public ResponseEntity<Response> getSingleAgent(@RequestParam String agentId) {
        return agentService.getSingleAgent(agentId);
    }

    @PreAuthorize("hasAnyAuthority('View Zone Agent')")
    @GetMapping(value = "get/single/location-agent")
    public ResponseEntity<Response> getSingleLocationAgent(@RequestParam String locationId, String keyword, @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        return agentService.getLocationAgent(locationId, keyword, pageable);
    }

    @PreAuthorize("hasAnyAuthority('View Zone Agent')")
    @GetMapping(value = "search/agent")
    public ResponseEntity<Response> searchAgent(@RequestParam String search) {
        return agentService.searchAgent(search);
    }
    @PreAuthorize("hasAnyAuthority('Manage Agents')")
    @GetMapping("/get/singleAgent")
    public ResponseEntity<Response> getAgentById(@RequestParam String agentId) {
        return agentService.getAgentById(agentId);
    }

    @PreAuthorize("hasAnyAuthority('Manage Agents')")
    @PostMapping(value = "edit/agent")
    public ResponseEntity<Response> editAgent(@RequestBody AgentModel agentModel) {
        return agentService.editAgent(agentModel);
    }

    @PreAuthorize("hasAnyAuthority('Manage Agents')")
    @PostMapping(value = "delete/agent/{agentId}")
    public ResponseEntity<Response> deleteAgent(@PathVariable String agentId) {
        return agentService.deleteAgent(agentId);
    }


    @PreAuthorize("hasAnyAuthority('View Agent Details')")
    @GetMapping(value = "get/agentDetails")
    public ResponseEntity<Response> getAgentDetails(@RequestParam String agentId) {
        return agentService.getAgentDetailsById(agentId);
    }

    @PreAuthorize("hasAnyAuthority('View Agent Details')")
    @GetMapping(value = "get/Bar-Report")
    public ResponseEntity<Response> getAgentBarDetails(@RequestParam String agentId) {
        return agentService.getAgentYearlyAndMonthlyBarReportById(agentId);
    }

    @PreAuthorize("hasAnyAuthority('View Agent Details')")
    @GetMapping(value = "get/Agent-orderDetails")
    public ResponseEntity<Response> getAgentOrderDetails(@RequestParam String agentId, @RequestParam String keyWord) {
        return agentService.getAgentOrderDetails(agentId, keyWord);
    }

    @PreAuthorize("hasAnyAuthority('View Agent Details')")
    @GetMapping(value = "get/Agent-orderList")
    public ResponseEntity<Response> getAgentOrderListDetail(@RequestParam String orderId) {
        return agentService.getAgentOrderList(orderId);
    }


}
