package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.SchemesDto;
import com.Oorvasi.Application.Model.SchemesModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface SchemeRepository extends JpaRepository<SchemesModel ,String> {


        SchemesModel findFirstByOrderByCreatedAtDesc();
        List<SchemesDto> findByStatusAndCreatedAtBetween(String status, Date startDate, Date endDate);

        Optional<SchemesModel> findBySchemeIdAndDeletedAtIsNull(String schemeId);
        @Query(value = "select * from schemes_table where scheme_name iLike :schemeName",nativeQuery = true)
        SchemesModel findBySchemeName(String schemeName);

        @Query("SELECT s FROM SchemesModel s WHERE s.isGlobal = true AND s.startDate >= :startDate AND s.endDate <= :endDate ")
        List<SchemesModel> findAllGlobalSchemesByDate(Date startDate, Date endDate);






}
