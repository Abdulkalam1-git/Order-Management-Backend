package com.Oorvasi.Application.Entity;

public interface ShopOrderItemsDto {
    String getShopName();
    String getExecutiveName();
    String getLocationName();
    Double getTotalOrderWeight();
    Double getTotalOrderAmount();
    Double getTotalFreeOrderWeight();
}
