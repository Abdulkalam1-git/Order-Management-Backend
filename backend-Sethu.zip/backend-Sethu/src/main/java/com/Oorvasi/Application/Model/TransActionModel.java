package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "transaction_table")
public class TransActionModel {

    @Id
    private String transactionId;
    @OneToOne
    @JoinColumn(name = "agent_id",nullable = false)
    AgentModel agentModel;
    private Double amount;
    private String referenceNo;
    private String receivedBy;
    private Date receivedOn = new Date();
    private String status;
    private Date createdOn = new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}
