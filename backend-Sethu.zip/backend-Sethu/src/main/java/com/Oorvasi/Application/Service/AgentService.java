package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Entity.Reports.AgentDetailsDTO;
import com.Oorvasi.Application.Entity.Reports.ZoneBasedTotal;
import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.*;
import org.bouncycastle.pqc.math.ntru.HRSSPolynomial;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class AgentService {
    @Autowired
    private AgentRepository agentRepository;
    @Autowired
    private AgentServiceLimitRepository agentServiceLimitRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private AgentHistoryRepository agentHistoryRepository;

    public ResponseEntity<Response> createAgent(AgentModel agentModel) {
        Response response = new Response();
        try {
            if (agentModel.getAgentName() == null || agentModel.getPhoneNo() == null ||
                    agentModel.getCity() == null || agentModel.getArea() == null ||
                    agentModel.getState() == null) {
                response.setStatus("Failure");
                response.setResponseMessage("mandatory field must be filled");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            AgentModel agentModel1 = agentRepository.findByPhoneNo(agentModel.getPhoneNo());
            if (agentModel1 != null) {
                response.setStatus("Failure");
                response.setResponseMessage("agent phoneNo already exists  ");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            String agentIdRegex = "AGENT";
            AgentModel agentModelFromDb = agentRepository.findTop1ByAgentIdContainingOrderByCreatedOnDesc(agentIdRegex);
            String AgentId = agentModelFromDb == null ? "AGENT00001" : "AGENT" + String.format("%05d", (Long.parseLong(agentModelFromDb.getAgentId().split("AGENT")[1]) + 1));
            while (agentRepository.existsByAgentId(AgentId)) {
                AgentId = agentModelFromDb == null ? "AGENT00001" : "AGENT" + String.format("%05d", (Long.parseLong(AgentId.split("AGENT")[1]) + 1));
            }
            agentModel.setAgentId(AgentId);
            agentRepository.save(agentModel);
            //---Generate new id for agent if new ----//
            AgentServiceLimitModel agentServiceLimitModelFromDb = agentServiceLimitRepository.findFirstByOrderByCreatedOnDesc();
            String agentServiceLimitId = agentServiceLimitModelFromDb == null
                    ? "ASL00001"
                    : "ASL" + String.format("%05d", (Long.parseLong(agentServiceLimitModelFromDb.getAgentServiceLimitId().split("ASL")[1]) + 1));
            while (agentServiceLimitRepository.existsById(agentServiceLimitId)) {
                agentServiceLimitId = "ASL" + String.format("%05d", (Long.parseLong(agentServiceLimitId.split("ASL")[1]) + 1));
            }
            AgentServiceLimitModel newAgentServiceLimit = new AgentServiceLimitModel();
            newAgentServiceLimit.setAgentServiceLimitId(agentServiceLimitId);
            newAgentServiceLimit.setOutStandingAmount(0.0);
            newAgentServiceLimit.setExcessAmount(0.0);
            newAgentServiceLimit.setAgentModel(agentModel);
            newAgentServiceLimit.setCreatedOn(new Date());
            newAgentServiceLimit.setCreatedBy(agentModel.getCreatedBy());
            agentServiceLimitRepository.save(newAgentServiceLimit);
            response.setStatus("success");
            response.setResponseMessage("agent added successfully");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getSingleAgent(String agentId) {
        Response response = new Response();
        try {
            AgentModel agentModelFromDb = agentRepository.findByAgentId(agentId);
            List<OrderDto> orderDtos = orderRepository.getSingleAgentOrder(agentId);
            AgentServiceLimitModel agentServiceLimitModel = agentServiceLimitRepository.findByAgentModel_AgentId(agentId);
            AgentPersonalModel agentPersonalModel = new AgentPersonalModel();
            if (agentModelFromDb == null) {
                response.setStatus("Success");
                response.setResponseMessage("Agent Details not found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                agentPersonalModel.setAgentId(agentModelFromDb.getAgentId());
                agentPersonalModel.setAgentName(agentModelFromDb.getAgentName());
                agentPersonalModel.setCity(agentModelFromDb.getCity());
                agentPersonalModel.setState(agentModelFromDb.getState());
                agentPersonalModel.setArea(agentModelFromDb.getArea());
                agentPersonalModel.setDiscountPercent(agentModelFromDb.getDiscountPercent());
                agentPersonalModel.setAgentBalance(agentServiceLimitModel.getOutStandingAmount());
                response.setStatus("Success");
                response.setResponseMessage("Agent Details");
                AgentProfileModel agentProfileModel = new AgentProfileModel();
                agentProfileModel.setAgentPersonalModel(agentPersonalModel);
                agentProfileModel.setOrderModel(orderDtos);
                response.setData(Collections.singletonList(agentProfileModel));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getLocationAgent(String location_Id, String keyword, @PageableDefault(page = 0, size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            if (keyword.isEmpty()) {
                Page<AgentPersonalData> agentModelFromDb = agentRepository.findByLocation_Id(location_Id, pageable);
                boolean checkNull = !agentModelFromDb.isEmpty();
                response.setStatus(checkNull ? "success" : "failure");
                response.setResponseMessage(checkNull ? "Agent Details" : "No Details Found for Location");
                response.setDatas(checkNull ? agentModelFromDb : null);
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                Page<AgentPersonalData> agentModelFromDb = agentRepository.findByLocation_Ids(location_Id, keyword, pageable);
                boolean checkNull = !agentModelFromDb.isEmpty();
                response.setStatus(checkNull ? "success" : "failure");
                response.setResponseMessage(checkNull ? "Agent Details" : "NNo Details Found for Location");
                response.setDatas(checkNull ? agentModelFromDb : null);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> searchAgent(String search) {
        Response response = new Response();
        //search agent by name ------ or get All agents without Query//
        try {
            List<AgentModel> agentModelFromDb;
            agentModelFromDb = search == null || search.isEmpty() ? agentRepository.findAll() : agentRepository.findByAgentNameContainingIgnoreCase(search);
            boolean checkAgentModelNull = !agentModelFromDb.isEmpty();
            response.setStatus(checkAgentModelNull ? "success" : "failure");
            response.setResponseMessage(checkAgentModelNull ? " agent retrieve success " : "No agents found matching the search criteria.");
            response.setData(checkAgentModelNull ? agentModelFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("fail");
            response.setResponseMessage(e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> editAgent(AgentModel agentModel) {
        Response response = new Response();
        try {
            AgentModel agentModel1 = agentRepository.findByAgentId(agentModel.getAgentId());
            AgentHistoryTable agentHistoryTable = new AgentHistoryTable();
            agentHistoryTable.setAgentId(agentModel.getAgentId());
            if (agentModel1 != null) {
                if (agentModel.getAgentName() != null) {
                    agentModel1.setAgentName(agentModel.getAgentName());
                    agentHistoryTable.setAgentName(agentModel.getAgentName());
                }
                if (agentModel.getArea() != null) {
                    agentModel1.setArea(agentModel.getArea());
                    agentHistoryTable.setArea(agentModel.getArea());
                }
                if (agentModel.getCity() != null) {
                    agentModel1.setCity(agentModel.getCity());
                    agentHistoryTable.setCity(agentModel.getCity());
                }
                if (agentModel.getEmail() != null) {
                    agentModel1.setEmail(agentModel.getEmail());
                    agentHistoryTable.setEmail(agentModel.getEmail());
                }
                if (agentModel.getPhoneNo() != null) {
                    AgentModel agentModel2 = agentRepository.findByPhoneNo(agentModel.getPhoneNo());
                    if (agentModel2 != null && !agentModel1.getPhoneNo().equals(agentModel2.getPhoneNo())) {
                        response.setStatus("Failure");
                        response.setResponseMessage("agent phoneNo already exists  ");
                        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
                    }
                    agentModel1.setPhoneNo(agentModel.getPhoneNo());
                    agentHistoryTable.setPhoneNo(agentModel.getPhoneNo());

                }
                if (agentModel.getDiscountPercent() != null) {
                    agentModel1.setDiscountPercent(agentModel.getDiscountPercent());
                    agentHistoryTable.setDiscountPercent(agentModel.getDiscountPercent());
                }
                if (agentModel.getState() != null) {
                    agentModel1.setState(agentModel.getState());
                    agentHistoryTable.setState(agentModel.getState());

                }
                if (agentModel.getLocationModel() != null) {
                    agentModel1.setLocationModel(agentModel.getLocationModel());
                    agentHistoryTable.setLocationModel(agentModel.getLocationModel());
                } else {
                    agentHistoryTable.setLocationModel(agentModel1.getLocationModel());
                }
                if (agentModel.getAddressLine1() != null) {
                    agentModel1.setAddressLine1(agentModel.getAddressLine1());
                    agentHistoryTable.setAddressLine1(agentModel.getAddressLine1());
                }
                if (agentModel.getAddressLine2() != null) {
                    agentModel1.setAddressLine2(agentModel.getAddressLine2());
                    agentHistoryTable.setAddressLine2(agentModel.getAddressLine2());
                }
                if (agentModel.getBusinessName() != null) {
                    agentModel1.setBusinessName(agentModel.getBusinessName());
                    agentHistoryTable.setBusinessName(agentModel.getBusinessName());
                }
                if (agentModel.getUpdatedBy() != null) {
                    agentModel1.setUpdatedBy(agentModel.getUpdatedBy());
                    agentHistoryTable.setUpdatedBy(agentModel.getUpdatedBy());
                }
                agentRepository.save(agentModel1);
                agentHistoryTable.setStatus("Active");
                agentHistoryRepository.save(agentHistoryTable);
                response.setStatus("Success");
                response.setResponseMessage("Agent Updates Successfully");
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                response.setStatus("Failure");
                response.setResponseMessage("Agent Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled error:" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> deleteAgent(String agentId) {
        Response response = new Response();
        try {
            AgentModel agentModel = agentRepository.findByAgentId(agentId);
            if (agentModel == null) {
                response.setStatus("Failure");
                response.setResponseMessage("Agent Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                List<Object[]> agentModelList = agentRepository.findByAgentStatusAndId(agentId);
                if (!agentModelList.isEmpty()) {
                    response.setStatus("Failure");
                    response.setResponseMessage("Agent Has some order to finalize");
                    return new ResponseEntity<>(response, HttpStatus.NOT_ACCEPTABLE);
                } else {
                    agentModel.setStatus("InActive");
                    agentRepository.save(agentModel);
                    response.setStatus("Success");
                    response.setResponseMessage("Agent Deleted Successfully");
                    return new ResponseEntity<>(response, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled Error:" + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


//    public ResponseEntity<Response> agentReport(String agentId,Date startDate,Date endDate){
//        Response response= new Response();
//        try {
//            if (startDate==null&& endDate==null){
//               List<AgentMonthlyReportModel> agentMonthlyReportModel = agentRepository.findAgentReportMonthly(agentId);
//                AgentReportModel agentReportModel1 = agentRepository.findAgentReport(agentId);
//                if (agentMonthlyReportModel.isEmpty() && agentReportModel1.getCount()==-0){
//                    response.setStatus("Failure");
//                    response.setResponseMessage("No order details for this Agent");
//                    return new ResponseEntity<>(response,HttpStatus.NO_CONTENT);
//                }else {
//                    AgentOverAllReport agentOverAllReport = new AgentOverAllReport();
//                    agentOverAllReport.setAgentMonthlyReportModelList(agentMonthlyReportModel);
//                    agentOverAllReport.setAgentReportModel(agentReportModel1);
//                    response.setStatus("Success");
//                    response.setResponseMessage("Agent overAll Reports");
//                    response.setData(Collections.singletonList(agentOverAllReport));
//                    return new ResponseEntity<>(response,HttpStatus.OK);
//                }
//            }else {
//                AgentReportModel agentReportModel = agentRepository.findAgentReportSingleMonth(agentId,startDate,endDate);
//                if (agentReportModel!=null){
//                    response.setStatus("Success");
//                    response.setResponseMessage("Agent overAll Report");
//                    response.setData(Collections.singletonList(agentReportModel));
//                    return new ResponseEntity<>(response,HttpStatus.OK);
//                }else {
//                    response.setStatus("Failure");
//                    response.setResponseMessage("No order details for this Agent");
//                    return new ResponseEntity<>(response,HttpStatus.NO_CONTENT);
//                }
//            }
//        }catch (Exception e){
//            response.setStatus("Failure");
//            response.setResponseMessage("Unhandled Error :" + e.getMessage());
//            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

    public ResponseEntity<Response> getAgentDetailsById(String agentId) {
        Response response = new Response();
        try {
            AgentDetails agentDetails = agentRepository.agentDetails(agentId);
            if (agentDetails == null) {
                response.setResponseMessage("no agent found : " + agentId);
                response.setStatus("failure");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("agentDetails fetched successfully");
                response.setData(Collections.singletonList(agentDetails));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAgentYearlyAndMonthlyBarReportById(String agentId) {
        Response response = new Response();
        try {
            ZoneBasedTotal agentTotalDetails = agentRepository.findTotalYearBarReport(agentId);
            List<AgentMonthlyReportModel> agentMonthlyReportModel = agentRepository.findAgentReportMonthly(agentId);

            if (agentTotalDetails == null || agentMonthlyReportModel == null) {
                response.setResponseMessage("no agent details found : " + agentId);
                response.setStatus("success");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {

                response.setStatus("success");
                response.setResponseMessage("agent Details fetched successfully ");
                response.setData(Collections.singletonList(new CombinedBarDetails(agentTotalDetails, agentMonthlyReportModel)));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("failure " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAgentOrderDetails(String agentId, String keyWord) {
        Response response = new Response();
        try {
            List<AgentOrderDetailsDto> agentDetailsDTOS = agentRepository.findAgentOrderDetails(agentId, keyWord);
            if (agentDetailsDTOS == null) {
                response.setResponseMessage("no orderDetails found for agentId " + agentId);
                response.setStatus("success");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("orderDetails found successfully ");
                response.setData(Collections.singletonList(agentDetailsDTOS));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage("failure " + e.getMessage());
            response.setStatus("failure");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAgentOrderList(String orderId) {
        Response response = new Response();
        try {
            List<AgentOrderListDetails> agentOrderListDetails = agentRepository.agentOrderList(orderId);

            if (agentOrderListDetails == null) {
                response.setStatus("success");
                response.setResponseMessage("no orderList found for this orderId" + orderId);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setResponseMessage("orderList found successfully ");
                response.setStatus("success");
                response.setData(Collections.singletonList(agentOrderListDetails));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("failure " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAgentById(String agentId) {
        Response response = new Response();
        try {
            AgentModel agentModel = agentRepository.findById(agentId)
                    .orElseThrow(() -> new Exception("Agent not found with id: " + agentId));

            response.setStatus("success");
            response.setResponseMessage("Agent retrieve success");
            response.setData(Collections.singletonList(agentModel));
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("fail");
            response.setResponseMessage(e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
}
