package com.Oorvasi.Application.Entity.Reports;

public interface TotalOutstandingDto {
      Double getTotalOutStanding();
}
