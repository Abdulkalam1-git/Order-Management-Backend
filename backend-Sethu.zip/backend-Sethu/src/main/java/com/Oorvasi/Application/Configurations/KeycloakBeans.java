package com.Oorvasi.Application.Configurations;

import lombok.Data;
import org.keycloak.OAuth2Constants;
import org.keycloak.adapters.springsecurity.KeycloakConfiguration;
import org.keycloak.admin.client.KeycloakBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author arulmurugan
 *
 * KeycloakBeans is a Spring Configuration class responsible for creating and providing the Keycloak client instance
 * used to interact with the Keycloak Admin API. This class is annotated with {@link KeycloakConfiguration} to enable
 * integration with Keycloak's Spring Security Adapter.
 *
 * <p>The {@link KeycloakBeans} client instance created by this class allows for programmatic access to the Keycloak
 * server, enabling operations such as managing users, roles, and clients.</p>
 *
 * <p>This class is intended for use in applications that require interaction with Keycloak to perform administrative
 * tasks, such as managing realms, clients, and users. It is configured to use the Client Credentials Grant flow for
 * authentication with the Keycloak server.</p>
 *
 * <p>Note: The static configuration parameters (such as realm name, client ID, and secret) should be externalized
 * in a production environment (e.g., via application properties) rather than hardcoded in this class.</p>
 */
@Data
@Configuration
@KeycloakConfiguration
@SuppressWarnings("unused")
public class KeycloakBeans {

    private static String REALMS;
    private static String CLIENT_ID;
    private static String CLIENT_URL;
    private static String CLIENT_USERNAME;
    private static String CLIENT_PASSWORD;
    private static String CLIENT_SECRET_KEY;

    static {
        REALMS = "Oorvasi";
        CLIENT_ID = "admin-cli";
        CLIENT_URL = "https://auth.vinbytes.com";
        CLIENT_USERNAME = "admin";
        CLIENT_PASSWORD = "Password";
        CLIENT_SECRET_KEY = "UcOlcaIxb2Jo5V1w6fxtgpthFYovKX10";
    }


    /**
     * Creates and returns an instance of the {@link org.keycloak.admin.client.Keycloak} client used for
     * administrative tasks.
     * <p>
     * This client is configured using the Client Credentials Grant flow and the provided realm, client ID,
     * username, password, and secret key. It will allow for communication with the Keycloak server to manage
     * realms, clients, users, and other administrative tasks.
     * </p>
     *
     * @return a {@link org.keycloak.admin.client.Keycloak} instance configured with the specified parameters.
     */
    @Bean
    public org.keycloak.admin.client.Keycloak keycloak(){
        return KeycloakBuilder
                .builder()
                .serverUrl(CLIENT_URL)
                .realm(REALMS)
                .grantType(OAuth2Constants.CLIENT_CREDENTIALS)
                .clientId(CLIENT_ID)
                .username(CLIENT_USERNAME)
                .password(CLIENT_PASSWORD)
                .clientSecret(CLIENT_SECRET_KEY)
                .build();
    }


}
