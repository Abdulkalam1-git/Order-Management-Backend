package com.Oorvasi.Application.Entity;

public interface ShopOrderListProductDto {
    String getProductName();
    Double getQuantity();
    Double getAmount();
    Double getTotalAmount();
}
