package com.Oorvasi.Application.Entity.Reports;

public interface SalesForMonthDto {
    Long getTotalSales();
    Long getTotalOrders();
    Long getTotalAmount();
    String getMonth();


}
