package com.Oorvasi.Application.Entity;

import java.util.List;

public interface LocationPriceDto {
    List<String> getLocationName();
    List<Double> getLocationPrice();
}
