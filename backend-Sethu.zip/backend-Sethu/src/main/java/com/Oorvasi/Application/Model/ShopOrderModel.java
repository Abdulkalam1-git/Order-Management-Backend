package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "shop_order_table")
public class ShopOrderModel {

    @Id
    private String tempId;
    private Integer executiveId;
    private String executiveName;
    private String orderBy;
    private Date orderOn = new Date();
    private Integer items;
    private Double totalOrderAmount;
    private Double totalOrderWeight;
    private Double totalFreeOrderWeight;
    @OneToOne
    @JoinColumn(name = "shop_id", nullable = false)
    ShopModel shopModel;
    private String status;
    private Date createdOn = new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}