package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "product_price_table")
public class ProductPriceModel {
    @Id
    private String locationPriceId;
    private Double locationPrice;
    @OneToOne
    @JoinColumn(name = "location_id",nullable = false)
    LocationModel locationModel;
    private String productId;
    private String status;
    private Date createdOn = new Date();
    private String createdBy;
    private Date updatedOn;
    private String updateBy;
}
