package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Entity.ItemAndPriceDto;
import com.Oorvasi.Application.Entity.ItemDetailDto;
import com.Oorvasi.Application.Entity.ItemDto;
import com.Oorvasi.Application.Entity.LocationPriceDto;
import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.LocationRepository;
import com.Oorvasi.Application.Repository.ProductHistoryRepository;
import com.Oorvasi.Application.Repository.ProductPriceRepository;
import com.Oorvasi.Application.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductPriceRepository productPriceRepository;

    @Autowired
    private LocationRepository locationRepository;
    @Autowired
    private ProductHistoryRepository productHistoryRepository;

    public ResponseEntity<Response> getItems(String search,@PageableDefault(page = 0, size = 10, sort = "created_on", direction = Sort.Direction.DESC) Pageable pageable) {
        Response response = new Response();
        try {
            Page<ItemDto> getItemsFromDb = productRepository.findAllItems(search,pageable);
            Boolean checkNull = !getItemsFromDb.isEmpty();
            response.setStatus(checkNull ? "success " : "failure ");
            response.setResponseMessage(checkNull ? "Items successfully retrieved " : " No Items Found ");
            response.setDatas(checkNull ? getItemsFromDb : null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> addProduct(CreateProductModel createProductModel) {
        Response response = new Response();
        try {
            Boolean isStandard = createProductModel.getStandard() != null ? createProductModel.getStandard() : true;
            if (!isStandard) {
                if (createProductModel.getLocationId() == null || createProductModel.getLocationId().isEmpty() ||
                        createProductModel.getLocationPrice() == null || createProductModel.getLocationPrice().isEmpty() ||
                        createProductModel.getLocationId().size() != createProductModel.getLocationPrice().size()) {
                    response.setStatus("Failure");
                    response.setResponseMessage("LocationName and Price must not be empty, and sizes must match for location-based pricing.");
                    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                }
            }
            ProductModel productModelFromDb = productRepository.findFirstByOrderByCreatedOnDesc();
            String productId = productModelFromDb == null
                    ? "PRD00001"
                    : "PRD" + String.format("%05d", (Long.parseLong(productModelFromDb.getProductId().split("PRD")[1]) + 1));
            while (productRepository.existsByProductId(productId)) {
                productId = "PRD" + String.format("%05d", (Long.parseLong(productId.split("PRD")[1]) + 1));
            }
            ProductModel productModel = new ProductModel();
            productModel.setProductId(productId);
            productModel.setProductName(createProductModel.getProductName());
            //negative or zero checking ----//
            Integer unitBox = createProductModel.getUnitPerBox();
            if (unitBox == null || unitBox <= 0) {
                throw new RuntimeException("UnitPerBox must be a positive integer.");
            }
            Double boxWeight = createProductModel.getBoxWeight();
            if (boxWeight == null || boxWeight <= 0) {
                throw new RuntimeException("BoxWeight must be a positive number.");
            }
            Double weightPerUnit = createProductModel.getWeightPerUnit();
            if (weightPerUnit == null || weightPerUnit <= 0) {
                throw new RuntimeException("WeightPerUnit must be a positive number.");
            }
            Double price = createProductModel.getPrice();
            if (price == null || price <= 0) {
                throw new RuntimeException("Price must be a positive number ");
            }
            productModel.setUnitPerBox(createProductModel.getUnitPerBox());
            productModel.setBoxWeight(createProductModel.getBoxWeight());
            productModel.setWeightPerUnit(createProductModel.getWeightPerUnit());
            productModel.setStatus("Active");
            productModel.setPrice(createProductModel.getPrice());
            productModel.setCreatedOn(new Date());
            productModel.setCreatedBy(createProductModel.getCreatedBy());
            productModel.setUpdatedOn(createProductModel.getUpdatedOn());
            productModel.setUpdatedBy(createProductModel.getUpdatedBy());
            productModel.setStandard(isStandard);
            productRepository.save(productModel);
            if (!isStandard) {
                long lastId = productPriceRepository.count();
                List<ProductPriceModel> productPriceModels = new ArrayList<>();
                for (int i = 0; i < createProductModel.getLocationId().size(); i++) {
                    String locationId = createProductModel.getLocationId().get(i);
                    LocationModel locationModel = locationRepository.findById(locationId).orElseThrow(() -> new RuntimeException("Location not found"));
                    ProductPriceModel productPriceModel = new ProductPriceModel();
                    productPriceModel.setLocationPriceId("LPR" + String.format("%05d", ++lastId));
                    productPriceModel.setProductId(productId);
                    productPriceModel.setLocationModel(locationModel);
                    productPriceModel.setLocationPrice(createProductModel.getLocationPrice().get(i));
                    productPriceModel.setStatus("Active");
                    productPriceModel.setCreatedOn(new Date());
                    productPriceModel.setCreatedBy(createProductModel.getCreatedBy());
                    productPriceModels.add(productPriceModel);
                }
                productPriceRepository.saveAll(productPriceModels);
            }
            response.setStatus("Success");
            response.setResponseMessage("Product added successfully.");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setResponseMessage("Failure: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getItemById(String productId) {
        Response response = new Response();

        try {
            ItemAndPriceDto itemAndPriceDto = new ItemAndPriceDto();
            ProductModel productModel = new ProductModel();
            List<ItemDetailDto> productModelFromDb = productRepository.findProduct(productId);
            if (productModelFromDb.isEmpty()) {
                throw new RuntimeException("id not found");
            }
            List<LocationPriceDto> priceFromDto = productRepository.findPrice(productId);
            itemAndPriceDto.setViewItem(productModelFromDb);
            itemAndPriceDto.setPriceDetails(priceFromDto);
            response.setData(Collections.singletonList(itemAndPriceDto));
            response.setStatus("success");
            response.setResponseMessage("product successfully retrieved");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setData(null);
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public ResponseEntity<Response> editProduct(CreateProductModel updateProductModel) {
        Response response = new Response();
        try {
            ProductModel productModel = productRepository.findByProductIdAndStatus(updateProductModel.getProductId(),"Active");
            if (productModel==null){
                throw new RuntimeException("Product Not found.");
            }else {
                ProductHistoryTable productHistoryTable = new ProductHistoryTable();
                if (updateProductModel.getUnitPerBox() != null) {
                    Integer unitBox = updateProductModel.getUnitPerBox();
                    if (unitBox <= 0) {
                        throw new RuntimeException("UnitPerBox must be a positive integer.");
                    } else {
                        productModel.setUnitPerBox(updateProductModel.getUnitPerBox());
                        productHistoryTable.setUnitPerBox(updateProductModel.getUnitPerBox());
                    }
                }
                if (updateProductModel.getBoxWeight() != null) {
                    Double boxWeight = updateProductModel.getBoxWeight();
                    if (boxWeight <= 0) {
                        throw new RuntimeException("BoxWeight must be a positive number.");
                    } else {
                        productModel.setBoxWeight(updateProductModel.getBoxWeight());
                        productHistoryTable.setBoxWeight(updateProductModel.getBoxWeight());
                    }
                }
                if (updateProductModel.getWeightPerUnit() != null) {
                    Double weightPerUnit = updateProductModel.getWeightPerUnit();
                    if (weightPerUnit <= 0) {
                        throw new RuntimeException("WeightPerUnit must be a positive number.");
                    } else {
                        productModel.setWeightPerUnit(updateProductModel.getWeightPerUnit());
                        productHistoryTable.setWeightPerUnit(updateProductModel.getWeightPerUnit());
                    }
                }
                if (updateProductModel.getPrice() != null) {
                    Double prices = updateProductModel.getPrice();
                    if (prices <= 0) {
                        throw new RuntimeException("Price must be a positive number ");
                    } else {
                        productModel.setPrice(updateProductModel.getPrice());
                        productHistoryTable.setPrice(updateProductModel.getPrice());
                    }
                }
                if (updateProductModel.getProductName() != null) {
                    productModel.setProductName(updateProductModel.getProductName());
                    productHistoryTable.setProductName(updateProductModel.getProductName());
                }
                productModel.setUpdatedOn(new Date());
                productModel.setStandard(updateProductModel.getStandard());
                productHistoryTable.setUpdatedOn(new Date());
                productHistoryTable.setStandard(updateProductModel.getStandard());
                if (updateProductModel.getStandard()) {
                    //--true---//
                    if (updateProductModel.getLocationId() != null && !updateProductModel.getLocationId().isEmpty()) {
                        response.setStatus("Failure");
                        response.setResponseMessage("LocationId must be empty for standard pricing.");
                        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                    }
                    if (updateProductModel.getLocationPrice() != null && !updateProductModel.getLocationPrice().isEmpty()) {
                        response.setStatus("Failure");
                        response.setResponseMessage("LocationPrice must be empty for standard pricing.");
                        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                    }
                } else {
                    //---false---//
                    List<String> locationIds = updateProductModel.getLocationId();
                    List<Double> locationPrices = updateProductModel.getLocationPrice();

                    if (locationIds == null || locationPrices == null || locationIds.isEmpty() || locationPrices.isEmpty()
                            || locationIds.size() != locationPrices.size()) {
                        response.setStatus("Failure");
                        response.setResponseMessage("LocationId and LocationPrice must not be empty, and their sizes must match.");
                        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                    }

                    List<ProductPriceModel> existingEntriesFromDb = productPriceRepository.findByProductId(updateProductModel.getProductId());
                    Map<String, ProductPriceModel> existingMap = existingEntriesFromDb.stream()
                            .collect(Collectors.toMap(e -> e.getLocationModel().getLocationId(), entry -> entry));

                    for (int i = 0; i < locationIds.size(); i++) {
                        String locationId = locationIds.get(i);
                        Double price = locationPrices.get(i);

                        if (!existingMap.containsKey(locationId)) {
                            response.setStatus("Failure");
                            response.setResponseMessage("Modifying LocationId is not found .");
                            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
                        }
                        //--override-- price //
                        ProductPriceModel existingEntryFromDb = existingMap.get(locationId);
                        existingEntryFromDb.setLocationPrice(price);
                        existingEntryFromDb.setStatus("Active");
                        existingEntryFromDb.setUpdatedOn(new Date());
                        existingEntryFromDb.setUpdateBy("admin");
                        productPriceRepository.save(existingEntryFromDb);
                    }
                }
                productRepository.save(productModel);
                productHistoryRepository.save(productHistoryTable);
                response.setStatus("Success");
                response.setResponseMessage("Product updated successfully.");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> deleteItem(String productId) {
        Response response = new Response();
        try {
            ProductModel ItemFromDb = productRepository.findById(productId).orElseThrow(() -> new RuntimeException("Item not found by this id "));
            ItemFromDb.setStatus("inActive");
            productRepository.save(ItemFromDb);
            response.setResponseMessage("Item deleted successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
