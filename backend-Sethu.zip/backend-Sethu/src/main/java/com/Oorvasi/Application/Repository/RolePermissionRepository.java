package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.RolePermissionModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RolePermissionRepository extends JpaRepository<RolePermissionModel,Long> {
    @Query(value = "select p.permission_name from role_permission_table as rp\n" +
            "inner join permission_table as p on p.permission_id=rp.permission_id where rp.role_id=?1\n",nativeQuery = true)
    List<String> findPermissionsByRoleId(String roleId);

    RolePermissionModel findTop1ByRolePermissionIdContainingOrderByCreatedOnDesc(String rolePermissionIdRegex);

    boolean existsByRolePermissionId(String rolePermissionId);
}
