package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "product_history_table")
@Entity
public class ProductHistoryTable {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer productEditId;
    private String productId;
    private String productName;
    private Double price;
    private Double weightPerUnit;
    private Integer unitPerBox;
    private Double boxWeight;
    private String status;
    private Date createdOn;
    private String createdBy;
    private Date updatedOn = new Date();
    private String updatedBy;
    private Boolean Standard;

}
