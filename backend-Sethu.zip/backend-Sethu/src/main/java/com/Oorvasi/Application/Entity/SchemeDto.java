package com.Oorvasi.Application.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SchemeDto {
        private String schemeId;
        private String schemeName;
        private String description;
        private Date startDate;
        private Date endDate;
        private Boolean isActive;
        private Boolean isGlobal;
        private List<SchemeRuleDTO> rules = new ArrayList();

}
