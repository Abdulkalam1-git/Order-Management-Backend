package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Model.*;
import com.Oorvasi.Application.Repository.ProductRepository;
import com.Oorvasi.Application.Repository.SchemeProductRepository;
import com.Oorvasi.Application.Repository.SchemeRepository;
import com.Oorvasi.Application.Repository.SchemeRuleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
public class SchemeService {

    @Autowired
    private SchemeRepository schemeRepository;
    @Autowired
    private SchemeRuleRepository schemeRuleRepository;
    @Autowired
    private SchemeProductRepository schemeProductRepository;
    @Autowired
    private ProductRepository productRepository;

    public ResponseEntity<Response> createScheme(SchemesModel schemesModel) {

        Response response = new Response();
        try {
            SchemesModel schemeName = schemeRepository.findBySchemeName(schemesModel.getSchemeName());
            if (schemeName != null) {
                response.setStatus("failure");
                response.setResponseMessage("schemeName is already exists");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            SchemesModel schemeDetailFromDb = schemeRepository.findFirstByOrderByCreatedAtDesc();
            String schemeId = schemeDetailFromDb == null ? "SCH0001" : "SCH" + String.format("%04d", Long.parseLong(schemeDetailFromDb.getSchemeId().split("SCH")[1]) + 1);
            while (schemeRepository.existsById(schemeId)) {
                schemeId = schemeDetailFromDb == null ? "SCH0001" : "SCH" + String.format("%04d", Long.parseLong(schemeDetailFromDb.getSchemeId().split("SCH")[1]) + 1);
            }
            schemesModel.setStatus("Active");
            schemesModel.setSchemeId(schemeId);
            schemeRepository.save(schemesModel);
            response.setResponseMessage("scheme added successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("failure " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getSchemesDetails(String status ,Date startDate  , Date endDate) {
        Response response = new Response();
        try {
            List<SchemesDto> schemesDetailsFromDb = schemeRepository.findByStatusAndCreatedAtBetween(status,  startDate , endDate);
            if (schemesDetailsFromDb.isEmpty()) {
                response.setResponseMessage("no schemes found");
                response.setStatus("success");
                response.setData(null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("scheme retrieved successfully");
                response.setData(schemesDetailsFromDb);
                return ResponseEntity.ok(response);
            }
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("failure " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> updateScheme(SchemesModel updatedSchemeData) {
        Response response = new Response();
        try {
            String schemeId = updatedSchemeData.getSchemeId();
            System.out.println(schemeId);
            if (schemeId == null || schemeId.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("Scheme ID is required");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            SchemesModel existingScheme = schemeRepository.findById(schemeId).orElseThrow(() -> new RuntimeException("No scheme found for ID: " + schemeId));

            SchemesModel existingSchemeByName = schemeRepository.findBySchemeName(updatedSchemeData.getSchemeName());
            if (existingSchemeByName != null && !existingSchemeByName.getSchemeId().equals(schemeId)) {
                response.setStatus("failure");
                response.setResponseMessage("Scheme name already exists");
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }
            existingScheme.setSchemeName(updatedSchemeData.getSchemeName());
            existingScheme.setDescription(updatedSchemeData.getDescription());
            existingScheme.setStartDate(updatedSchemeData.getStartDate());
            existingScheme.setEndDate(updatedSchemeData.getEndDate());
            existingScheme.setIsActive(updatedSchemeData.getIsActive());
            existingScheme.setIsGlobal(updatedSchemeData.getIsGlobal());
            existingScheme.setUpdatedAt(new Date());
            schemeRepository.save(existingScheme);

            response.setResponseMessage("Scheme updated successfully");
            response.setStatus("success");
            response.setData(Collections.singletonList(existingScheme));
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> deleteScheme(String schemeId) {
        Response response = new Response();
        try {
            SchemesModel schemesModelFromDbById = schemeRepository.findBySchemeIdAndDeletedAtIsNull(schemeId).orElseThrow(() -> new RuntimeException("no data found"));
            schemesModelFromDbById.setStatus("InActive");
            schemesModelFromDbById.setDeletedAt(new Date());
            schemeRepository.save(schemesModelFromDbById);
            response.setResponseMessage("scheme deleted successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public ResponseEntity<Response> createSchemeProduct(CreateSchemeProductModel createSchemeProductModel) {
        Response response = new Response();
        try {
            if (createSchemeProductModel.getSchemeId() == null || createSchemeProductModel.getSchemeId().isEmpty()) {
                throw new RuntimeException("Scheme ID cannot be empty.");
            }
            if (createSchemeProductModel.getProductId().isEmpty()) {
                throw new RuntimeException("Product ID list cannot be empty.");
            }

            SchemesModel schemeFromDb = schemeRepository.findById(createSchemeProductModel.getSchemeId())
                    .orElseThrow(() -> new RuntimeException("No scheme found for ID: " + createSchemeProductModel.getSchemeId()));

            List<ProductModel> productsFromDb = createSchemeProductModel.getProductId().stream()
                    .map(productId -> productRepository.findById(productId)
                            .orElseThrow(() -> new RuntimeException("No product details found for ID: " + productId)))
                    .toList();

            SchemeProductsModel latestSchemeProduct = schemeProductRepository.findFirstByOrderByCreatedAtDesc();
            long nextIdNumber = latestSchemeProduct == null ? 1 : Long.parseLong(latestSchemeProduct.getSchemeProductId().replace("SCP", "")) + 1;

            for (ProductModel product : productsFromDb) {
                String schemeProductId = String.format("SCP%04d", nextIdNumber++);

                SchemeProductsModel schemeProductsModel = new SchemeProductsModel();
                schemeProductsModel.setStatus("Active");
                schemeProductsModel.setSchemeProductId(schemeProductId);
                schemeProductsModel.setSchemesModel(schemeFromDb);
                schemeProductsModel.setProductModel(product);
                schemeProductsModel.setCreatedAt(new Date());

                schemeProductRepository.save(schemeProductsModel);
            }

            response.setResponseMessage("Scheme applied to all products successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAllProductsScheme() {
        Response response = new Response();
        try {
            List<SchemeProductsModel> schemeModelFromDb = schemeProductRepository.findByStatus("Active");
            if (schemeModelFromDb.isEmpty()) {
                response.setData(null);
                response.setStatus("success");
                response.setResponseMessage("no Data Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setResponseMessage("retrieved successfully");
                response.setStatus("success");
                response.setData(schemeModelFromDb);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> deleteProductScheme(String schemeProductId) {
        Response response = new Response();
        try {
            SchemeProductsModel schemesModelFromDbById = schemeProductRepository.findBySchemeProductIdAndDeletedAtIsNull(schemeProductId).orElseThrow(() -> new RuntimeException("no data found"));
            schemesModelFromDbById.setStatus("InActive");
            schemesModelFromDbById.setDeletedAt(new Date());
            schemeProductRepository.save(schemesModelFromDbById);
            response.setResponseMessage("scheme deleted successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //--3--/
    public ResponseEntity<Response> createSchemeRule(SchemeRulesModel schemeRulesModel) {
        Response response = new Response();
        try {
            //-- Check if the scheme exists
            SchemesModel scheme = schemeRepository.findById(schemeRulesModel.getSchemesModel().getSchemeId()).orElseThrow(() -> new RuntimeException("No scheme found for ID: " + schemeRulesModel.getSchemesModel().getSchemeId()));

            // --Generate new schemeRuleId
            SchemeRulesModel lastSchemeRule = schemeRuleRepository.findFirstByOrderByCreatedAtDesc();
            String schemeRuleId = lastSchemeRule == null ? "SCR0001" : "SCR" + String.format("%04d", Long.parseLong(lastSchemeRule.getSchemeRuleId().replace("SCR", "")) + 1);
            while (schemeRuleRepository.existsById(schemeRuleId)) {
                schemeRuleId = lastSchemeRule == null ? "SCR0001" : "SCR" + String.format("%04d", Long.parseLong(lastSchemeRule.getSchemeRuleId().replace("SCR", "")) + 1);

            }

            //-- Check if the product exists (if applicable)
            ProductModel product = null;
            if (schemeRulesModel.getProductModel() != null && schemeRulesModel.getProductModel().getProductId() != null) {
                product = productRepository.findById(schemeRulesModel.getProductModel().getProductId()).orElseThrow(() ->
                        new RuntimeException("No product found for ID: " + schemeRulesModel.getProductModel().getProductId()));
            }

            SchemeRulesModel newSchemeRule = new SchemeRulesModel();
            newSchemeRule.setSchemeRuleId(schemeRuleId);
            newSchemeRule.setSchemesModel(scheme);
            newSchemeRule.setConditionType(schemeRulesModel.getConditionType());
            newSchemeRule.setConditionValue(schemeRulesModel.getConditionValue());
            newSchemeRule.setRewardType(schemeRulesModel.getRewardType());
            newSchemeRule.setRewardValue(schemeRulesModel.getRewardValue());
            if(schemeRulesModel.getFreeProductQuantity() < 0 ){
                throw new RuntimeException("free product quantity cannot be zero");
            }
            if(schemeRulesModel.getProductModel() !=null){
                 if(schemeRulesModel.getFreeProductQuantity() <=0){
                     throw new RuntimeException("free product quantity cannot be zero or negative");
                 }
            }
            if(schemeRulesModel.getProductModel() == null){
                if(schemeRulesModel.getFreeProductQuantity() >0){
                    throw new RuntimeException("please choose product to add quantity");
                }
            }
            if(schemeRulesModel.getFreeProductQuantity() == null){
                if(schemeRulesModel.getProductModel() != null){
                    throw new RuntimeException("please add quantity for product");
                }
            }
            newSchemeRule.setFreeProductQuantity(schemeRulesModel.getFreeProductQuantity());
            newSchemeRule.setProductModel(product);
            newSchemeRule.setCreatedAt(new Date());
            newSchemeRule.setStatus("Active");

            schemeRuleRepository.save(newSchemeRule);

            response.setResponseMessage("Scheme Rule created successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> getAllRuleScheme(String status , Date startDate, Date endDate) {
        Response response = new Response();
        try {
            List<SchemeRulesModel> schemeRuleModelFromDb = schemeRuleRepository.findByStatusAndCreatedAtBetween(status,startDate,endDate);
            if (schemeRuleModelFromDb.isEmpty()) {
                response.setData(null);
                response.setStatus("success");
                response.setResponseMessage("no Data Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setResponseMessage("retrieved successfully");
                response.setStatus("success");
                response.setData(schemeRuleModelFromDb);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> updateSchemeRule(SchemeRulesModel updateSchemeRule) {
        Response response = new Response();
        try {
            String schemeRuleId = updateSchemeRule.getSchemeRuleId();
            System.out.println(schemeRuleId);
            if (schemeRuleId == null || schemeRuleId.isEmpty()) {
                response.setStatus("failure");
                response.setResponseMessage("Scheme ID is required");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            SchemeRulesModel existingSchemeRule = schemeRuleRepository.findById(schemeRuleId).orElseThrow(() -> new RuntimeException("No scheme Rule found for ID: " + schemeRuleId));
            existingSchemeRule.setSchemesModel(updateSchemeRule.getSchemesModel());
            existingSchemeRule.setConditionType(updateSchemeRule.getConditionType());
            existingSchemeRule.setConditionValue(updateSchemeRule.getConditionValue());
            existingSchemeRule.setRewardType(updateSchemeRule.getRewardType());
            existingSchemeRule.setRewardValue(updateSchemeRule.getRewardValue());
            existingSchemeRule.setUpdatedAt(new Date());
            existingSchemeRule.setProductModel(updateSchemeRule.getProductModel());
            existingSchemeRule.setFreeProductQuantity(updateSchemeRule.getFreeProductQuantity());
            schemeRuleRepository.save(existingSchemeRule);
            response.setResponseMessage("Scheme updated successfully");
            response.setStatus("success");
            response.setData(Collections.singletonList(existingSchemeRule));
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> deleteRuleScheme(String schemeRuleId) {
        Response response = new Response();
        try {
            SchemeRulesModel schemesModelFromDbById = schemeRuleRepository.findBySchemeRuleIdAndDeletedAtIsNull(schemeRuleId).orElseThrow(() -> new RuntimeException("no data found"));
            schemesModelFromDbById.setStatus("InActive");
            schemesModelFromDbById.setDeletedAt(new Date());
            schemeRuleRepository.save(schemesModelFromDbById);
            response.setResponseMessage("scheme deleted successfully");
            response.setStatus("success");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage("Failure: " + e.getMessage());
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> findSchemesByProductId(String productId){

        Response response = new Response();
        try{
            List<SchemesGetByProductId> schemesByProductId = schemeProductRepository.fetchSchemeDetails(productId);
            if (schemesByProductId.isEmpty()) {
                response.setData(null);
                response.setStatus("success");
                response.setResponseMessage("no Data Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setResponseMessage("retrieved successfully");
                response.setStatus("success");
                response.setData(schemesByProductId);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        }
    public ResponseEntity<Response> findGlobalSchemes(){

        Response response = new Response();
        try{
            List<SchemeGlobalDto> schemesGlobalFromDb = schemeProductRepository.fetchGlobalDetails();
            if (schemesGlobalFromDb.isEmpty()) {
                response.setData(null);
                response.setStatus("success");
                response.setResponseMessage("no Data Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setResponseMessage("retrieved successfully");
                response.setStatus("success");
                response.setData(schemesGlobalFromDb);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<Response> getAllGlobalSchemes(Date startDate, Date endDate) {
        Response response = new Response();
        try {
            List<SchemesModel> schemes = schemeRepository.findAllGlobalSchemesByDate(startDate, endDate);

            if (schemes.isEmpty()) {
                response.setData(null);
                response.setStatus("success");
                response.setResponseMessage("No data found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

            List<SchemeResponseDTO> responseDTOs = new ArrayList<>();

            for (SchemesModel scheme : schemes) {
                SchemeResponseDTO responseDTO = new SchemeResponseDTO();
                responseDTO.setSchemeId(scheme.getSchemeId());
                responseDTO.setSchemeName(scheme.getSchemeName());
                responseDTO.setStartDate(scheme.getStartDate());
                responseDTO.setEndDate(scheme.getEndDate());

                List<SchemeRuleDTO> ruleDTOs = new ArrayList<>();
                for (SchemeRulesModel rule : scheme.getSchemeRulesModel()) { // Assuming you have a mapped collection
                    SchemeRuleDTO ruleDTO = new SchemeRuleDTO();
                    ruleDTO.setSchemeRuleId(rule.getSchemeRuleId());
                    ruleDTO.setConditionType(rule.getConditionType());
                    ruleDTO.setConditionValue(rule.getConditionValue());
                    ruleDTO.setRewardType(rule.getRewardType());
                    ruleDTO.setRewardValue(rule.getRewardValue());
                    ruleDTO.setFreeProductId(rule.getProductModel() != null ? rule.getProductModel().getProductId() : null);
                    ruleDTO.setFreeProductQuantity(rule.getFreeProductQuantity());


                    if (rule.getProductModel() != null) {
                        ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();
                        productDetailsDTO.setProductId(rule.getProductModel().getProductId());
                        productDetailsDTO.setProductName(rule.getProductModel().getProductName());
                        productDetailsDTO.setPrice(rule.getProductModel().getPrice());
                        productDetailsDTO.setWeightPerUnit(rule.getProductModel().getWeightPerUnit());
                        productDetailsDTO.setUnitPerBox(rule.getProductModel().getUnitPerBox());
                        productDetailsDTO.setBoxWeight(rule.getProductModel().getBoxWeight());
                        productDetailsDTO.setStandard(rule.getProductModel().getStandard());
                        ruleDTO.setFreeProductDetails(productDetailsDTO);
                    } else {
                        ruleDTO.setFreeProductDetails(null);
                    }

                    ruleDTOs.add(ruleDTO);
                }

                responseDTO.setSchemeRules(ruleDTOs);
                responseDTOs.add(responseDTO);
            }

            response.setResponseMessage("Retrieved successfully");
            response.setStatus("success");
            response.setData(responseDTOs);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    public ResponseEntity<Response> findSchemesByProduct(String productId , Date startDate, Date endDate) {
        Response response = new Response();
        try {
            List<SchemeProductsModel> schemeProducts = schemeProductRepository.findByProductModel_ProductId(productId, startDate ,endDate);
            if (schemeProducts.isEmpty()) {
                response.setData(null);
                response.setStatus("success");
                response.setResponseMessage("no Data Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                List<SchemeProductDto> schemeProductDtos = mapToSchemeProductDtos(schemeProducts);
                response.setResponseMessage("retrieved successfully");
                response.setStatus("success");
                response.setData(schemeProductDtos);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private List<SchemeProductDto> mapToSchemeProductDtos(List<SchemeProductsModel> schemeProducts) {
        List<SchemeProductDto> schemeProductDtos = new ArrayList<>();
        for (SchemeProductsModel schemeProduct : schemeProducts) {
            SchemeDto schemeDto = new SchemeDto();
            schemeDto.setSchemeId(schemeProduct.getSchemesModel().getSchemeId());
            schemeDto.setSchemeName(schemeProduct.getSchemesModel().getSchemeName());
            schemeDto.setDescription(schemeProduct.getSchemesModel().getDescription());
            schemeDto.setStartDate(schemeProduct.getSchemesModel().getStartDate());
            schemeDto.setEndDate(schemeProduct.getSchemesModel().getEndDate());
            schemeDto.setIsActive(schemeProduct.getSchemesModel().getIsActive());
            schemeDto.setIsGlobal(schemeProduct.getSchemesModel().getIsGlobal());

            List<SchemeRuleDTO> ruleDtos = new ArrayList<>();
            for (SchemeRulesModel rule : schemeProduct.getSchemesModel().getSchemeRulesModel()) {
                SchemeRuleDTO ruleDto = new SchemeRuleDTO();
                ruleDto.setSchemeRuleId(rule.getSchemeRuleId());
                ruleDto.setConditionType(rule.getConditionType());
                ruleDto.setConditionValue(rule.getConditionValue());
                ruleDto.setRewardValue(rule.getRewardValue());
                ruleDto.setRewardType(rule.getRewardType());
                 ruleDto.setFreeProductQuantity(0);
                // Handle product model and set freeProductId to null when product is not present
                if (rule.getProductModel() != null) {
                    ruleDto.setFreeProductId(rule.getProductModel().getProductId());
                    ProductDetailsDTO productDto = new ProductDetailsDTO();
                    productDto.setProductId(rule.getProductModel().getProductId());
                    productDto.setProductName(rule.getProductModel().getProductName());
                    productDto.setPrice(rule.getProductModel().getPrice());
                    productDto.setWeightPerUnit(rule.getProductModel().getWeightPerUnit());
                    productDto.setUnitPerBox(rule.getProductModel().getUnitPerBox());
                    productDto.setBoxWeight(rule.getProductModel().getBoxWeight());
                    productDto.setStandard(rule.getProductModel().getStandard());
                    ruleDto.setFreeProductDetails(productDto);
                    ruleDto.setFreeProductQuantity(rule.getFreeProductQuantity());
                }

                ruleDtos.add(ruleDto);
            }
            schemeDto.setRules(ruleDtos);

            // Create SchemeProductDto without schemeProductId and productId
            SchemeProductDto schemeProductDto = new SchemeProductDto();
            schemeProductDto.setScheme(schemeDto);

            schemeProductDtos.add(schemeProductDto);
        }
        return schemeProductDtos;
    }


}
