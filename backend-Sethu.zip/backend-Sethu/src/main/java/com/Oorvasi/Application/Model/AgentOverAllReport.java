package com.Oorvasi.Application.Model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AgentOverAllReport {


    private List<AgentMonthlyReportModel> agentMonthlyReportModelList;
    private AgentReportModel agentReportModel;
}
