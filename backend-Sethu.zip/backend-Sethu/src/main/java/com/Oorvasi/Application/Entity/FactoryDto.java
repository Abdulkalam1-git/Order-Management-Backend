package com.Oorvasi.Application.Entity;

public interface FactoryDto{
    String getFactoryName();
    String getShortCode();

}
