package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.ShopOrderItemsDto;
import com.Oorvasi.Application.Entity.ShopOrderListProductDto;
import com.Oorvasi.Application.Model.ShopOrderListModel;
import com.Oorvasi.Application.Model.ShopOrderModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ShopOrderListRepository extends JpaRepository<ShopOrderListModel,String> {

    List<ShopOrderListModel>   findByShopOrderModelTempId(String tempId);
       ShopOrderListModel findFirstByOrderByCreatedOnDesc();

       @Query(value = "  select p.product_name  AS ProductName, sol.quantity AS Quantity, sol.amount AS Amount, sol.total_amount AS TotalAmount from " +
               "  shop_order_list_table AS sol " +
               "  join product_table AS p " +
               "  on p.product_id = sol.product_id " +
               "  where temp_id =:ShopTempId",nativeQuery = true)
       List<ShopOrderListProductDto> getShopOrderListProduct(@Param("ShopTempId")String ShopTempId);

       @Query(value = "  select s.shop_name AS ShopName , " +
               "sot.executive_name AS ExecutiveName  , " +
               "l.location_name AS LocationName ," +
               " sot.total_order_weight AS TotalOrderWeight , " +
               "sot.total_order_amount AS TotalOrderAmount  , " +
               "COALESCE(sot.total_free_order_weight , 0) As TotalFreeOrderWeight "+
               "   from shop_order_table AS sot " +
               "   join shop_table AS s on s.shop_id = sot.shop_id " +
               "   join location_table AS l on  l.location_id = s.location_id " +
               "   where sot.temp_id =:ShopTempId",nativeQuery = true)
       List<ShopOrderItemsDto> getShopOrderListInformation(@Param("ShopTempId") String ShopTempId);

       List<ShopOrderListModel> findByShopOrderModel(ShopOrderModel shopOrderModel);

   @Query(value = "select olt.order_list_id as orderListId,pt.product_name as productName,pt.product_id as productId,pt.price as price,olt.quantity as quantity,\n" +
           "olt.total_amount as total_amount,olt.delivery_status as status,olt.factory_id as factory_id \n" +
           "from shop_order_list_table as olt inner join\n" +
           "product_table as pt on olt.product_id=pt.product_id where olt.temp_id=:tempId ",nativeQuery = true)
   List<OrderDetailsRepo> findBytempIds(String tempId);
}
