package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UuidGenerator;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "journal_entry_table")
public class JournalEntryModel {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private String journalId;
    private Date journalDate = new Date();
    private String accountId;
    private String debitAccountId;
    private String creditAccountId;
    private String particular;
    private Integer debit;
    private Integer credit;
    private String status;
    private Date createdOn= new Date();
    private String createdBy ;
    private Date updatedOn;
    private String updatedBy;
    private String encryptId;
    private String referenceNo;
}
