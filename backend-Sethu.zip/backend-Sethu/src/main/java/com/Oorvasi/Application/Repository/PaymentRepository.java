package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.PaymentModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PaymentRepository extends JpaRepository<PaymentModel,String> {

    PaymentModel findFirstByOrderByCreatedOnDesc();

    boolean existsByPaymentId(String paymentId);


}
