package com.Oorvasi.Application.Entity;

public interface FactoryAssignDto {

    String getOrderId();
    double getTotalOrderWeight();
    double getTotalOrderAmount();
    double getTotalFreeOrderWeight();
    double getAgentBalance();
    String getStatus();

}
