package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.ItemDetailDto;
import com.Oorvasi.Application.Entity.ItemDto;
import com.Oorvasi.Application.Entity.LocationPriceDto;
import com.Oorvasi.Application.Model.ProductModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface ProductRepository extends JpaRepository<ProductModel,String> {

    ProductModel findFirstByOrderByCreatedOnDesc();

    boolean existsByProductId(String productId);

    @Query(value = "select p.product_id as productId,p.product_name AS productName , p.weight_per_unit  AS weightPerUnit ,p.price AS price  from product_table AS p " +
            "where p.status iLike 'active' AND (:search IS NULL OR p.product_name iLIKE %:search%)",nativeQuery = true)
    List<ItemDto> findAll(String search);

    @Query(value = "select w.product_name , w.weight_per_unit , w.box_weight , w.price , w.unit_per_box , w.standard from product_table AS w where w.product_id = :productId ",nativeQuery = true)
    List<ItemDetailDto> findProduct(String productId);

    @Query(value = "SELECT l.location_name , p.location_price " +
            "FROM product_price_table AS p " +
            "JOIN location_table AS l " +
            "ON l.location_id = p.location_id " +
            "WHERE p.product_id = :productId " +
            "AND p.status ILIKE 'active'", nativeQuery = true)
    List<LocationPriceDto> findPrice(String productId);

    ProductModel findByProductIdAndStatus(String productId,String status);

    @Query(value = " select p.product_id as productId,p.product_name AS productName , p.weight_per_unit  AS weightPerUnit ,p.price AS price  from product_table AS p " +
            "where p.status iLike 'Active' AND (:search IS NULL OR p.product_name iLIKE %:search%) ",nativeQuery = true)
    Page<ItemDto> findAllItems(String search, Pageable pageable);
}
