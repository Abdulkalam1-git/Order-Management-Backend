package com.Oorvasi.Application.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "payment_type_table")
@Entity
public class PaymentTypeModel {

    @Id
    private String paymentTypeId;
    private String paymentMode;
    private String status;
    private Date createdOn = new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}
