package com.Oorvasi.Application.Entity;

public interface AgentPerformanceDto {
    String getAgent();

    String getAgentId();

    String getLocationId();
    String getState();

    String getCity();

    String getArea();

    Long getOrders();

    Long getSales();
}
