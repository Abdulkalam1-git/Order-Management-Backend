package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.text.DecimalFormat;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "order_list_table")
public class OrderListModel {

    @Id
    private String orderListId;
    @OneToOne
    @JoinColumn(name = "order_id",nullable = false)
    OrderModel orderModel;
    @OneToOne
    @JoinColumn(name = "product_id",nullable = false)
    ProductModel productModel;
    private Integer quantity;
    private Double amount;
    private Double totalAmount;
    @OneToOne
    @JoinColumn(name = "factory_id")
    FactoryModel factoryModel;
    private String deliveryStatus;
    private Date createdOn;
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}
