package com.Oorvasi.Application.Model;

import com.Oorvasi.Application.Entity.ShopOrderResponseModel;
import com.Oorvasi.Application.Repository.OrderDetailsRepo;
import com.Oorvasi.Application.Repository.OrderResponseModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderAndOrderListModel {

    private OrderResponseModel orderModel;
    private List<OrderDetailsRepo> orderListModelList;
    private ShopOrderResponseModel shopOrderResponseModel;
    private Double agentBalance;
}
