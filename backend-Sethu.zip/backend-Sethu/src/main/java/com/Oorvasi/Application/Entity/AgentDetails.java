package com.Oorvasi.Application.Entity;

public interface AgentDetails {

          String getAgentName();
          String getAgentId();
          String getLocationId();
          String getCity();
          String getArea();
          Double getDiscountPercent();
          Long getAgentBalance();
}
