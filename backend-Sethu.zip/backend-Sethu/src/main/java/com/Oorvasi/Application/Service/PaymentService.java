package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.PaymentTypeModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Repository.PaymentRepository;
import com.Oorvasi.Application.Repository.PaymentTypeRepository;
import com.Oorvasi.Application.Repository.TransactionalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class PaymentService {
    @Autowired
    private PaymentTypeRepository paymentTypeRepository;

    public ResponseEntity<Response> addPaymentType(PaymentTypeModel paymentTypeModel) {
        Response response = new Response();
        try {
            PaymentTypeModel paymentTypeModelFromDB = paymentTypeRepository.findFirstByOrderByCreatedOnDesc();
            String paymentTypeId = paymentTypeModelFromDB == null ? "PT001" : "PT" + String.format("%03d", (Long.parseLong(paymentTypeModelFromDB.getPaymentTypeId().split("PT")[1]) + 1));
            while (paymentTypeRepository.existsByPaymentTypeId(paymentTypeId)) {
                paymentTypeId = paymentTypeModelFromDB == null ? "PT001" : "PT" + String.format("%03d", (Long.parseLong(paymentTypeId.split("PT")[1]) + 1));
            }
            paymentTypeModel.setPaymentTypeId(paymentTypeId);
            paymentTypeModel.setStatus("Active");
            paymentTypeModel.setCreatedOn(new Date());
            paymentTypeRepository.save(paymentTypeModel);
            response.setStatus("Success");
            response.setResponseMessage("Payment Type Added Successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }
    public ResponseEntity<Response> getPaymentTypes(){
        Response response = new Response();
        try {
            List<PaymentTypeModel> paymentTypeModel = paymentTypeRepository.findAll();
            response.setStatus("Success");
            response.setResponseMessage("Payment Types");
            response.setData(paymentTypeModel);
            return new ResponseEntity<>(response,HttpStatus.OK);
        }catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Unhandled Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }
}
