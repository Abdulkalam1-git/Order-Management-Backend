package com.Oorvasi.Application.Model;


public interface AgentReportModel {

     Integer getCount();
     Double getTotalSalesAmount();
}
