package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.JournalEntryModel;
import com.Oorvasi.Application.Model.OrderListModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Repository.JournalEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;

@Service
public class JournalEntryService {

    @Autowired
    private JournalEntryRepository journalEntryRepository;

    public ResponseEntity<Response> createJournalEntry(JournalEntryModel journalEntryModel) {
        Response response = new Response();
        try {

            JournalEntryModel journalEntryModelFromDb = journalEntryRepository.findFirstByOrderByCreatedOnDesc();
            String journalId = journalEntryModelFromDb == null ? "JI0000001" : "JI" + String.format("%07d", (Long.parseLong(journalEntryModelFromDb.getJournalId().split("JI")[1]) + 1));
            journalEntryModel.setJournalId(journalId);
            Integer debitFromDb = journalEntryModel.getDebit();
            Integer creditFromDb = journalEntryModel.getCredit();
            if (debitFromDb == 0 || creditFromDb == 0) {
                throw new RuntimeException("debit or credit amount cannot be zero");
            }
            if (debitFromDb < 0 || creditFromDb < 0) {
                throw new RuntimeException("debit or credit amount cannot be negative");
            }

            boolean checkNullFromDb = journalEntryModelFromDb != null;
            response.setResponseMessage(checkNullFromDb ? " successfully created JournalEntry " : " failed to create JournalEntry ");
            response.setStatus(checkNullFromDb ? "Success" : "Failure");
            journalEntryRepository.save(journalEntryModel);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setData(null);
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
