package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.AccountMasterModel;
import com.Oorvasi.Application.Model.AccountTypeModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/account")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

public class AccountController {
    @Autowired
    private AccountService accountService;

//    @PreAuthorize("hasAnyAuthority('Read_User')")
    @PostMapping("/create/account-type")
    public ResponseEntity<Response> createAccountType(@RequestBody AccountTypeModel accountTypeModel) {
        return accountService.createAccountType(accountTypeModel);
    }

//    @PreAuthorize("hasAnyAuthority('Read_User')")
    @PostMapping("/create/account-master")
    public ResponseEntity<Response> createAccountMaster(@RequestBody AccountMasterModel accountMasterModel) {
        return accountService.createAccountMaster(accountMasterModel);
    }

//    @PreAuthorize("hasAnyAuthority('Read_User')")
    @GetMapping("/get/Account")
    public ResponseEntity<Response> searchAccountsByTypeAndName(@RequestParam String Type, @RequestParam String keyWord) {
        return accountService.getAccountsByAccountTypeAndAccountName(Type, keyWord);
    }


}
