package com.Oorvasi.Application.Controller;

import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.TransActionAndPaymentModel;
import com.Oorvasi.Application.Service.TransActionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transaction")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)

public class TransActionController {

    @Autowired
    private TransActionService transActionService;
    @PreAuthorize("hasAnyAuthority('Make PayMent')")
    @PostMapping(value = "/make/transaction")
    public ResponseEntity<Response> makeTransAction(@RequestBody TransActionAndPaymentModel transActionAndPaymentModel) {
        return transActionService.addTransAction(transActionAndPaymentModel);
    }
    @PreAuthorize("hasAnyAuthority('View Final PayMent ')")
    @PostMapping(value = "/get/final/paymentDetails")
    public ResponseEntity<Response> getFinalDetails(@RequestBody TransActionAndPaymentModel transActionAndPaymentModel){
        return transActionService.getFinalPaymentDetails(transActionAndPaymentModel);
    }
}
