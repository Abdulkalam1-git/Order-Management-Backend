package com.Oorvasi.Application.Service;

import com.Oorvasi.Application.Model.PermissionModel;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Model.RolePermissionModel;
import com.Oorvasi.Application.Repository.PermissionsRepository;
import com.Oorvasi.Application.Repository.RolePermissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RolePermisssionsService {

    @Autowired
    private RolePermissionRepository rolePermissionRepository;

    public ResponseEntity<Response>createRolePermissions(RolePermissionModel rolePermissionModel) {
        Response response = new Response();
        try {
            rolePermissionRepository.save(rolePermissionModel);
            response.setStatus("Success");
            response.setResponseMessage("Permission Created successfully");
            response.setData(Collections.singletonList(rolePermissionModel));
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.setStatus("Failure");
            response.setResponseMessage("Error occurred while Creating Permission: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    public ResponseEntity<Response> getAllPermissions(){
//        Response responses=new Response();
//        try{
//            List<PermissionModel> permissions =  permissionsRepository.findAll();
//            responses.setStatus("Success");
//            responses.setResponseMessage("Retrieved all Permissions Successfully");
//            responses.setData(permissions);
//            return new ResponseEntity<>(responses, HttpStatus.OK);
//        }
//        catch (Exception e){
//            responses.setStatus("Failure");
//            responses.setResponseMessage(e.getLocalizedMessage());
//            return new ResponseEntity<>(responses, HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

}
