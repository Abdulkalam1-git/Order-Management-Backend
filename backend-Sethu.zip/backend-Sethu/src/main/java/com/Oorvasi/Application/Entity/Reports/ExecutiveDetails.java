package com.Oorvasi.Application.Entity.Reports;

import java.math.BigInteger;

public interface ExecutiveDetails {

               BigInteger getExecutiveId();
               BigInteger getUserId();
               String getName();
               String getLocationId();
               String getArea();
               String getCity();
               String getState();
               Long getOrders();
               Long getSales();




}
