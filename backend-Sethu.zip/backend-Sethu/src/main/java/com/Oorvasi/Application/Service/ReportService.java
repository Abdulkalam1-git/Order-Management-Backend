package com.Oorvasi.Application.Service;


import com.Oorvasi.Application.Entity.*;
import com.Oorvasi.Application.Model.Response;
import com.Oorvasi.Application.Entity.Reports.*;
import com.Oorvasi.Application.Repository.AgentRepository;
import com.Oorvasi.Application.Repository.OrderListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class ReportService {

    @Autowired
    private OrderListRepository orderListRepository;
    @Autowired
    private AgentRepository agentRepository;

    // -- 1. sales insight -- //

    public ResponseEntity<Response> salesForMonth() {
        Response response = new Response();
        try {
            SalesForMonthDto salesForMonthDto = orderListRepository.salesForMonth();
            if (salesForMonthDto == null) {
                response.setResponseMessage("no data found");
                response.setStatus("failure");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("Success");
                response.setResponseMessage("sales for the current month ");
                response.setData(Collections.singletonList(salesForMonthDto));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response> monthlySalesGroupByYear(int year) {
        Response response = new Response();
        try {
            List<MonthlySalesReports> monthlySalesReportsByYear = orderListRepository.monthlySalesReports(year);
            MonthlySalesByYearTotal monthlySalesByYearTotal = orderListRepository.monthlySalesByYear(year);

            CombinedYearsDetails combinedYearsDetails = new CombinedYearsDetails();

            if (monthlySalesReportsByYear.isEmpty() || monthlySalesByYearTotal == null) {
                response.setStatus("failure");
                response.setResponseMessage("no data found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                combinedYearsDetails.setMonthlySalesByYears(monthlySalesReportsByYear);
                combinedYearsDetails.setYearTotal(monthlySalesByYearTotal);
                response.setData(Collections.singletonList(combinedYearsDetails));
                response.setResponseMessage("success");
                response.setStatus("success");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }

        } catch (Exception e) {
            throw e;
        }
    }

    public ResponseEntity<Response> SalesChart(int year, String locationId) {
        Response response = new Response();
        try {
            List<SalesChartDto> salesChartDto = orderListRepository.salesChartDto(year, locationId);
            List<SalesOverTheYearByZone> salesOverTheYearByZones = orderListRepository.salesOverYearByZone(year);
            CombinedSalesChartDetails salesChartDetails = new CombinedSalesChartDetails();
            salesChartDetails.setSalesOverTheYear(salesChartDto);
            salesChartDetails.setZones(salesOverTheYearByZones);
            if (salesChartDto == null) {
                response.setResponseMessage("no data found");
                response.setStatus("failure");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("Success");
                response.setResponseMessage("sales for the current month ");
                response.setData(Collections.singletonList(salesChartDetails));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // --2 report --(i)// zone --//

    public ResponseEntity<Response> getZoneDetails(String startDate, String endDate, Pageable pageable) {
        Response response = new Response();
        try {
            Page<ZoneByDto> zoneStats = orderListRepository.findTotalOrderByZones(startDate, endDate, pageable);
            TotalSales orderSummary = orderListRepository.findTotalSales(startDate, endDate);

            CombinedZoneResponseDTO combinedResponse = new CombinedZoneResponseDTO();

            combinedResponse.setZoneStats(zoneStats);
            combinedResponse.setOrderSummary(orderSummary);

            response.setStatus("success");
            response.setResponseMessage("summary Data fetched successfully ");
            response.setData(Collections.singletonList(combinedResponse));
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // (ii) -- //
    public ResponseEntity<Response> getZoneOrderDetails(String startDate, String endDate, Pageable pageable, String locationId) {
        Response response = new Response();
        try {
            Page<OrderByDto> orderStats = orderListRepository.findByOrders(startDate, endDate, pageable, locationId);
            ZoneBasedTotal orderSummary = orderListRepository.findZoneBasedSales(startDate, endDate, locationId);

            CombinedOrderResponseDTO combinedResponse = new CombinedOrderResponseDTO();

            combinedResponse.setOrderStats(orderStats);
            combinedResponse.setOrderSummary(orderSummary);
            response.setStatus("success");
            response.setResponseMessage("Data fetched successfully");
            response.setData(Collections.singletonList(combinedResponse));
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // -- 3 -- // items -- //

    public ResponseEntity<Response> ItemTrends(String startDate, String endDate, Pageable pageable, String factoryId) {
        Response response = new Response();
        try {
            Page<ItemTrendDto> ItemsDetails = orderListRepository.ItemTrends(startDate, endDate, factoryId, pageable);
            ItemOrderSummaryDto ItemSummary = orderListRepository.getTotalOrderAndItems(startDate, endDate, factoryId);
            ItemTrend itemTrendSummary = new ItemTrend();
            itemTrendSummary.setItemSummary(ItemSummary);
            itemTrendSummary.setItemsTrends(ItemsDetails);

            if (ItemsDetails.isEmpty() || ItemSummary == null) {
                response.setStatus("failure");
                response.setResponseMessage("no data found");

                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            } else {

                response.setStatus("success");
                response.setResponseMessage(" Retrieved Successfully");
                response.setData(Collections.singletonList(itemTrendSummary));

                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setData(null);
            response.setResponseMessage(" Retrieved Successfully ");
            response.setResponseMessage("failure " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //-- 4 ----- agent performance -----//

    public ResponseEntity<Response> agentPerformance(String startDate, String endDate, String locationId, Pageable pageable) {
        Response response = new Response();
        try {
            Page<AgentPerformanceDto> agentPerformance = agentRepository.AgentPerformance(startDate, endDate, locationId, pageable);
            AgentSummary agentSummary = agentRepository.agentSummary(startDate, endDate, locationId);
            AgentPerformanceTotal agentPerformanceTotal = new AgentPerformanceTotal();
            agentPerformanceTotal.setAgentSummary(agentSummary);
            agentPerformanceTotal.setAgentPerformance(agentPerformance);
            if (agentPerformance.isEmpty() || agentSummary == null) {
                response.setResponseMessage("no agents found for this location");
                response.setStatus("failure");
                response.setData(null);
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            } else {
                response.setData(Collections.singletonList(agentPerformanceTotal));
                response.setStatus("success");
                response.setResponseMessage("agent retrieved successfully");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    //--5 agent -- //

    public ResponseEntity<Response> fetchAgentSummary(String startDate, String endDate, String locationId, Pageable pageable) {
        Response response = new Response();
        try {
            Page<AgentDetailsDTO> agentSummary = agentRepository.agentOutStandingDetails(startDate, endDate, locationId, pageable);
            TotalOutstandingDto totalOutStanding = agentRepository.totalOutStandingAmounts(locationId);
            TotalSalesDto totalSales = agentRepository.TotalSales(locationId);
            AgentCount agentCount = agentRepository.agentsDetails(locationId);

            AgentOutStandingDto agents = new AgentOutStandingDto();
            agents.setTotalSales(totalSales);
            agents.setTotalOutStandings(totalOutStanding);
            agents.setAgent(agentCount);
            agents.setAgents(agentSummary);

            if (agentSummary.isEmpty()) {
                response.setResponseMessage("No agents found");
                response.setStatus("failure");
                response.setData(null);
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            } else {
                response.setData(Collections.singletonList(agents));
                response.setStatus("success");
                response.setResponseMessage("Agent summary retrieved successfully ");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setStatus("failure");
            response.setResponseMessage(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    //--6 -- // executive --//

    public ResponseEntity<Response> getExecutiveTotals(String startDate, String endDate, String locationId, Pageable pageable) {
        Response response = new Response();
        try {
            ExecutiveTotals executiveTotals = orderListRepository.findExecutiveTotals(startDate, endDate, locationId);
            Page<ExecutiveDetails> executiveDetails = orderListRepository.findExecutiveDetails(startDate, endDate, locationId, pageable);

            if (executiveTotals == null) {
                response.setStatus("failure");
                response.setResponseMessage("no data found for this locationId " + locationId);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else {
                response.setStatus("success");
                response.setResponseMessage("executive details found ");
                response.setData(Collections.singletonList(new CombinedExecutiveDetails(executiveTotals, executiveDetails)));
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        } catch (Exception e) {
            response.setResponseMessage(e.getMessage());
            response.setStatus("failure");
            response.setData(null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
