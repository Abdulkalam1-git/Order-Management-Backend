package com.Oorvasi.Application.Entity;

public interface OrderDto {

    String getOrderId();
    double getTotalOrderWeight();
    double getTotalOrderAmount();
    double getTotalFreeOrderWeight();
    Integer getItems();
    String getStatus();
    Double getAgentBalance();

}
