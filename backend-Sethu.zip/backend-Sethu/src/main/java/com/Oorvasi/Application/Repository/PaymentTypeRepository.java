package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.PaymentTypeModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentTypeRepository extends JpaRepository<PaymentTypeModel,String> {

    PaymentTypeModel findFirstByOrderByCreatedOnDesc();

    boolean existsByPaymentTypeId(String paymentTypeId);
}
