package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.PermissionModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionsRepository extends JpaRepository<PermissionModel, String> {
    Boolean existsByPermissionName(String permissionName);
}
