package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Entity.ShopOrderDto;
import com.Oorvasi.Application.Entity.ShopOrderResponseModel;
import com.Oorvasi.Application.Model.ShopModel;
import com.Oorvasi.Application.Model.ShopOrderModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ShopOrderRepository extends JpaRepository<ShopOrderModel , String> {

    ShopOrderModel findFirstByOrderByCreatedOnDesc();

    @Query(value = "SELECT s.shop_id As shopId,s.shop_name AS shopName, o.total_order_weight AS totalOrderWeight, " +
            "o.total_order_amount AS totalOrderAmount, COALESCE(o.total_free_order_weight,0) AS totalFreeOrderWeight  , o.temp_id as tempId, o.executive_name AS executiveName , o.executive_id AS executiveId " +
            "FROM shop_order_table o " +
            "JOIN shop_table s ON o.shop_id = s.shop_id " +
            "WHERE o.executive_name IS NOT NULL AND s.shop_name ILIKE %:keyWord% and o.status iLike 'Active' and s.location_id=:locationId " +
            "ORDER BY o.executive_name", nativeQuery = true)
    List<ShopOrderDto> findShopsGroupedByExecutive(@Param("keyWord") String keyWord, String locationId, Pageable pageable);


    @Query(value = "select sot.temp_id as tempId,sot.executive_id as executiveId,sot.executive_name as executiveName,s.city as city,s.area as area,st.shop_name as shopName,\n" +
            "st.shop_id as shopId,sot.total_order_amount as totalOrderAmount, sot.total_order_weight as totalOrderWeight , COALESCE(sot.total_free_order_weight , 0)  as totalFreeOrderWeight from shop_order_table as sot \n" +
            "inner join shop_table as st on sot.shop_id=st.shop_id\n" +
            "inner join staffs as s on s.user_id=sot.executive_id where sot.temp_id=:tempId ",nativeQuery = true)
    ShopOrderResponseModel findByTempIds(String tempId);
    ShopOrderModel findByTempId(String tempId);


    List<ShopOrderModel> findByExecutiveIdAndStatus(Integer executiveId,String status);

    ShopOrderModel findByExecutiveIdAndShopModelShopIdAndStatus(Integer executiveId, String shopId, String status);

    List<ShopOrderModel> findByTempIdIn(List<String> tempIds);
}
