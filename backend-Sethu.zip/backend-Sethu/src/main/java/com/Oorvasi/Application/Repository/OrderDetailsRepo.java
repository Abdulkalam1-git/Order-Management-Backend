package com.Oorvasi.Application.Repository;

public interface OrderDetailsRepo {

    String getOrderListId();
    String getProductId();
    String getProductName();
    Double getPrice();
    Integer getQuantity();
    Double getTotalAmount();
    String getStatus();
    String getFactoryId();
    String getFactoryName();
    String getFactoryShortName();
    Double getWeightPerUnit();
}
