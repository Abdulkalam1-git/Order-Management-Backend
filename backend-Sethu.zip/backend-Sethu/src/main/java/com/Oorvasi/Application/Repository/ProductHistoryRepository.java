package com.Oorvasi.Application.Repository;

import com.Oorvasi.Application.Model.ProductHistoryTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductHistoryRepository extends JpaRepository<ProductHistoryTable,String> {

}