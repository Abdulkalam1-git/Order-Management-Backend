package com.Oorvasi.Application.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "shop_table")
public class ShopModel {

    @Id
    private String shopId;
    private String shopName;
    private String area;
    @OneToOne
    @JoinColumn(name = "location_id",nullable = false)
    LocationModel locationModel;
    private String state;
    private String city;
    private String status;
    private Date createdOn=new Date();
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;
}
